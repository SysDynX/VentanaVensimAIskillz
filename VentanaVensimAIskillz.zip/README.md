# VentanaAI.VenAIdev

AI-assisted System Dynamics modelling experiments using Vensim and Ventity.

## Directory structure

### Shared resources

**SDAgentDocs/** — Documentation on good System Dynamics modelling practice.
- `SDPrinciplesPractice.md` — Principles and practice of SD modelling: motivation, stocks/flows, feedback loops, behavior modes, rules of thumb, archetypes, modeling workflow, and model analysis/testing. A primary reference for students and agents.
- `SDModelCritique.md` — Keating (1999) framework for critiquing SD models: five phases (Analysis, Design, Formulation, Testing, Implementation) with checklists for boundary adequacy, units consistency, extreme conditions, parameter sensitivity, etc.
- `CALIBRATION_DECISIONS.md` — Teaching material on calibration: likelihood, priors, process noise, estimation strategies, and model checking.

**VensimAgentDocs/** — Reference documentation for Vensim-specific work.
- `EQUATIONS.md` — Vensim equation syntax
- `MDL.md` — .mdl file format overview and full settings block reference (entries 1–124)
- `SKETCH.md` / `NEWSKETCH.md` — V300 sketch format reference (corrected from official docs)
- `VENSIM.md` — Interacting with Vensim for testing and batch runs
- `FILES.md` — Vensim file types and conventions
- `CUSTOM.md` — Custom/advanced topics

**VensimUtilities/** — Reusable Python scripts and prompt guidelines for Vensim work.
- `generate_sketch.py` — Generate a V300 sketch from a .mdl or SD-JSON file and inject it into a .mdl. Usage: `python generate_sketch.py [--add] [input.json] model.mdl [output.mdl]`
- `translate_json_to_mdl.py` — Translate an SD-JSON model description to a Vensim .mdl. Usage: `python translate_json_to_mdl.py input.json output.mdl`
- `inspect_tab.py` — Summarise Vensim VDF2TAB output at landmark time points. Usage: `python inspect_tab.py file.tab [vars] [--times t1 t2 ...]`
- `render_diagram.py` — Render a model diagram to PNG using matplotlib.
- `PROMPT_TO_MDL.md` — Guidelines for building a .mdl interactively from a natural language prompt: elicitation questions, units conventions, MDL structure template, equation ordering, pre/post-run checklists.

**VentityAgentDocs/** — Reference documentation for Ventity-specific work. *(in preparation)*
- 'VENTITY.md' - Interaction with the Ventity .dll via Python, and Ventity model file structure

### Experiment workspaces

**Vensim claude test/** — Experiments translating SD-JSON and natural language prompts into Vensim .mdl models. Contains source models (`oak_squirrel.mdl`, `acorn_squirrel.mdl`), generated sketches, and Vensim batch test scripts.

**VentityDLLTest/** — Analogous experiments for Ventity. *(in preparation)*


## License

Copyright 2026 Ventana Systems, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
