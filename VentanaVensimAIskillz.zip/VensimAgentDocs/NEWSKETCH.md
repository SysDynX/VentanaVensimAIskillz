# Vensim .mdl Sketch Format — V301

This documents the V301 sketch format introduced in recent Vensim builds, as observed by
comparing `scirev7s - Copy.mdl` (V300) with `scirev7s - newformat.mdl` (V301, re-saved from
the same model). See SKETCH.md for the V300 format; this document covers only what changed.

## What Changed: Hash-Based Element Identity

The single structural change in V301 is that **sequential integer IDs are replaced by
40-character hex hashes** (SHA-1, 160-bit) for element identity and cross-references.

Everything else — overall file structure, view delimiters, the `$` font/color line, element
line field layout, shape codes, color format, waypoints — is **identical to V300**.

---

## Element IDs are always 0

In V300, each element had a unique integer ID within its view:
```
10,1,X,1742,765,40,20,3,3,...         ← stock X, ID=1
11,22,0,1613,770,6,8,34,3,...          ← valve, ID=22
12,19,48,1515,770,10,8,0,3,...         ← cloud, ID=19
```

In V301, the ID field (field 2) is always `0` for all element types:
```
10,0,X,1742,765,40,20,3,3,...          ← stock X, ID=0
11,0,0,1613,770,6,8,34,3,...           ← valve, ID=0
12,0,48,1515,770,10,8,0,3,...          ← cloud, ID=0
```

---

## Arrows use hashes instead of integer IDs

In V300, arrow from/to fields (fields 3 and 4) were integer IDs:
```
1,3,2,1,0,0,0,0,0,0,0,-1--1--1,,1|(0,0)|
  ↑  ↑ ↑
  id from to
```

In V301, those same fields are 40-character hex hashes:
```
1,0,3BE16695C5A870744447566D38A0586DA8453421,6F46C496C90F9B386FE37105CA0C49941A3458E9,0,0,0,0,0,0,0,-1--1--1,,1|(0,0)|
   ↑  ↑(from hash)                            ↑(to hash)
   id=0
```

All remaining arrow fields (polarity, style, thickness, arrowhead, color, waypoints) are
unchanged.

---

## Hash properties

- Each hash is a 40-character uppercase hexadecimal string (SHA-1)
- Each element instance gets a unique hash — multiple appearances of the same variable name
  (e.g., `SAP` appearing four times in a view) each have distinct hashes
- The hash is not stored in the element's own line — it exists only in the arrow lines that
  reference it; the mapping from element to hash is maintained internally by Vensim
- The hash algorithm is opaque; hashes are assigned by Vensim when creating or editing
  elements and are not derivable from the visible element fields alone

Verification: three TIME STEP instances in the Stock Structures view each appear with
different hashes in the arrows that reference them:
```
3BE16695C5A870744447566D38A0586DA8453421  ← TIME STEP at (1755,850)
334AC95C8B9A298FFED163D563B880A8FA611518  ← TIME STEP at (415,890)
6E4AF70B0EC17E09E3BF88E6662913F2D932ACEB  ← TIME STEP at (1625,620)
```

---

## Cloud ref_id field is unchanged

In both V300 and V301, cloud elements (type 12, shape 0) have `48` in field 3. This is
not a reference to another element — it is a constant present for all clouds in both
formats and does not change with the ID scheme:
```
V300:  12,19,48,1515,770,10,8,0,3,...
V301:  12,0,48,1515,770,10,8,0,3,...
```

---

## Summary of differences

| Aspect | V300 | V301 |
|---|---|---|
| Version tag | `V300` | `V301` |
| Element ID field (field 2) | Sequential integer, unique per view | Always `0` |
| Arrow from/to fields (fields 3–4) | Integer IDs matching element IDs | 40-char hex hashes |
| All other fields | — | Identical |
| `$` line format | — | Identical |
| Shape codes, colors, waypoints | — | Identical |

## Implications

- V301 files are not hand-editable for adding new arrows (the hash linking is opaque)
- V301 identifiers are stable across reordering and view merging operations (no integer
  counter to conflict)
- Parsing arrows requires maintaining a hash→element mapping built from file order or from
  Vensim's internal hash generation, which is not publicly documented
- The advisory "do not modify anything except names" remains appropriate for both formats


## License

Copyright 2026 Ventana Systems, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
