# Vensim Kalman Filter — Reference Documentation

Annotated guide to the Kalman filter feature in Vensim DSS, with ElkWolves worked examples.

Vensim Help references: `kalman-filtering.html`, `kalman_prm-format--keywords.html`, `ref_kalman.html`.
Online: `www.vensim.com/documentation/`

---

## Overview

The Vensim Kalman filter implements an **Extended Kalman Filter (EKF)** for state and parameter estimation in nonlinear SD models. It is activated during optimization (Powell or MCMC) by `SIMULATE>KALMAN|1` in the command script.

The filter operates at each observation time step:
1. **Predict**: advance model state and covariance using the linearized state transition (Jacobian of flows w.r.t. stocks)
2. **Update**: when data is available, compute the innovation (observed − predicted), update state toward observation, and update covariance
3. **Score**: add the log-likelihood of the innovation to the cumulative payoff

The result: model state trajectories are continuously nudged toward observations during integration, and the payoff is the full Kalman log-likelihood rather than a simple squared error.

---

## 1. Files Required for Kalman Calibration

| File | Role |
|------|------|
| `.mdl` (estimator) | Model with DETERMINISTIC=1; must have `M_KALMAN_PAYOFF` and `M_KALMAN_PARAMETER` in its sketch settings, or equivalently Kalman-compatible structure |
| `.prm` | Kalman filter settings and state/noise variance specification |
| `.vpd` | Must use `*CK` (or `*CKE`) payoff directives — not `*C` or `*CGL` |
| `.voc` | Standard optimizer control; payoff type and optimizer selection unchanged |
| `.lst` | Savelist for state variable trajectories (optional but recommended) |
| `.cmd` | Script with `SIMULATE>KALMAN|1` |

---

## 2. MDL Model Requirements

The estimator model must be structured for Kalman filtering:

### DETERMINISTIC=1

Flows must be continuous (not stochastic). The Kalman filter linearizes the flows to compute the Jacobian; stochastic flows do not have a stable Jacobian.

### Variance Model Variables

The model must define variables for the process noise (Q matrix) and measurement noise (R matrix) that evolve with the simulation state. These variable names are referenced in `kalman.prm`. Strictly, they can also be entered in the filter as numerical values, but using explicit variables makes them easier to document, change and estimate.

In ElkWolves:
```
Est Elk driving noise variance = Elk Driving Var * Est Elk driving noise scale
Est Wolf driving noise variance = Wolf Driving Var * Est Wolf driving noise scale
Est elk measurement var = MAX(unit elk, Elk) * Est Elk measurement var frac
Est wolf measurement var = MAX(unit wolf, Wolves) * Est Wolf measurement var frac
```

- `Est Elk driving noise variance` and `Est Wolf driving noise variance` → Q diagonal entries (referenced in `kalman.prm`)
- `Est elk measurement var` and `Est wolf measurement var` → R diagonal entries (referenced in `.vpd`)

### `:INTERPOLATE:` on Measurement Variables

Data variables in the estimator use `:INTERPOLATE:` rather than `RANDOM_POISSON` etc.:
```
Measured Elk:INTERPOLATE:
Measured Wolves:INTERPOLATE:
```
Vensim interpolates the external dataset onto the model time grid. `:NA:` values in the data are skipped (no update at that time step).

### `SIMULATION PAYOFF` and `SIMULATION WEIGHT`

The estimator includes:
```
SIMULATION PAYOFF=0
SIMULATION WEIGHT=1
```
These are Vensim hooks for the Kalman/MCMC payoff accumulation infrastructure. Both should be defined in the model; Vensim writes to them internally.

### `MAX THREADS`

For parallel MCMC chains:
```
MAX THREADS=16
```
This model variable tells Vensim how many CPU threads to use when running XParallel chains. Typically this can be omitted, and will be set to (number of physical cores)-2.

### Nonextinction and Variance Floor

In continuous (DETERMINISTIC=1) mode, state variables can drift near zero. A `unit elk == 1` / `unit wolf == 1` floor prevents the variance model from producing near-zero (or zero) variances that would cause numerical issues:
```
Est elk measurement var = MAX(unit elk, Elk) * Est Elk measurement var frac
Elk Driving Var = MAX(unit elk, Elk) * (...)
```
This parallels the structure in the generator model that prevents extinction of each species.

---

## 3. `.prm` File Format

The `.prm` file has two sections:
1. **Keyword flags**: `:KEYWORD=value` lines, one per setting
2. **Variance specification**: lines naming state variables with their process noise variables

### 3.1 Keyword Flags Reference

All flags are binary (0/1) unless noted. Default values from the Vensim Help are noted alongside each.

Normally there is no reason to change the defaults, and any or all of these can be omitted for simplicity. :DEBUG supplies useful diagnostic information if you have filter stability issues.

**Covariance matrix options:**

| Keyword | Default | Meaning when 1 |
|---------|---------|---------------|
| `:CNHTil=` | 0 | H (observation matrix) is constant; skip Jacobian update of H at each step |
| `:CNREswm=` | 0 | Residual weighting matrix is constant |
| `:CNRTil=` | 0 | R (measurement noise) is constant; skip re-evaluation of R each step |
| `:CNQTil=` | 0 | Q (driving noise) is constant; skip re-evaluation of Q each step |
| `:DIQTil=` | 0 | Q is diagonal (zero cross-covariances); saves computation |
| `:DIREswm=` | 0 | Residual weighting matrix is diagonal |
| `:DIRTtil=` | 0 | R is diagonal |
| `:IDFTil=` | 0 | F (state transition) is identity matrix |
| `:IDHTil=` | 0 | H (observation) is identity matrix |
| `:IDREswm=` | 0 | Residual weighting matrix is identity |
| `:IDRTil=` | 0 | R is identity matrix |

**Estimation mode:**

| Keyword | Default | Meaning |
|---------|---------|---------|
| `:LEAStsq=` | 0 | 1 = use least squares (sum of squared residuals); 0 = full FIML Kalman log-likelihood |
| `:STEAdy=` | 0 | 1 = assume filter reaches steady state at sample `:NSS=`; fix covariances after that |
| `:NSS=` | 1 | Sample number at which steady state is assumed (only used when STEAdy=1) |

**Whiteness test:**

| Keyword | Type | Meaning |
|---------|------|---------|
| `:LAGMax=` | integer | Maximum lag for autocorrelation whiteness test (typically 4) |
| `:NSDWt=` | float | Standard deviation threshold for whiteness test (typically 4.0) |

**Debug:**

| Keyword | Meaning |
|---------|---------|
| `:DEBUg` | Enable debug output (extra diagnostic info in log) |

### 3.2 Annotated ElkWolves `kalman.prm`

```
:CNHTil=0      # H is time-varying: EKF linearizes at each step (correct for nonlinear model)
:CNREswm=0     # Residual weighting matrix is time-varying
:CNRTil=0      # R is time-varying: measurement variance tracks state (Elk*frac)
:CNQTil=0      # Q is time-varying: driving variance tracks state (Poisson/Binomial formula)
:DIQTil=0      # Q is NOT forced diagonal — allows cross-covariance between species (though
               #   the variance spec has it commented out, leaving diagonal in practice)
:DIREswm=0     # Full residual weighting
:DIRTtil=0     # R is not forced diagonal (appropriate since each species is measured
               #   independently — effectively diagonal, but the flag doesn't hurt)
:IDFTil=0      # F is not identity: EKF computes full Jacobian of Lotka-Volterra flows
:IDHTil=0      # H is not identity: general observation model
:IDREswm=0     # Full residual weighting matrix
:IDRTil=0      # R is not identity
:LEAStsq=0     # Full FIML log-likelihood (not least squares)
:STEAdy=0      # No steady-state assumption; covariances evolve throughout simulation
:NSS=1         # (Unused since STEAdy=0)
:LAGMax=4      # Check autocorrelation at lags 1, 2, 3, 4
:NSDWt=4.0     # Flag autocorrelation exceeding 4 sigma
:DEBUg         # Debug mode on
```

**Variance specification** (after all keyword flags):
```
wolves/Est Wolf driving noise variance   # Q[wolf,wolf] = this model variable
elk/Est Elk driving noise variance       # Q[elk,elk] = this model variable
# wolves | elk / 1e-6                   # Cross-covariance (commented out → = 0)
```

The `levelName` on the left (`wolves`, `elk`) must match the INTEG variable name in the model — case-insensitive, spaces normalized, subscripts populated. The variable name on the right is evaluated from the running model at each time step.

Variances or covariances may be omitted, in which case default assumptions will be substituted.

### 3.3 Variance Spec Format Details

```
stateName/processNoiseVariable[/initialVariance]
stateName1|stateName2/covarianceVariable
```

- `stateName/var`: diagonal Q entry for this state
- `stateName/var/initVar`: initial covariance value (if not specified, Vensim initializes P from variance)
- `state1|state2/covar`: off-diagonal covariance entry (symmetric; specify once)

---

## 4. `.vpd` Directives for Kalman

Prior to version 10.5, when Kalman filtering is active, the payoff directives must use the `K` variants. However, as of 10.5, most distributions will be translated to a Gaussian approximation, so they can be used as convenient and interchanged with payoffs in Powell optimizations.

| Directive | Effect |
|-----------|--------|
| `*CK` | Full Kalman log-likelihood: updates state AND contributes to payoff |
| `*CKE` | Kalman update only: updates state (and its covariance) but does NOT add to payoff. Rarely useful. |
| `*CP` | Poisson approximation: uses Poisson-style log-likelihood (not Gaussian); for count data |
| `*CGX` | Gaussian, with scale parameter expressed as a fractional standard deviation, proportional to the data |

**`*CK`** format:
```
*CK
ModelState|DataVariable/VarianceVariable
```
- `ModelState`: the INTEG variable name (e.g., `Elk`, `Wolves`)
- `DataVariable`: the `:INTERPOLATE:` data variable (e.g., `Measured Elk`)
- `VarianceVariable`: model variable holding the measurement variance R entry at this observation

**`*CKE`** use case: want the Kalman filter to track wolf state (smoothing wolf trajectory) but don't trust wolf observations enough to include them in the likelihood. Example from `KalmanFit-ElkOnly.vpd`:
```
*CKE
Wolves|Measured Wolves/Est wolf measurement var
*CK
Elk|Measured Elk/Est elk measurement var
```

**`*CP`** (Poisson) from `KalmanFit-NKPapprox.vpd`:
```
*CP
Wolves|Measured Wolves/1
*CP
Elk|Measured Elk/1
```
Used when applying a Poisson log-likelihood directly rather than the Gaussian Kalman form. The weight is typically 1 (variance = mean, implicit in Poisson).

### Measurement Variance Variable

The variance variable in the `.vpd` entry should match R[i,i] for the corresponding observation. In ElkWolves, these are state-dependent:
```
Est elk measurement var = MAX(unit elk, Elk) * Est Elk measurement var frac
```
The `MAX()` ensures R is always at least `unit elk` (1 animal) even when continuous Elk → 0.

In other systems, where stocks and flows are less variable, constant variances may be fine.

---

## 5. Command Script Integration

### Basic Kalman Optimization

```
SIMULATE>RUNNAME|MyKalmanRun
SIMULATE>PAYOFF|KalmanFit.vpd
SIMULATE>KALMAN|1                       ! 1 = Kalman filter active
SIMULATE>OPTIMIZE|Parameters+Filter.voc
SIMULATE>DATA|"DataSparse.vdfx"         ! observed dataset; data might also originate from GET XLS DATA, GET DIRECT DATA or ODBC
MENU>RUN_OPTIMIZE|o
```

### Full MCMC with Kalman

```
SIMULATE>RUNNAME|MyMCMCRun
SIMULATE>PAYOFF|KalmanFit.vpd
SIMULATE>KALMAN|1
SIMULATE>OPTIMIZE|Parameters+Filter MC.voc   ! OPTIMIZER=MCMC, MULTIPLE_START=XParallel
SIMULATE>DATA|"DataSparse.vdfx"
MENU>RUN_OPTIMIZE|o
```

### Kalman Smoother (posterior trajectories)

After MCMC, use `SIMULATE>READCIN` to load best parameters and run the Kalman filter in forward-simulation mode to get state trajectories. If there are multiple change files, `SIMULATE>READCIN` for the first and `SIMULATE>ADDCIN` for additional entries:
```
SIMULATE>READCIN|Est-data-MCad-sparse.out
SIMULATE>KALMAN|1
SIMULATE>DATA|"DataSparse.vdfx"
SIMULATE>RUNNAME|KalmanSmooth
MENU>RUN|o
```
State trajectories saved via `SIMULATE>SENSSAVELIST|wolf elk state.lst`.

### Forward Simulation (no filter)

For sensitivity runs using MCMC posterior samples:
```
SIMULATE>READCIN|Est-data-MCad-sparse.out
SIMULATE>KALMAN|0                            ! 0 = filter off; model runs forward only
SIMULATE>PAYOFF|KalmanFit-NKPapprox.vpd     ! can use *CP for scoring without filter
SIMULATE>SENSITIVITY|posterior_sample.vsc
SIMULATE>SENSSAVELIST|wolf elk state.lst
MENU>RUN_SENSITIVITY|o
MENU>SENS2FILE|!|!|>T
```

---

## 6. `.lst` Savelist for State Trajectories

The `wolf elk state.lst` file specifies which variables to save during sensitivity/sensitivity-mode runs:
```
Elk
Wolves
```
These are the Kalman-tracked state variables. Including them in the savelist allows you to examine how the filter updates each species trajectory across MCMC posterior samples.

The savelist is referenced in the `.cmd` via:
```
SIMULATE>SENSSAVELIST|wolf elk state.lst
```

---

## 7. Kalman Filter Mechanics (Extended Kalman)

For reference and debugging, here is what the EKF does at each observation time `t`:

**Predict step** (between observations):
- Propagate state: `x̂⁻ = f(x̂, u)` (run model forward)
- Propagate covariance: `P⁻ = F·P·Fᵀ + Q`
  - `F` = Jacobian of flows w.r.t. stocks (linearized at current state)
  - `Q` = process noise covariance (from `kalman.prm` variance spec)

**Update step** (at each observation):
- Innovation: `ν = y − H·x̂⁻`  (observed minus predicted)
- Innovation covariance: `S = H·P⁻·Hᵀ + R`
- Kalman gain: `K = P⁻·Hᵀ·S⁻¹`
- Updated state: `x̂ = x̂⁻ + K·ν`
- Updated covariance: `P = (I − K·H)·P⁻`
- Log-likelihood contribution: `−½(νᵀ·S⁻¹·ν + log|S|)`

**Whiteness test**: After fitting, checks whether the sequence of innovations `{ν₁, ν₂, ...}` is autocorrelated. If the model is correctly specified, innovations should be white noise. Significant autocorrelation at lag k means the model structure is systematically missing something at time scale k·`SAVEPER`.

---

## 8. Practical Tips

**Start without the filter**: Use `Parameters.voc` (Powell, no Kalman, 6 params) to get dynamics parameters close before activating the Kalman filter. The filter can be sensitive to poor starting points because early innovations can overwhelm the covariance.

**Q and R scaling**: If optimization converges to extreme noise estimates (e.g., measurement var frac → 0 or → upper bound), check:
- Is the variance floor (`unit elk`, `unit wolf`) in place?
- Is the `LOGNORMAL` prior strong enough to prevent boundary solutions?
- Is the dataset long enough to identify both process and measurement noise?

**Process vs. measurement noise tradeoff**: These are often hard to identify separately (observational equivalence). More data, richer data (both species), and informative priors on the analytical Driving Var formula help. ElkWolves uses an analytically derived Q (Poisson/Binomial) rather than estimating Q from scratch — this strongly constrains the identification.

**`STEAdy=0` vs `STEAdy=1`**: For models with cyclic dynamics (like predator-prey), P never truly converges to steady state — the Jacobian changes throughout the cycle. Keep `STEAdy=0`. For models that quickly reach equilibrium, `STEAdy=1` saves computation.

---

## 9. Known Help Gaps

1. **Linear vs. nonlinear support**: The Help discusses EKF linearization but does not document which nonlinear function forms cause numerical instability in the Jacobian computation. Models with extreme IF-THEN-ELSE switches or discontinuities can produce degenerate Jacobians.

2. **`.prm` keyword naming**: The `.prm` keywords use abbreviated names (`CNHTil`, `DIQTil`, etc.) that are not obviously related to the Help documentation. The mapping is: `CN` = "constant", `DI` = "diagonal", `ID` = "identity", `Til` = "tilde" (the linearized matrix). The ElkWolves `kalman.prm` includes comments that explain each flag.

3. **Initial P (covariance) initialization**: The Help does not document how Vensim initializes the state covariance matrix P at t=0 when no `initVariance` is specified in the variance spec. Empirically, P is initialized from the process noise variance Q (reasonable default).

4. **`*CKE` vs. `*CK` distinction**: Documented in `extended_payoffs.html` but the description of what "excluded from likelihood" means precisely (update yes, score no) is only implicit.

5. **Kalman with MCMC chains**: Each XParallel chain runs an independent Kalman filter trajectory. The filter state is not shared between chains. This is correct behavior but is not stated explicitly in the Help.


## License

Copyright 2026 Ventana Systems, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
