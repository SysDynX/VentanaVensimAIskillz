# Vensim .mdl Sketch Format

This documents the sketch (diagram layout) section of Vensim `.mdl` files, as inferred from
the official documentation at https://www.vensim.com/documentation/ref_sketch_format.html
(which is incomplete and may be outdated) and from inspection of actual model files.

## Overall Structure

The sketch section is appended after all model equations. The file ends with `:GRAPH` data
after the sketch section.

```
\\\---/// Sketch information - do not modify anything except names
V300  Do not put anything below this section - it will be ignored
*ViewName
$<default font/color line>
<element lines...>
\\\---/// Sketch information - do not modify anything except names
V300  Do not put anything below this section - it will be ignored
*AnotherView
...
///---\\\              ← opens the custom-graph block (not a sketch end marker)
:GRAPH ...
:L<%^E!@              ← opens the settings block
```

- Each view begins with `\\\---/// Sketch information - do not modify anything except names`
- `V300` is the format version tag — still in use despite the docs saying it's for Vensim 3-5
- View name follows on the next line, prefixed with `*` (max 30 characters)
- There is **no explicit end-of-sketch delimiter**. Vensim recognises the end of the sketch
  section when it encounters `///---\\\` (custom-graph block), `:L<%^E!@` (settings block),
  or EOF — whichever comes first. All three are optional.
- `///---\\\` is the **opener of the custom-graph block**, not a sketch terminator
- IDs are per-view (each view has its own ID namespace starting at 1)

---

## Default Font/Color Line (`$`)

One per view, immediately after the view name line.

```
$192-192-192,0,Arial|10||0-0-0|0-0-0|0-0-255|-1--1--1|-1--1--1|96,96,100,0
```

| Position | Example | Meaning |
|---|---|---|
| 1 | `192-192-192` | Default arrow color (R-G-B) |
| 2 | `0` | Reserved — always 0 |
| 3 | `Arial\|10\|\|0-0-0` | Default font: `face\|size\|attributes\|color` |
| 4 | `0-0-0` | Default shape outline color |
| 5 | `0-0-255` | Default arrow color |
| 6 | `-1--1--1` | Default fill color (`-1--1--1` = none/transparent) |
| 7 | `-1--1--1` | Background color |
| 8 | `96,96` | Pixels per inch (x, y) |
| 9 | `100` | Zoom percentage |
| 10 | `0` | Template flag: `0`=normal, `1`=no template, `3`=template view |

### Color format
Colors are `R-G-B` with values 0–255. `-1--1--1` means none/transparent/default.

### Font attributes field
Empty string = normal. Characters from `BUSI`: B=bold, U=underline, S=strikethrough, I=italic.
Example: `|12|B|0-0-0` = size 12, bold, black.

---

## Element Lines

### Type `10` — Variable node

```
10,id,name,x,y,width,height,shape,??,vis,??,layer,0,0,0[,outline,text,font_override,0,0,0,0,0,0]
```

| Field | Meaning |
|---|---|
| 1 | `10` — element type |
| 2 | Element ID (unique within view) |
| 3 | Variable name |
| 4,5 | X, Y position (center of element) |
| 6,7 | Width, height |
| 8 | Shape code (see below) |
| 9 | Unknown |
| 10 | Visibility flag (0=hidden?, 2=normal?, 3=normal?) |
| 11 | Unknown |
| 12 | Layer (-1 = default layer) |
| 13–15 | Unknown (usually 0,0,0) |
| 16+ | Optional color/font overrides (see below) |

**Shape codes:**

| Code | Meaning |
|---|---|
| `3` | Stock (rectangle) |
| `8` | Auxiliary variable or constant (typically circle/oval) |
| `40` | Rate name label (the text label positioned below a flow valve) |

**Color/font override fields** (when present, replace the view defaults for this element):
```
128-128-128,0-0-0,|||128-128-128,0,0,0,0,0,0
```
- Field 1: Shape outline color
- Field 2: Text color
- Field 3: Font override in `|face|size|attributes|color` format (empty fields = use default)
- Remaining fields: unknown

Example — grayed-out input variable:
```
10,2,TIME STEP,1755,850,44,9,8,2,0,3,-1,0,0,0,128-128-128,0-0-0,|||128-128-128,0,0,0,0,0,0
```

---

### Type `11` — Flow valve

The pipe joint symbol at the center of a flow. Paired with a rate label (type `10`, shape `40`)
and two pipe arrows (type `1`, style `22`).

```
11,id,0,x,y,width,height,shape,??,??,??,orientation,0,0,0,...
```

| Field | Meaning |
|---|---|
| 1 | `11` — flow valve |
| 2 | Element ID |
| 3 | Unknown (always `0` in observed data) |
| 4,5 | X, Y position |
| 6,7 | Width, height |
| 8 | Shape code: `34`=standard valve, `33`=diagonal valve, `2`=small/circular valve |
| 12 | Orientation: `1`=horizontal flow, `4`=vertical flow |

---

### Type `12` — Special elements

Used for clouds (flow boundaries), graph panels, and text boxes. Meaning varies by shape/type_code.

```
12,id,ref_id,x,y,width,height,shape,type_code,0,0,subtype,0,...
[optional text on next line]
```

#### Cloud (flow source/sink)
```
12,19,48,1515,770,10,8,0,3,0,0,-1,0,0,0,...
```
- Shape `0`, type_code `3`
- `ref_id` (field 3) = **always `48`**, a constant — not the valve ID (confirmed by V301
  comparison in NEWSKETCH.md, where IDs change but this field stays `48`)
- No text on following line

#### Graph panel (in Control/dashboard views)
```
12,1,0,275,200,239,175,3,188,0,0,1,0,...
Practitioners
12,2,0,760,200,239,175,3,188,0,0,2,0,...
CDP,Graph
```
- Shape `3`, type_code `188`
- `ref_id` = 0
- `subtype` (field 12): `1` = appears to be a group/run selector (next line is the group/variable name); `2` = graph with specified type (next line is `variablename,GraphType`)
- Graph types seen: `Graph` (time series), `Gantt`

#### Text box
```
12,1,0,170,120,118,38,8,7,0,24,-1,0,0,0,-1--1--1,0-0-0,|12|B|0-0-0,...
Path Dependence, Competition, and Succession in the Dynamics of Scientific Revolution
```
- Shape `8`, type_code `7`
- Text content is on the following line

#### Hyperlink text box
```
12,5,0,170,400,65,14,8,135,0,18,-1,0,253,253,-1--1--1,0-0-0,||U|0-0-255,...
http://models.metasd.com|models.metasd.com
```
- Shape `8`, type_code `135`
- Next line: `url|display_text`
- Font override `||U|0-0-255` = underline, blue (typical hyperlink style)

---

### Type `1` — Arrow / connection

The field layout differs between causal arrows, flow pipes, and initial-value arrows.
All share fields 1–5 and the waypoint tail.

| Field | Meaning |
|---|---|
| 1 | `1` — arrow/connection |
| 2 | Element ID |
| 3 | Source element ID (or hash in V301) |
| 4 | Destination element ID (or hash in V301) |
| 5 | Polarity: `0`=none, `1`=positive, `-1`=negative; for pipes encodes direction (see below) |
| 6 | Unknown (always `0`) |
| 7 | `43` for causal arrows; `0` for pipes and initial-value arrows |
| 8 | Style: `0`=causal arrow, `22`=flow pipe |
| 9 | `1` for causal arrows; `0` for pipes |
| 10 | Line thickness: `64` for causal and initial-value arrows; `0` for pipes |
| 11 | Arrowhead: `0`=default; `1`=filled (used on initial-value arrows) |
| 12 | Color: `0-0-0` (black) for causal; `-1--1--1` (default) for pipes |
| 13 | Font spec for causal (`\|\|\|0-0-0`); empty for pipes |
| 14 | `1` (always) |
| 15+ | Waypoints: `\|(x,y)\|` per bend; `\|(0,0)\|` = straight line |

#### Causal arrows
Normal causal links between variables. Style `0`, field 7 = `43`, thickness = `64`.
```
1,27,23,7,0,0,43,0,1,64,0,0-0-0,|||0-0-0,1|(0,0)|   ← polarity 0 (none), straight
1,28,1,7,1,0,43,0,1,64,0,0-0-0,|||0-0-0,1|(406,332)| ← polarity 1 (+), curved
```

**Important for programmatic generation:** causal arrows that point *to* a flow should
target the flow's **rate label** (type `10`, shape `40`), not the valve (type `11`).
The rate label is what the user sees and clicks; the valve is the pipe graphic only.

#### Flow pipes
Flows use three connected elements: a valve (`11`), a downstream stock or cloud, and an
upstream cloud or stock. The pipe is two arrows that both originate from the valve:

| Field 5 value | Meaning |
|---|---|
| `4` | Downstream half — valve → sink (stock or cloud) |
| `100` | Upstream half — valve → source (stock or cloud) |

Both use style `22`, thickness `192`, color `-1--1--1`.

```
1,20,22,1,4,0,0,22,0,0,0,-1--1--1,,1|(1660,770)|   ← valve 22 → stock 1 (downstream)
1,21,22,19,100,0,0,22,0,0,0,-1--1--1,,1|(1566,770)| ← valve 22 → cloud 19 (upstream)
```

The waypoint is conventionally placed at the midpoint between the valve and its target.

#### Initial value arrows
Connections from initial-value constants to stocks. Style `0`, field 7 = `0`, thickness `64`,
arrowhead `1` (filled), color `-1--1--1`.
```
1,26,25,1,0,0,0,0,0,64,1,-1--1--1,,1|(0,0)|
```

---

---

## Programmatic Generation

### Use V300, not V301

V301 replaces integer IDs with opaque SHA-1 hashes assigned internally by Vensim.
There is no known way to derive or predict the hash for a new element without running Vensim.
**Always generate V300 sketches in code.** Vensim will convert to V301 on save if the user
opens the file in a version that defaults to V301, but that is fine.

### Default font/color line for generated sketches

Use all-transparent defaults so Vensim renders elements with its built-in defaults:
```
$-1--1--1,0,|12||-1--1--1|-1--1--1|-1--1--1|-1--1--1|-1--1--1|96,96,100,2
```

### ID assignment

In V300, IDs are sequential integers, unique within each view, starting from 1. Assign them
in element-definition order and track them in a dict keyed by variable name for later use in
arrow `from_id`/`to_id` fields.

### Flows need two IDs tracked

Each flow has two sketch elements that may be referenced by arrows:

| Element | Type | Shape | Used as arrow target by |
|---|---|---|---|
| Valve | `11` | `34` | Pipe arrows (`from_id` field) |
| Rate label | `10` | `40` | Causal arrows (`to_id` / `from_id` field) |

Causal arrows that reference a flow should point to the **rate label ID**, not the valve ID.
Pipe arrows use the **valve ID** as the `from_id` (source of both pipe halves).

### Element ordering within a flow block

The required ordering in observed files is:
1. Cloud element(s) (if applicable)
2. Upstream pipe arrow (`polarity=100`, from valve to source) — **FIRST**
3. Downstream pipe arrow (`polarity=4`, from valve to sink) — **SECOND**
4. Valve (`type 11`)
5. Rate label (`type 10`, shape `40`)

**Critical**: Arrow element IDs must be **lower** than the valve ID (i.e., arrows are
allocated and emitted before the valve). The arrows reference the valve ID before the
valve element is defined; Vensim resolves references by ID after reading the whole view.
To achieve this: compute the planned valve ID in advance as
`current_id + n_clouds + 2 + 1`, emit clouds and arrows (each consuming one ID), then
emit the valve last (receiving the pre-computed ID).

Violating either constraint (wrong arrow order, or valve ID lower than arrow IDs) causes
Vensim to silently discard the pipe structure on load and replace valves with plain ovals.

### Multiple outflows from the same stock

If a stock has two or more outflow flows each terminating in a cloud (no sink stock), placing
all their valves at the default "one CLOUD_GAP to the right" produces overlapping elements.
Spread them in different cardinal directions from the stock centre — e.g. right, down, left,
up for the first four.

### Causal arrows not in the relationships array

The JSON `relationships` array typically captures only the main structural causal connections.
Connections from parameter constants to the flows or auxiliaries they appear in are often
absent. Derive these by scanning each variable's `equation` field for references to other
named variables (trying both space and underscore forms of the name). Suppress any arrow
that is already shown by a flow pipe (stock→flow or flow→stock where the flow is in the
stock's `inflows`/`outflows` list).

### Python string literals for sketch delimiters

The sketch delimiters contain literal backslashes, which require care in Python string
literals (raw strings cannot end with an odd number of backslashes):

```python
SKETCH_START  = r'\\\---/// Sketch information - do not modify anything except names'
GRAPH_START   = '///---' + '\\\\\\'   # ///---\\\  — custom-graph block opener
                                       # There is NO sketch-end delimiter constant;
                                       # insert new sketches before GRAPH_START or ':L<%^E!@'
# NOTE: the settings marker contains a DEL byte (0x7f): ':L<%^E!@'
# Search for both forms; always write the DEL form to match Vensim's output.
```

---

## Notes and Uncertainties

- Field positions are 1-indexed throughout this document
- Type `10` fields confirmed from user-created test models (current Vensim): all normal
  elements use `f9=3, f10=0, f11=0, layer=-1` followed by 9 trailing zeros — no color
  overrides needed. Specifically:
  - Stocks: `shape=3, f9=3, f10=0, f11=0, layer=-1`, height=26
  - Auxiliaries/constants: `shape=8, f9=3, f10=0, f11=0, layer=-1`, height≈20
  - Rate labels: `shape=40, f9=3, f10=0, f11=0, layer=-1`, height=26
  - Shadow/system variables (grayed): `shape=8, f9=2, f10=0, f11=3, layer=-1` + color overrides `128-128-128,0-0-0,|||128-128-128,...`
- Cloud `ref_id` (field 3) is always `48` — confirmed by V301 comparison; the earlier
  hypothesis that it was the valve ID is incorrect
- Valve shape codes and dimensions confirmed from test models:
  - Horizontal valve (orient=1): `shape=34, w=6, h=8`
  - Vertical valve (orient=4): `shape=33, w=8, h=6`
  - Circular variant: shape=`2` (observed but not tested)
  - All use `f9=3, f10=0, f11=0` + 9 trailing zeros, no color overrides
- Pipe arrow thickness must be `192` (not `0`) — thickness=0 makes pipes invisible/missing
- Rate label Y offset below horizontal valve: 34 pixels; X offset right of vertical valve: ~64 pixels
- Causal arrow field 7 = `43` in all observed cases; meaning is unknown but it is required
  for correct rendering — arrows written with `0` in this field may display differently
- The `subtype` field in type `12` graph panels (`1` vs `2`) is inferred from context, not confirmed
- Observations come from `scirev7s - Copy.mdl`, `gen_prey_predator.mdl`,
  `gen_prey_predator-newsketch.mdl`, and `acorn_squirrel_sketch.mdl`


## License

Copyright 2026 Ventana Systems, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
