# Vensim Calibration — Workflow Overview

How the calibration system fits together: file types, workflow stages, and command reference.
The **ElkWolves** project (`VensimElkWolvesOpt/`) is used as the running example throughout.

**Detailed references** (read these after this overview):
- `VOC_VPD.md` — optimizer control (`.voc`) and payoff definition (`.vpd`) file formats
- `KALMAN.md` — Kalman filter (`.prm`) setup, EKF mechanics, Kalman-specific `.vpd` directives
- `SENSITIVITY.md` — sensitivity (`.vsc`) file format, MCMC posterior predictive runs, TAB export
- `VensimElkWolvesOpt/NOTES.md` — full project documentation, results, derivations

---

## 1. What Calibration Does in Vensim

Vensim calibration finds parameter values that maximize a **payoff** (log-likelihood or negative squared error) measuring agreement between model output and data.

Three components must always be specified:
1. **What to fit** — the payoff function (`.vpd`)
2. **What to vary** — the parameters, bounds, and priors (`.voc`)
3. **How to run it** — the command script (`.cmd`)

Optional but frequently used:
- **Kalman filter** (`.prm`) — state estimation alongside parameter estimation for stochastic models
- **Sensitivity** (`.vsc`) — posterior predictive runs, uncertainty visualization, data generation sweeps

---

## 2. The File Ecosystem

```
                    ┌─────────────────────────────────────────┐
                    │           .cmd script                   │
                    │  (orchestrates everything)              │
                    └──┬──────┬──────┬──────┬──────┬─────────┘
                       │      │      │      │      │
              LOADMODEL │  PAYOFF  OPTIMIZE KALMAN  SENSITIVITY
                       │      │      │      │      │
                       ▼      ▼      ▼      ▼      ▼
                     .mdl   .vpd   .voc   .prm   .vsc
                  (model) (what  (how   (filter (param
                          to fit) to opt) config) sweep)
                       │      │      │      │      │
                       └──────┴──────┴──────┴──────┘
                                    │
                              Optimization
                                    │
                              ┌─────┴──────┐
                              │   .out     │  (best parameters;
                              │   .tab     │   loadable as .voc)
                              │   .vdfx    │
                              └────────────┘

Data flow:
  Data (.vdfx/.tab) ──► .vpd references ──► payoff score
  .out ──READCIN──► model ──► warm-start next stage
  MCMC .out ──generates──► _MCMC_sample+blockN.vsc ──► sensitivity run
```

### File Types at a Glance

| Extension | Name | Role | Format |
|-----------|------|------|--------|
| `.mdl` | Model | SD model equations + sketch | Text (MDL format) |
| `.vpd` | Payoff Definition | Which variables to fit, how to weight | Text (directive + lines) |
| `.voc` | Optimizer Control | Method, bounds, priors, MCMC settings | Text (`:KEY=val` + param lines) |
| `.prm` | Kalman Parameter | Filter flags + process noise spec | Text (`:KEY=val` + state lines) |
| `.vsc` | Sensitivity Control | Parameter sweep distributions | Text (header + `Var=DIST(...)`) |
| `.lst` | Savelist | Which variables to save in sensitivity | Text (one var per line) |
| `.vdfx` | Data / Results | Simulation output or observed data | Binary |
| `.tab` | TAB Data | Tab-delimited data (import or export) | Text |
| `.out` | Optimization Output | Best-fit parameters after optimization | Text (valid `.voc` + `= value`) |
| `.cmd` | Command Script | Orchestration script | Text (`CATEGORY>COMMAND\|arg`) |

---

## 3. Three-Stage Workflow (ElkWolves)

Calibration proceeds in stages that trade speed for thoroughness. Each stage uses the output of the previous as its starting point.

### Stage 0 — Generate Synthetic Data

**Goal**: produce observed datasets with known ground truth for calibration testing.

**Model**: `Elk-Wolves kf gen 1c.mdl` (generator, `DETERMINISTIC=0`)

**Files**: `noise seed.vsc` (sweeps NOISE SEED 1–20), outputs → `Data*.vdfx`

```cmd
SPECIAL>LOADMODEL|Elk-Wolves kf gen 1c.mdl
SIMULATE>RUNNAME|DataGen
SIMULATE>SENSITIVITY|noise seed.vsc
MENU>RUN_SENSITIVITY|o
```

Produces multiple stochastic trajectories. Select representative datasets (full, short, sparse) for calibration experiments.

---

### Stage 1 — Powell: Dynamics Parameters Only

**Goal**: fast point estimate of the 6 core dynamics parameters; ignore noise structure for now.

**Files**: `Parameters.voc` (Powell, 6 params, 0 restarts), `KalmanFit.vpd` (or simpler `UnweightedFit.vpd` for speed), data `.vdfx`

**Key `.voc` settings**:
```
:OPTIMIZER=Powell
:MULTIPLE_START=Off
:RESTART_MAX=0
```

**Command pattern**:
```cmd
SPECIAL>LOADMODEL|Elk-Wolves kf est 1hb.mdl
SIMULATE>RUNNAME|Powell6
SIMULATE>PAYOFF|KalmanFit.vpd
SIMULATE>OPTIMIZE|Parameters.voc
SIMULATE>DATA|"DataSparse.vdfx"
MENU>RUN_OPTIMIZE|o
```

**Output**: `Powell6.out` — best-fit dynamics parameters; load with `READCIN` to warm-start Stage 2.

**Rationale**: Powell is fast (seconds to minutes). Starting with 6 rather than 11 parameters avoids identifiability problems early — noise parameters need a good dynamics fit before they can be estimated meaningfully.

---

### Stage 2 — Powell + Kalman: Full Parameter Set

**Goal**: refine estimate including 4 noise parameters and `Elk other mortality rate`; use Kalman filter likelihood.

**Files**: `Parameters+Filter.voc` (Powell, 11 params, 4 restarts), `KalmanFit.vpd` (`*CK`), `kalman.prm`

**Key `.voc` settings**:
```
:OPTIMIZER=Powell
:MULTIPLE_START=Off
:RESTART_MAX=4          ! 4 restarts to escape local optima
```

**Command pattern**:
```cmd
SIMULATE>RUNNAME|PowellKalman
SIMULATE>READCIN|Powell6.out            ! warm start from Stage 1
SIMULATE>PAYOFF|KalmanFit.vpd
SIMULATE>OPTIMIZE|Parameters+Filter.voc
SIMULATE>KALMAN|1                       ! activate Kalman filter
SIMULATE>DATA|"DataSparse.vdfx"
MENU>RUN_OPTIMIZE|o
```

**Output**: `PowellKalman.out` — best-fit 11 parameters; use as MCMC starting point.

**Rationale**: `RESTART_MAX=4` runs 5 total Powell optimizations from different starting points and keeps the best. Noise parameters (`Est Wolf/Elk measurement var frac`, `Est Wolf/Elk driving noise scale`) have a rougher likelihood surface than dynamics parameters, so multiple restarts help.

**XParallel Powell variant** (`Parameters+Filter XP.voc`): runs 32 restarts simultaneously across CPU threads. Better when compute is available and the surface is highly multimodal.

---

### Stage 3 — MCMC: Full Posterior

**Goal**: quantify parameter uncertainty; explore the posterior distribution; generate samples for predictive runs.

**Files**: `Parameters+Filter MC.voc` or `Parameters+Filter MC-ad.voc` (MCMC, 64 chains), `KalmanFit.vpd`, `kalman.prm`

**Key `.voc` settings**:
```
:OPTIMIZER=MCMC
:MULTIPLE_START=XParallel
:RESTART_MAX=64         ! 64 simultaneous chains
:MCLIMIT=32000          ! 32,000 iterations per chain
:MCBURNIN=30000         ! discard first 30,000
:MCDECIMATE=10          ! keep every 10th post-burnin draw
:MCSAMPLE=1000          ! target 1,000 posterior samples
```

**Command pattern**:
```cmd
SIMULATE>RUNNAME|MCMCRun
SIMULATE>READCIN|PowellKalman.out       ! warm start from Stage 2
SIMULATE>PAYOFF|KalmanFit.vpd
SIMULATE>OPTIMIZE|Parameters+Filter MC-ad.voc
SIMULATE>KALMAN|1
SIMULATE>DATA|"DataSparse.vdfx"
MENU>RUN_OPTIMIZE|o
```

**Output**:
- `MCMCRun.out` — best parameters (also readable as `.voc`)
- `MCMCRun_MCMC_sample+block0.vsc`, `+block1.vsc`, ... — posterior samples (for sensitivity)

**Rationale**: MCMC with 64 chains × 32K iterations generates a rich posterior sample even in 11D. Burn-in 30K/32K = 93.75% discarded — conservative, but ensures chains have mixed. The MC-ad version adds adaptive proposal covariance (`MCADAPT=0.1`) for better efficiency in high-dimensional problems.

---

### Stage 4 — Posterior Predictive Sensitivity

**Goal**: visualize prediction uncertainty by running the estimator forward with posterior parameter draws.

**Files**: `MCMCRun_MCMC_sample+blockN.vsc` (generated in Stage 3), `KalmanFit-NKPapprox.vpd`, `wolf elk state.lst`

**Command pattern**:
```cmd
SIMULATE>READCIN|MCMCRun.out            ! load best parameters
SIMULATE>KALMAN|0                       ! forward simulation (no filter update)
SIMULATE>PAYOFF|KalmanFit-NKPapprox.vpd
SIMULATE>DATA|"DataSparse.vdfx"
SIMULATE>RUNNAME|PostPred
SIMULATE>SENSITIVITY|MCMCRun_MCMC_sample+block1.vsc
SIMULATE>SENSSAVELIST|wolf elk state.lst
MENU>RUN_SENSITIVITY|o
MENU>SENS2FILE|!|!|>T
```

**Output**: TAB file with `Elk` and `Wolves` trajectories across 1000 posterior draws → uncertainty envelopes.

---

## 4. How Stages Connect

```
Stage 0       Stage 1         Stage 2           Stage 3           Stage 4
(Generate)    (Powell-6)      (Powell-11+KF)    (MCMC-64+KF)     (Posterior)

Data*.vdfx ──► Powell6.out ──► PowellKalman.out ──► MCMCRun.out ──► TAB uncertainty
                               (READCIN warm start) (READCIN warm start)  envelopes
                                                     │
                                                     └──► *_MCMC_sample+blockN.vsc
                                                              │
                                                              └──► Sensitivity run
```

Each `.out` file is also a valid `.voc`: it contains the complete optimizer configuration plus best parameter values. Loading it with `READCIN` sets parameter starting values for the next stage. The warm-start chain means each stage benefits from all prior computation.

---

## 5. Complete Command Reference

All commands used in calibration scripts:

### SPECIAL commands
| Command | Argument | Effect |
|---------|----------|--------|
| `SPECIAL>NOINTERACTION` | `1` | Suppress dialogs (required for batch) |
| `SPECIAL>CONTINUEONERROR` | `1` | Continue script after errors |
| `SPECIAL>LOADMODEL` | `filename.mdl` | Load model |

### SIMULATE commands
| Command | Argument | Effect |
|---------|----------|--------|
| `SIMULATE>RUNNAME` | `name` | Set output run name |
| `SIMULATE>PAYOFF` | `file.vpd` | Load payoff definition |
| `SIMULATE>OPTIMIZE` | `file.voc` | Load optimizer control |
| `SIMULATE>KALMAN` | `0` or `1` | Disable/enable Kalman filter |
| `SIMULATE>DATA` | `"file.vdfx"` | Load observed dataset (quotes required for spaces) |
| `SIMULATE>READCIN` | `file.out` | Load parameter values (CIN = constant input) |
| `SIMULATE>SENSITIVITY` | `file.vsc` | Load sensitivity control |
| `SIMULATE>SENSSAVELIST` | `file.lst` | Savelist for sensitivity output |
| `SIMULATE>REPORT` | `0` or `1` | Enable/disable payoff report output |

### MENU commands
| Command | Argument | Effect |
|---------|----------|--------|
| `MENU>RUN` | `o` | Run single simulation (overwrite) |
| `MENU>RUN_OPTIMIZE` | `o` | Run optimization |
| `MENU>RUN_SENSITIVITY` | `o` | Run sensitivity |
| `MENU>SENS2FILE` | `name\|set\|>T` | Export sensitivity output to TAB |
| `MENU>EXIT` | — | Exit Vensim |

**Notes**:
- `o` flag = overwrite existing output without dialog
- `MENU>RUN_SENSITIVITY|o` and `MENU>SENS2FILE|!|!|>T` can be written on the same line (no separator needed) — Vensim parses them as separate commands
- `SIMULATE>DATA` quotes are required when the filename contains spaces

---

## 6. Output Files After Calibration

### `.out` File

The primary output of any optimization run. Structure:

```
:COMSYS After N simulations
:COMSYS Best payoff is -177.413
:COMSYS Normally terminated optimization
:OPTIMIZER=MCMC
... [all :KEY=value settings from the .voc, possibly updated]
:MCADAPT=0.05        [settings that were auto-updated]
:MCDECIMATE=10
:MCSAMPLE=1000
0 <= Parameter Name = BestValue <= upper
...
```

Key points:
- `After N simulations`: total function evaluations across all chains/restarts
- `Best payoff is X`: the maximum log-likelihood achieved (more negative = worse for minimization, more positive = better for maximization — Vensim maximizes)
- `Normally terminated`: converged to tolerance; `Abnormally terminated` means hit iteration limit
- Parameter lines with `= BestValue`: the point estimate for each parameter
- All `:KEY=val` lines: can differ from input `.voc` if adaptive settings were updated

**Loading an `.out`**:
```cmd
SIMULATE>READCIN|MCMCRun.out    ! sets parameters to BestValue
```
This sets model constants to the best-fit values. The optimizer settings in the `.out` are ignored by `READCIN` (they only matter if you use the `.out` as a `.voc` with `SIMULATE>OPTIMIZE`).

### `_MCMC_sample+blockN.vsc` Files

Posterior sample files generated automatically by MCMC when `MCDECIMATE` and `MCSAMPLE` are set. Each block covers a segment of the post-burnin chain. Block 0 = earliest post-burnin samples; block N = latest. Multiple blocks enable convergence checking:

```
! Compare block 0 vs block 1 output distributions
! If they differ substantially → chain hasn't mixed yet
```

### TAB Export (from `SENS2FILE`)

Wide-format text:
```
Time    0    0.125    ...    100
Elk    100    102    ...    12
Wolves    10    10    ...    8
```

One block per sensitivity run, separated by blank lines (or all runs concatenated depending on Vensim version).

### `command.log`

Always check after any run. Optimization-specific indicators:
- `INFO: sim <runname>` — each simulation within the optimizer
- `INFO: Optimization completed` — optimizer finished
- No `sim` lines at all → optimizer may have failed to start (check for model errors before the optimizer runs)

For full log parsing reference, see `VENSIM.md`.

---

## 7. Payoff Sign Convention

Vensim **maximizes** the payoff. The Kalman log-likelihood is negative (log of a probability density < 1), so:
- Best payoff = largest (least negative) number
- `Best payoff is -177.413` means the Kalman log-likelihood at the best fit is −177.413
- More observations → more negative (each observation contributes a negative term)
- Comparing payoffs between datasets of different size or duration requires normalization

For minimization problems (sum of squared errors), use negative signs in the `.vpd` — Vensim maximizes `−SSE`.

---

## 8. Choosing `.vpd` Payoff Type

Quick decision guide:

| Situation | Directive | File |
|-----------|-----------|------|
| Stochastic model, process + measurement noise, filter active | `*CK` | `KalmanFit.vpd` |
| Want Kalman state tracking but exclude one variable from likelihood | `*CKE` for that variable | `KalmanFit-ElkOnly.vpd` |
| Count data (Poisson), no filter | `*CP` | `KalmanFit-NKPapprox.vpd` |
| Multiplicative errors, log-scale | `*CGL` | `LogWeightedFit.vpd` |
| Simple baseline, equal weighting | `*C` | `UnweightedFit.vpd` |

Full directive reference in `VOC_VPD.md §6`.

---

## 9. Choosing Optimizer

| Situation | Optimizer | `.voc` setting |
|-----------|-----------|---------------|
| Quick point estimate, smooth likelihood | Powell | `:OPTIMIZER=Powell` |
| Rough surface or many local optima | Powell + `RESTART_MAX=4+` | `:MULTIPLE_START=Off` |
| Multi-core Powell exploration | XParallel Powell | `:MULTIPLE_START=XParallel` |
| Full posterior, uncertainty quantification | MCMC | `:OPTIMIZER=MCMC` |
| MCMC, many cores available | XParallel MCMC | `:OPTIMIZER=MCMC` + `:MULTIPLE_START=XParallel` |

Always use Powell first to find a good starting point, then MCMC for the posterior. See `VOC_VPD.md §2–3` for full setting reference.

---

## 10. Minimal Working Example

The smallest possible Kalman calibration (no warm-start, single Powell pass):

**`KalmanFit.vpd`**:
```
*CK
Elk|Measured Elk/Est elk measurement var
*CK
Wolves|Measured Wolves/Est wolf measurement var
```

**`simple.voc`**:
```
:OPTIMIZER=Powell
:SENSITIVITY=Off
:MULTIPLE_START=Off
:MAX_ITERATIONS=500
:RESTART_MAX=0
0<=Reference wolf growth rate<=1
0<=Elk fractional growth rate alpha<=1
0<=Wolf mortality rate<=1
0.01<=Est Elk measurement var frac<=2,LOGNORMAL(1,1)
0.01<=Est Wolf measurement var frac<=2,LOGNORMAL(1,1)
```

**`simple.cmd`**:
```
SPECIAL>NOINTERACTION|1
SPECIAL>LOADMODEL|Elk-Wolves kf est 1hb.mdl
SIMULATE>RUNNAME|SimpleKalman
SIMULATE>PAYOFF|KalmanFit.vpd
SIMULATE>OPTIMIZE|simple.voc
SIMULATE>KALMAN|1
SIMULATE>DATA|"Data.vdfx"
MENU>RUN_OPTIMIZE|o
MENU>EXIT
```

**`kalman.prm`** (as in project).

Run: `vendss64MC.exe simple.cmd -log`

---

## 11. Help File Index

| Topic | HTML file | Key content |
|-------|-----------|-------------|
| Optimization control | `optimizationcontrol.html` | All `:KEY=val` settings, prior syntax |
| Optimization options | `optimizationoptions.html` | Powell, MCMC algorithm details |
| Payoff computation | `payoffcomputation.html` | `*C`, `*CGL` directives, weight expressions |
| Extended payoffs | `extended_payoffs.html` | `*CK`, `*CKE`, `*CP` Kalman directives |
| Extended payoff reporting | `extended_payoff_reporting.html` | What the payoff report contains |
| MCMC | `mcmc.html` | MCMC overview and algorithm |
| MCMC options | `mcmc_options.html` | All `:MC*=` settings |
| MCMC output | `mcmc_output.html` | `.out` file format, posterior `.vsc` files |
| MCMC sensitivity analysis | `mcmc_sa.html` | Posterior predictive run workflow |
| Kalman filtering | `kalman-filtering.html` | EKF theory, model requirements |
| Kalman `.prm` format | `kalman_prm-format--keywords.html` | All `.prm` keywords |
| Kalman reference | `ref_kalman.html` | `.cmd` commands for Kalman runs |
| Sensitivity control | `sensitivitycontrol.html` | `.vsc` format, header fields |
| Sensitivity parameters | `ksensitivity_control_parameters.html` | All sensitivity control parameters |
| Sensitivity distributions | `sensitivitydistributions.html` | VECTOR, UNIFORM, NORMAL, PERT, etc. |
| Sensitivity | `sensitivity.html`, `sensitivity2.html` | Sensitivity overview and workflow |
| Payoff sensitivity | `payoff_sensitivity.html` | Payoff-threshold sensitivity (`:SENSITIVITY=Payoff Value=`) |

All available online at `www.vensim.com/documentation/` and (in some Vensim installs) locally.
Our annotated notes on each topic:
- Optimization + MCMC + payoff → `VOC_VPD.md`
- Kalman filter → `KALMAN.md`
- Sensitivity → `SENSITIVITY.md`

---

## 12. Common Mistakes and Fixes

| Symptom | Likely cause | Fix |
|---------|-------------|-----|
| Optimizer starts but payoff never improves | Poor starting point; noise parameters at bounds | Run Powell-6 first; check variance floor in model |
| MCMC chains don't mix (R-hat >> 1) | Burn-in too short; `MCJUMP` too small | Increase `MCBURNIN`; tune `MCJUMP` toward 0.2–0.4 acceptance |
| All sensitivity runs identical | `READCIN` loaded a fixed parameter set; sensitivity spec not picked up | Check `SIMULATE>SENSITIVITY` is in the script before `RUN_SENSITIVITY` |
| `*CK` payoff returns zero | Kalman filter not activated (`KALMAN|0`) | Add `SIMULATE>KALMAN|1` before `RUN_OPTIMIZE` |
| Optimization completes instantly with bad payoff | `.vpd` data variable is all `:NA:` | Check `SIMULATE>DATA` points to correct `.vdfx` and data variable names match |
| `command.log` shows no `sim` lines | Model failed to load (check `BEGIN_LOADMODEL` errors) | Fix model errors; see `VENSIM.md` for log parsing |
| `Est **** var frac` estimate hits upper bound | Prior too weak; data insufficient to identify noise | Tighten `LOGNORMAL` prior; add more/better data |


## License

Copyright 2026 Ventana Systems, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
