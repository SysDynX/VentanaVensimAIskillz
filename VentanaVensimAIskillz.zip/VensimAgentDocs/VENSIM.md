# Vensim Release Build Command Line Guide

## Overview

This guide covers running Vensim models non-interactively via command scripts using the release
build (`vendss64MC.exe`) and interpreting the resulting `command.log`. For debug build behavior
and additional developer context, see `CLAUDE.md`.

Models in the Vensim `.mdl` file format are text-based and easy to inspect. Binary formats
(`.vmfx`, `.vpmx`, and legacy `.vmf`, `.vpm`) can also be run but cannot be easily edited as text.

The `.mdl` format is described in `MDL.md` including equation syntax in `EQUATIONS.md`.
Sketch/diagram layout is covered in `SKETCH.md` (V300) and `NEWSKETCH.md` (V301). Custom
graphs, tables, and reports are documented in `CUSTOM.md`. Supporting files are listed in `FILES.md`.

## How to Run

### Prerequisites

The Vensim DSS release build (`vendss64MC.exe`) must be in the system PATH or referenced by full
path. The standard installed location is `C:\Program Files\Vensim\vendss64MC.exe`.

### Basic Usage

```
cd <directory containing .cmd and .mdl files>
vendss64MC.exe "scriptname.cmd" -log
```

This runs the Vensim command script and writes results to `command.log` in the working directory.

### Known Issues

- **Exit codes:** The release build returns exit code 0. Do not rely solely on exit code; always
  parse `command.log` for results.
- **Repeated output:** Some errors and warnings are reported multiple times — once per command
  that touches the model (`LOADMODEL`, `RUNNAME`, `RUN`).
- **No `Simulation took` timing:** The release build does not emit a `Simulation took N seconds`
  line. To confirm simulation completed, look for `sim  <runname>` in INFO lines.
- **No `MISSING_UNITS` warnings:** The `MISSING_UNITS:` log lines are not emitted by the release
  build. Unit errors still appear as `ERROR:` lines (see below).

### Build Compatibility Note

Several log improvements are included in current builds and will be present in upcoming releases:

| Feature | Status |
|---|---|
| Syntax error detail (equation text, caret, line number) | Current release |
| Unit checking output (`ERROR:  No units specified`, `Error in units...`) | Current release |
| `BEGIN_LOADMODEL`/`END_LOADMODEL` and `BEGIN_UNITS_CHECK`/`END_UNITS_CHECK` block delimiters | Next release |
| `WARNING:` prefix for `Continuing command script` (instead of `ERROR:`) | Next release |
| `STOP:  Checking a macro call for a missing variable` (instead of "culled variable") | Next release |

This guide documents the next-release behavior throughout. Older builds may lack block delimiters,
use `ERROR:` instead of `WARNING:` for CONTINUEONERROR continuation, and say "culled variable"
instead of "missing variable".

## Files

### Command Scripts (.cmd)

Vensim command scripts use the format `CATEGORY>COMMAND|argument`. Key commands:

| Command | Purpose |
|---|---|
| `SPECIAL>NOINTERACTION\|1` | Suppress interactive dialogs (required for command line use) |
| `SPECIAL>CONTINUEONERROR\|1` | Continue script execution after errors instead of stopping |
| `SPECIAL>LOADMODEL\|filename.mdl` | Load a Vensim model (local filename or full path) |
| `SIMULATE>RUNNAME\|name` | Set the simulation run name |
| `MENU>RUN\|o` | Execute the simulation (`o` = overwrite existing output) |
| `MENU>EXIT` | Exit Vensim |

### Test Scripts

- **`RunCopyForAi.cmd`** — Runs the good model (`scirev7s - Copy.mdl`). Should complete with only
  USE FLAG warnings.
- **`RunCopyForAiBroken.cmd`** — Runs the broken model (`scirev7s - Broken.mdl`). Uses
  `CONTINUEONERROR` to proceed past simulation failure.
- **`RunFixedForAi.cmd`** — Runs the fixed model (`scirev7s - Fixed.mdl`). Should complete
  successfully.

### Models (.mdl)

- **`scirev7s - Copy.mdl`** — Working model. "Path Dependence, Competition and Succession in the
  Dynamics of Scientific Revolution" (Sterman & Wittenberg, 1999). Simulates successfully.
- **`scirev7s - Broken.mdl`** — Same model with intentional errors that prevent simulation.
- **`scirev7s - Fixed.mdl`** — Broken model repaired. Simulates successfully.
- **`scirev7s.mdl`** — Original model file.

### Output Files

- **`command.log`** — Written by Vensim when `-log` is used. Contains INFO, ERROR, WARNING,
  USE FLAG, and STOP messages from the run.
- **`.vdfx`** — Vensim simulation output data files.
- **`.tab`** — Tab-delimited data source or export files.

## Parsing command.log

Log lines are prefixed with a category tag:

| Prefix | Meaning |
|---|---|
| `INFO:` | Informational messages (command execution, simulation progress) |
| `ERROR:` | Model errors, unit errors, or failed commands (see below to distinguish) |
| `WARNING:` | Non-fatal notices (e.g., `Continuing command script` when CONTINUEONERROR is set) |
| `USE FLAG:` | Variables defined but not used in the model |
| `STOP:` | Unit error count summary or macro variable diagnostic |
| `NOT DEFINED:` | Variable used but not defined, assumed exogenous |
| `BEGIN_LOADMODEL` / `END_LOADMODEL` | Block delimiters wrapping all output from model parsing |
| `BEGIN_UNITS_CHECK` / `END_UNITS_CHECK` | Block delimiters wrapping all unit check output |

### Determining Success

Since exit codes are not fully reliable, parse `command.log`:

- **Simulation completed:** Look for `INFO:        sim  <runname> -w .` — this confirms the
  simulation ran.
- **Model-breaking errors:** `ERROR:` lines **inside `BEGIN_LOADMODEL`/`END_LOADMODEL`** with
  patterns like `Incomplete equation`, `Syntax error`, `Not able to analyze model`, `Unable to
  understand the right hand side`, `Missing right hand parenthesis`, `Expected a name or a valid
  expression`. These prevent simulation.
- **Unit errors (non-blocking):** All `ERROR:` lines **inside `BEGIN_UNITS_CHECK`/`END_UNITS_CHECK`**
  are unit errors only — they do **not** prevent simulation. `STOP:  N unit error(s) discovered.`
  summarizes these.
- **Script-level failures:** `ERROR:  Error executing command script at line N: ...` (outside the
  blocks) indicates a script command failed — usually a consequence of model errors.
- **CONTINUEONERROR continuation:** `WARNING:  Continuing command script (CONTINUEONERROR has been
  set to 1.` is normal when `CONTINUEONERROR` is set; it is not a model error.
- **Macro variable diagnostic:** `STOP:  Checking a macro call for a missing variable -
  #ADA>POS>POSKY#.` identifies a macro internal variable that could not be resolved during unit
  checking (inside `BEGIN_UNITS_CHECK`). Does not prevent simulation.
- **Success:** `sim  <runname>` appears in INFO and no model-breaking `ERROR:` lines exist inside
  `BEGIN_LOADMODEL`/`END_LOADMODEL`.

### Distinguishing unit errors from model errors (older builds without block delimiters)

In builds that lack `BEGIN_LOADMODEL`/`END_LOADMODEL` delimiters, both unit errors and model
errors appear as `ERROR:` lines without structural separation. Distinguish by error text pattern:

| Pattern | Type | Blocks simulation? |
|---|---|---|
| `ERROR:  No units specified for - VARNAME` | Unit error | No |
| `Error in units for the following equation:` | Unit error (multi-line block) | No |
| `STOP:  N unit error(s) discovered.` | Unit error summary | No |
| `STOP:  Checking a macro call for a missing variable` | Macro diagnostic | No |
| `ERROR:       Incomplete equation for - VARNAME` | Model error | Yes |
| `ERROR:       Syntax error.` | Model error | Yes |
| `ERROR:       Not able to analyze model.` | Model error | Yes |
| `ERROR:       Unable to understand the right hand side` | Model error | Yes |
| `ERROR:       Missing right hand parenthesis.` | Model error | Yes |
| `ERROR:       Expected a name or a valid expression.` | Model error | Yes |
| `ERROR:       Error executing command script at line N:` | Script failure (consequence) | — |
| `ERROR:       Continuing command script (CONTINUEONERROR` | Script continuation | No |

Note: unit error `ERROR:` lines use two spaces after the colon (`ERROR:  No units`), while model
error lines use many spaces (`ERROR:       Incomplete equation`). This is a reliable secondary
distinguisher.

### Example Successful Log (release build)

```
INFO:        Loaded multi-core engine from C:\Program Files\Vensim\VengineLib.dll.
INFO:        Executing: SPECIAL>NOINTERACTION|1, line number 1.
INFO:        Executing: SPECIAL>LOADMODEL|...\scirev7s - Fixed.mdl, line number 3.

BEGIN_LOADMODEL

USE FLAG:    -#CX>001CLIP#- is not used in the model.
USE FLAG:    -#CX>002CLIP>CLIP#- is not used in the model.
...
USE FLAG:    -TTPAMAX- is not used in the model.

END_LOADMODEL


BEGIN_UNITS_CHECK

***********************************************
ERROR:  No units specified for - #CX>001CLIP#
#CX>001CLIP#.

***********************************************
Error in units for the following equation:
DCE[PM]  =
P[PM]
DCE  --> Persons/Year
P  --> Persons

Analysis of units error:
Right hand and left hand units do not match
Right hand and left hand units do not match.
DCE[PM]
Has Units: Person/Year
P[PM]
Has Units: Person

***********************************************
ERROR:  No units specified for - NOISE SEED
NOISE SEED.
STOP:        8 unit error(s) discovered.

END_UNITS_CHECK

INFO:        Executing: SIMULATE>RUNNAME|Test, line number 4.
INFO:        Executing: MENU>RUN|o, line number 5.
INFO:        ---------------------------------.
INFO:        sim  Test -w .
INFO:        .
INFO:        Executing: MENU>EXIT, line number 6.
```

USE FLAG warnings appear inside `BEGIN_LOADMODEL`/`END_LOADMODEL`. Unit errors appear inside
`BEGIN_UNITS_CHECK`/`END_UNITS_CHECK` and do not prevent the simulation. The `sim  Test -w .`
line confirms the simulation ran. No `Simulation took` timing line appears in release builds.

### Example Error Log (release build, broken model)

```
INFO:        Loaded multi-core engine from C:\Program Files\Vensim\VengineLib.dll.
INFO:        Executing: SPECIAL>NOINTERACTION|1, line number 1.
INFO:        Executing: SPECIAL>CONTINUEONERROR|1, line number 3.
INFO:        Executing: SPECIAL>LOADMODEL|...\scirev7s - Broken.mdl, line number 5.

BEGIN_LOADMODEL

ERROR:       Output for MACRO POS is never defined.
ERROR:       Syntax error.
             :END OF MACRO:
.
             --------------^.
             Line 16 of file ...\scirev7s - Broken.mdl.
ERROR:       MACRO Definition error - see error window.
             :END OF MACRO:
.
             --------------^.
             Line 22 of file ...\scirev7s - Broken.mdl.
ERROR:       Unable to understand the right hand side of this equation.
             	~	 [1,1000,1]
.
             --^.
             Line 25 of file ...\scirev7s - Broken.mdl.
ERROR:       Missing right hand parenthesis.
             NP=INITIAL(ELMCOUNT(PM))* 357
.
             -------------------------^.
             Line 69 of file ...\scirev7s - Broken.mdl.
ERROR:       Expected a name or a valid expression.
             LSEED=1234//
.
             ------------^.
             Line 74 of file ...\scirev7s - Broken.mdl.
ERROR:       Missing a closing parenthesis on a lookup table call.
             	SPA*CLIP(0,CLIP(CLIP(1,0,X["N-1"],1),0,PA,RND),X[N],1)
.
             ------------^.
             Line 193 of file ...\scirev7s - Broken.mdl.
ERROR:       Incomplete equation for - DCE.
USE FLAG:    ...
ERROR:       Not able to analyze model.

END_LOADMODEL


BEGIN_UNITS_CHECK

ERROR:  No units specified for - #ADA>POS#
...
STOP:        Checking a macro call for a missing variable - #ADA>POS>POSKY#.
...
STOP:        8 unit error(s) discovered.

END_UNITS_CHECK

ERROR:       Error executing command script at line 5: SPECIAL>LOADMODEL|...
WARNING:     Continuing command script (CONTINUEONERROR has been set to 1.
INFO:        Executing: SIMULATE>RUNNAME|Test, line number 7.
ERROR:       Incomplete equation for - DCE.
...
ERROR:       Error executing command script at line 7: SIMULATE>RUNNAME|Test..
WARNING:     Continuing command script (CONTINUEONERROR has been set to 1.
INFO:        Executing: MENU>RUN|o, line number 9.
ERROR:       Error executing command script at line 9: MENU>RUN|o..
WARNING:     Continuing command script (CONTINUEONERROR has been set to 1.
INFO:        Executing: MENU>EXIT, line number 11.
```

Key observations:
- Syntax errors inside `BEGIN_LOADMODEL` include equation text, a caret (`^`), and `.mdl` line number
- All `ERROR:` lines inside `BEGIN_UNITS_CHECK`/`END_UNITS_CHECK` are unit errors — they do not
  prevent simulation
- `STOP:  Checking a macro call for a missing variable - #ADA>POS>POSKY#.` identifies the context:
  `ADA` is the calling variable, `POS` is the macro name, `POSKY` is the missing internal variable
- `WARNING:  Continuing command script` is normal when CONTINUEONERROR is set — not a model error
- `ERROR:  Error executing command script` is a consequence of model errors failing a command
- No `sim  <runname>` line — simulation did not run

## Syntax Error Types

| Error message | Meaning |
|---|---|
| `Output for MACRO POS is never defined` | Macro is named POS (from `:MACRO:` tag) but no variable inside has that name to provide a return value |
| `Syntax error` / `MACRO Definition error` | Macro definition has structural problems at `:END OF MACRO:` |
| `Unable to understand the right hand side` | RHS is missing or unparseable (e.g., `A FUNCTION OF` stub with no real equation) |
| `Missing right hand parenthesis` | Expression continues past the closing `)` — `INITIAL()` must be the outermost call on the RHS, so `INITIAL(ELMCOUNT(PM))* 357` fails because `* 357` is outside |
| `Expected a name or a valid expression` | Invalid syntax in equation (e.g., `LSEED=1234//` has a trailing `//` operator) |
| `Missing a closing parenthesis on a lookup table call` | Mismatched parentheses in nested function calls |

## Fixing Models from Log Output

### What the log tells you

`ERROR:       Incomplete equation for - <variable>` identifies which variables have problems.
Syntax error detail (equation text, line number, caret) pinpoints the exact location, making it
feasible to diagnose and fix model errors directly from the log.

### The `A FUNCTION OF` pattern

When a Vensim GUI user changes an equation's dependencies without editing the equation itself,
Vensim inserts a placeholder:

```
VARIABLE=A FUNCTION OF(dependency1,dependency2) ~~|
```

This is not valid equation syntax — it marks the equation as needing completion. After adding or
revising the correct equation, the `A FUNCTION OF` line must be deleted.

In the broken model:
- **NOISE SEED:** An `A FUNCTION OF` stub was inserted before the real definition, creating a
  duplicate. The real definition was also missing its RHS value (the constant `1`).
- **DCE:** An `A FUNCTION OF` stub was inserted before the real equation, which had a trailing
  `*` operator making it an incomplete expression.

### How to fix

1. Find the variables named in `ERROR:       Incomplete equation for - <variable>` lines
2. Search the `.mdl` for those variable names at the start of a line
3. Remove any `A FUNCTION OF` stub lines — these are always invalid and must be deleted
4. Fix the remaining equation — restore missing RHS values, remove trailing operators (a
   known-good copy of the model or knowledge of the intended equation is needed, since the log
   does not provide the correct value)

## For AI Agents

When working with these files:
1. Always run from the directory containing the `.cmd` and `.mdl` files
2. Use a timeout of at least 120 seconds for simulation runs; more for optimization, MCMC, and
   sensitivity runs
3. Parse `command.log` for results, not stderr
4. Look for `ERROR:` lines **inside `BEGIN_LOADMODEL`/`END_LOADMODEL`** to identify model-breaking
   errors; all `ERROR:` lines inside `BEGIN_UNITS_CHECK`/`END_UNITS_CHECK` are unit errors only
5. In older builds without block delimiters, distinguish by error text: `ERROR:  No units specified`
   and `Error in units for the following equation:` are unit errors; `ERROR:       Incomplete
   equation`, `Syntax error`, `Not able to analyze model` etc. are model-breaking
6. `WARNING:  Continuing command script` is normal with `CONTINUEONERROR` set — not a model error
7. Confirm simulation ran by looking for `sim  <runname>` in INFO lines (no `Simulation took`
   timing in release builds)
8. USE FLAG warnings are informational and do not prevent simulation


## License

Copyright 2026 Ventana Systems, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
