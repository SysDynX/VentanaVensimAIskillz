# Vensim Sensitivity Analysis — Reference Documentation

Annotated guide to Vensim sensitivity and Monte Carlo sampling, with ElkWolves worked examples.

Vensim Help references: `sensitivitycontrol.html`, `ksensitivity_control_parameters.html`,
`sensitivitydistributions.html`, `sensitivity.html`, `sensitivity2.html`, `payoff_sensitivity.html`.
Online: `www.vensim.com/documentation/`

---

## Overview

Vensim sensitivity analysis runs the model multiple times across a parameter space defined by a `.vsc` file. Three major uses in the ElkWolves project:

1. **Explore stochastic variation**: sweep over `NOISE SEED` values to generate multiple synthetic datasets (generator model)
2. **Posterior predictive checks**: run the estimator forward with MCMC posterior samples to visualize prediction uncertainty
3. **Payoff-threshold sensitivity**: run only parameter combinations within a specified payoff distance of the best fit (likelihood profile)

The `.vsc` file describes the parameter distribution; the `.cmd` script triggers the run.

---

## 1. `.vsc` File Format

A `.vsc` file has two sections:
1. **Header line**: comma-separated control parameters
2. **Variable lines**: one line per parameter, specifying the sampling distribution

### 1.1 Header Line

```
nRuns,method,seed1,seed2,seed3,seed4
```

| Field | Type | Meaning |
|-------|------|---------|
| `nRuns` | integer | Number of sensitivity runs to perform |
| `method` | letter | Sampling method: `U`=uniform random, `L`=Latin hypercube, `V`=VECTOR (fixed list) |
| `seed1` | integer | First RNG seed (for reproducibility) |
| `seed2`–`seed4` | integer | Additional seeds (usage varies; often 0) |

**ElkWolves `noise seed.vsc`**:
```
20,U,1234,,0,0
NOISE SEED=VECTOR(1,20,1)
```

The header: 20 runs, method `U` (but see below — `VECTOR` overrides the method), seed 1234.

**Method codes**:
- `U` — uniform random sampling from specified distributions
- `L` — Latin hypercube sampling: stratified random; guarantees uniform coverage of each marginal distribution (better space-filling than pure random for moderate run counts)
- `V` — vector (fixed list of values); often combined with `VECTOR(...)` in variable lines

### 1.2 Variable Lines

Each subsequent line specifies a parameter and its sampling distribution:

```
VariableName=DISTRIBUTION(args)
```

**`VECTOR(start, end, step)`**:
Generates a fixed arithmetic sequence. Not a random distribution — runs through `start, start+step, ..., end`.

```
NOISE SEED=VECTOR(1,20,1)
```
Runs NOISE SEED = 1, 2, 3, ..., 20 (20 values exactly).

**VECTOR edge cases** (from Help):
- `VECTOR(start, end, 0)` — step=0: only `start` and `end` are tested (two-point sweep)
- `VECTOR(start, end, step)` with negative step: only `start` is tested (degenerate; avoid)
- `VECTOR(x, x, step)` with start=end: single run at `x`
- The number of runs `nRuns` in the header must match the number of VECTOR values; if they don't match, Vensim uses whichever is smaller

**`UNIFORM(lo, hi)`**:
Random uniform sampling between `lo` and `hi`.

```
Reference wolf growth rate=UNIFORM(0.1, 0.4)
```

**`NORMAL(mu, sigma)`**:
Normal distribution with mean `mu`, standard deviation `sigma`.

**`LOGNORMAL(mu, sigma)`**:
Log-normal with natural-space mean `mu` and CV `sigma`. Same parameterization as in `.voc` prior specs.

**`PERT(lo, mode, hi)`**:
Beta-like distribution bounded by `lo` and `hi` with mode at `mode`.

**`RANDOM(lo, hi)`**:
Alias for UNIFORM. Sometimes seen in older `.vsc` files.

### 1.3 Payoff-Threshold Sensitivity (`.voc` `:SENSITIVITY=` keyword)

The `Parameters+SD.voc` file uses a special mode:
```
:SENSITIVITY=Payoff Value=1.92
```

This is not a standalone `.vsc` sensitivity run — it tells the optimizer to save (to an output `.vsc`) all parameter combinations encountered during optimization (Powell or MCMC) that are within `1.92` payoff units of the best. These can then be used as a `.vsc` for sensitivity runs.

This creates a "likelihood profile" sensitivity set automatically from the optimization run, without needing a separate MCMC sampler.

**Payoff threshold values** (from Help `payoff_sensitivity.html`):

| Payoff type | Recommended threshold | Rationale |
|-------------|----------------------|-----------|
| Sum-of-squares / weighted SS | `4.0` | Corresponds roughly to 95% confidence region for 2 parameters under F-distribution |
| Kalman log-likelihood | `2.0` (or `1.92`) | χ²₂ / 2 ≈ 1.92; 95% boundary for 2 DOF chi-squared |
| Other log-likelihoods | `χ²_k / 2` | Where k = number of constrained parameters |

The ElkWolves `Parameters+SD.voc` uses `1.92` — appropriate for the Kalman log-likelihood with 2-parameter profile. Higher thresholds produce more candidate points (wider profile); lower thresholds produce fewer (narrower).

---

## 2. Sensitivity Commands in `.cmd` Scripts

### 2.1 Running a Sensitivity

```
SIMULATE>RUNNAME|SensBase
SIMULATE>SENSITIVITY|noise seed.vsc    ! parameter distribution spec
SIMULATE>SENSSAVELIST|wolf elk state.lst  ! which variables to save
MENU>RUN_SENSITIVITY|o                  ! run; 'o' = overwrite
```

The output goes to `SensBase_*.vdfx` files (one per run) or is held in memory for export.

### 2.2 Exporting to TAB Files

```
MENU>SENS2FILE|outputName|runsetName|>T
```

| Argument | Meaning |
|----------|---------|
| `outputName` | Base name for output TAB file (or `!` = use run name) |
| `runsetName` | Name of run set to export (or `!` = current) |
| `>T` | Export as TAB-delimited file (T format); other options: `>C` (CSV), `>H` (HTML?) |

**ElkWolves `SensitivityTest.cmd`**:
```
MENU>RUN_SENSITIVITY|o
MENU>SENS2FILE|!|!|>T
```
Uses `!|!` to auto-name from the current context.

**`TestSensExport.cmd`**:
```
MENU>SENS2FILE|test|test|>T
```
Writes `test.tab` from run set named `test`.

### 2.3 Combined Run + Export (single line)

```
MENU>RUN_SENSITIVITY|oMENU>SENS2FILE|!|!|>T
```
Note: no newline or space between `|o` and `MENU>` — this is a Vensim `.cmd` continuation idiom. The `o` flag immediately after `RUN_SENSITIVITY|` triggers overwrite mode, and the next command follows on the same line.

---

## 3. TAB File Format

The exported TAB file is wide-format (variables as rows, time points as columns):

```
Time    0    0.125    0.25    ...    100
VariableName1    v₀    v₁    v₂    ...    vₙ
VariableName2    v₀    v₁    v₂    ...    vₙ
```

- First row: `Time` followed by all time points
- Subsequent rows: variable name followed by its value at each time point
- One block per sensitivity run (separated by blank lines), or all runs concatenated

**Observations from `DataSparse.tab`**:
- All variables saved by the savelist appear (Elk, Wolves) plus any control parameters
- The DETERMINISTIC flag, all parameters, and all intermediate variables are included if they were in the savelist
- Time step is `0.125`; 801 time points for T=0..100

---

## 4. Sensitivity with MCMC Posterior Samples

After an MCMC run, Vensim can generate a `.vsc` file containing posterior samples. This is the primary use of sensitivity in the ElkWolves project: run the estimator forward with 1000 parameter draws from the posterior to visualize prediction uncertainty.

### How MCMC Generates `.vsc` Files

When `MCDECIMATE` and `MCSAMPLE` are set (in `MC-ad.voc`):
```
:MCDECIMATE=10     # keep every 10th MCMC draw
:MCSAMPLE=1000     # target 1000 posterior samples
```

Vensim writes the retained posterior samples as one or more `.vsc` files named:
```
RunName_MCMC_sample+block0.vsc
RunName_MCMC_sample+block1.vsc
RunName_MCMC_sample+block2.vsc
...
```

Each `.vsc` contains a `VECTOR` or multi-value specification for all 11 parameters across the retained samples. The `SensitivityTest.cmd` reads these back:

```
SIMULATE>SENSITIVITY|Est-data-MC-sparse_MCMC_sample+block1.vsc
MENU>RUN_SENSITIVITY|o
MENU>SENS2FILE|!|!|>T
```

### Block vs. Non-Block

The `+block0` / `+block1` suffixes indicate partitions of the posterior sample:
- `+block0` — first block of samples (within-chain early samples)
- `+block1`, `+block2` — subsequent blocks (later chain states)
- "Multi" variants (`test block1 multi.vsc`) — samples drawn from multiple chains together

Running multiple block variants as separate sensitivity runs enables checking for convergence: if `block0` and `block1` give similar output distributions, the chain has mixed well.

---

## 5. `noise seed.vsc` in Detail

```
20,U,1234,,0,0
NOISE SEED=VECTOR(1,20,1)
```

**Purpose**: generate 20 different synthetic datasets from the generator model by varying the random seed.

**Effect**: 20 runs of `Elk-Wolves kf gen 1c.mdl` with NOISE SEED = 1, 2, ..., 20. Each run produces a different stochastic trajectory. Output datasets become `Data.vdfx`, `Data2.vdfx`, etc. (renamed after the run).

**Why `VECTOR` with method `U`?** `VECTOR` overrides the sampling distribution — it generates a fixed arithmetic sequence regardless of the header method. The `U` in the header is effectively ignored when all variable lines use `VECTOR`. This is a common pattern for deterministic sweeps.

**`MEAS SEED=1` is fixed** (not swept) — the measurement noise seed is constant across all datasets. This keeps measurement noise structure consistent so that variation across datasets reflects only dynamics variation.

---

## 6. Sensitivity with Kalman Filter Off

In `SensitivityTest.cmd`, all sensitivity runs use `SIMULATE>KALMAN|0`:
```
SIMULATE>KALMAN|0
SIMULATE>PAYOFF|KalmanFit-NKPapprox.vpd
SIMULATE>SENSITIVITY|Est-data-MC-sparse_MCMC_sample+block1.vsc
```

**Why KALMAN|0?** When running the estimator forward with fixed posterior parameter draws (not optimizing), the Kalman filter can be omitted. The model runs as a pure forward simulation with the given parameters. The payoff (`KalmanFit-NKPapprox.vpd`, `*CP`) scores each run, but the filter update step is not needed for generating prediction trajectories.

Keeping `KALMAN|1` during sensitivity runs would activate the filter for each run, updating state toward data — this produces smoother trajectories but makes it harder to see the raw forward-model uncertainty.

---

## 7. Sensitivity with the Generator Model

For generating multiple synthetic datasets:

```
SIMULATE>RUNNAME|DataGen
SIMULATE>SENSITIVITY|noise seed.vsc    ! sweep NOISE SEED 1..20
MENU>RUN_SENSITIVITY|o
```

Each run produces a `DataGen_N.vdfx` output. These are then renamed/selected for calibration runs. The `Data.vdfx`, `Data2.vdfx`, `Data3.vdfx`, `DataC.vdfx`, `DataShort.vdfx`, `DataSparse.vdfx` files in ElkWolves correspond to specific NOISE SEED values chosen for different calibration experiments.

---

## 8. Savelist (`.lst`) Format

The `.lst` file is a plain text list of variable names, one per line:
```
Elk
Wolves
```

These are the variables that will be saved for each sensitivity run and included in TAB export. All other model variables are discarded.

**When to include**: state variables (stocks) for trajectory visualization; key intermediate variables if you need them for post-processing. Keep the list short — each saved variable multiplies storage by `nRuns × nTimePoints`.

The savelist is referenced in the `.cmd` via `SIMULATE>SENSSAVELIST|wolf elk state.lst`.

---

## 9. Full ElkWolves Sensitivity Workflow Example

```
! Load estimator model
SPECIAL>LOADMODEL|Elk-Wolves kf est 1hb.mdl

! Load best-fit parameters from MCMC run
SIMULATE>READCIN|Est-data-MCad-sparse.out

! Configure for forward simulation (no filter)
SIMULATE>KALMAN|0
SIMULATE>REPORT|0
SIMULATE>PAYOFF|KalmanFit-NKPapprox.vpd
SIMULATE>DATA|"DataSparse.vdfx"

! First block of posterior samples
SIMULATE>RUNNAME|PostPred_Block1
SIMULATE>SENSITIVITY|Est-data-MC-sparse_MCMC_sample+block1.vsc
SIMULATE>SENSSAVELIST|wolf elk state.lst
MENU>RUN_SENSITIVITY|o
MENU>SENS2FILE|!|!|>T

! Second block for convergence check
SIMULATE>RUNNAME|PostPred_Block2
SIMULATE>SENSITIVITY|Est-data-MC-sparse_MCMC_sample+block2.vsc
SIMULATE>SENSSAVELIST|wolf elk state.lst
MENU>RUN_SENSITIVITY|o
MENU>SENS2FILE|!|!|>T
```

---

## 10. Known Help Gaps

1. **Latin hypercube vs. random vs. VECTOR**: The Help describes Latin hypercube theoretically but doesn't document when to prefer it over uniform random. Rule of thumb: Latin hypercube is better for moderate run counts (50–500) where you want good coverage of the joint distribution; plain uniform is fine for large counts (>1000) or when using VECTOR.

2. **`VECTOR` with `U` header method**: The Help doesn't explicitly state that `VECTOR` in a variable line overrides the header method. This is implied by the semantics but not stated directly.

3. **MCMC `.vsc` file naming convention**: The `_MCMC_sample+blockN.vsc` file naming from MCMC runs is not documented in Help. The block structure and how to use multiple blocks for convergence checking is not explained.

4. **`Payoff Value=` threshold units**: The `:SENSITIVITY=Payoff Value=X` setting in `.voc` uses the same scale as the payoff function. For Kalman log-likelihood, the appropriate X depends on the number of parameters and the desired confidence level. Not documented with examples.

5. **`SENS2FILE` output format**: The `>T` (TAB), `>C` (CSV), and other format codes are not fully documented. The TAB format structure (one variable per row, time as columns) is inferred from examples rather than stated.

6. **Sensitivity with multiple data files**: It's not clear from the Help whether `SIMULATE>DATA` inside a sensitivity loop can reference different datasets for different runs (parameterized by the sensitivity spec). In ElkWolves all sensitivity runs use the same `DataSparse.vdfx`.


## License

Copyright 2026 Ventana Systems, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
