# Equation Documentation

## Variables

Vensim is designed so that what a variable is and does can be determined by the way it is defined or used.  There are no forward declarations of variables and no added markers indicating what a variable is.  The following list describes the eleven variable types used in Vensim (four of which were introduced in the previous section). 

Vensim is not case sensitive.  You can enter variables with any mix of lower and upper case you like.  Vensim will retain the case, but recognize the variable even when used with other capitalization patterns.   


• Auxiliary.  Any dynamic variable that is computed from other variables at a given time.  Auxiliaries are typically the most numerous variable type.  An auxiliary variable has an expression involving other variables in its equation. 


• Constant.  A variable whose value does not change over time.  Constants have numbers on the right side of their equations or can be defined using the GET XLS CONSTANTS function or the TABBED ARRAY function. A constant can be temporarily changed prior to simulating a model. 


• Data. These have values that change over time, but do not depend on other model variables (except possibly other data).  Data use an empty equation to denote raw data or a := equation to indicate the way in which they are derived.  If a variable is used in a model, but not defined, it will be assumed exogenous and therefore treated as a Data variable.  This makes it easy to run sections of a model without writing new equations.  


• Group. Groups are not really variables, but a way to group different variables together.  They have no values, but can be used to access collections of other variable types.  Groups appear enclosed in special markers which consist of four (4) or more asterisks ****, or are defined by typing their name into the Group selector in the Equation Edit tool.  Group names are shown preceded by a period . to prevent confusion with other variable names. 


• Initial. Like a constant, except that it is the result of combining different variables at initialization time.  Initials all have INITIAL or REINITIAL equations. 


• Level.  The dynamic variables in the model.  Levels all have INTEG equations. 


• Lookup. Nonlinear functions with numerical parameters (where the parameters are the x- and y-axis values).  They are defined in equations beginning with a left parenthesis ( and ending with a right parenthesis ). 


• String Variable.  String Variables (also called String Constants take on a character string as a value.  They are useful with the MESSAGE function and as labels in Venapps. 


• Subscript Element. An element of a Subscript Range.  These identify the meaning of specific values of a subscript.  The Subscript Elements appear on the right hand side of a Subscript Range equation. 


• Subscript Range.Rather than repeating the same equation with different names, you can write one equation using a subscript that takes on different values.  We refer to variables in such an equation as subscripted, with one name representing more than one distinct concept.  Subscript Ranges are defined using a special equation that begins with a colon :.  


• Time Base. Like an Auxiliary, but with some special output and data interpretation features.  These must use the TIME BASE equation as described in Chapter 4. 


• Units.  Units are defined as additional information about a model variable and can be used to check the model for dimensional consistency.  Units are entered as an expression in the units field of an equation. 


• Unchangeable Constants: These are Constants that can’t be changed during simulation experiments. For example the number of days per year would sensibly be defined as an Unchangeable Constant. Equations for Unchangeable Constants are the same as those for Constants but use a double equal sign == for assignment. 

Constants and Unchangeable Constants are almost the same. The only difference is that the value for an Unchangeable Constant is determined from its equations, or read from a spreadsheet when a model is checked, and never changed after that. If you include an Unchangeable Constant in a .cin file you will get an error message. Unchangeable Constants are not given sliders in SyntheSim and are not included in Constant lists for Sensitivity, Optimization or Setting of Parameters.

## Variable Naming

Variable names can be of any length and contain any characters.  Variable names containing special characters must be surrounded by double quotes "" when used in equations.  If you use the Sketch and Equation editors, Vensim will automatically add the quotes.  

Variable names do not need to be surrounded by quotes if they start with a letter, or international character, and contain only letters, international characters, numbers, single quotes ' and dollar signs $.  

Variable names can contain spaces and underbars _ and the two are considered interchangeable.  If two or more spaces or underbars appear side by side, they will be collapsed to a single space (for example Hello  _  _  __      There will become Hello  There).  When you work with Vensim you can choose whether to have variable names appear with a space or underbar _.  

Variable names cannot contain an explicit line break.  In the Equation Editor, this means that you cannot add a Ctrl+Enter sequence within a variable name.  Line wraps, entered automatically by the Equation Editor, do not present a problem.  In the Text Editor, lines ending with a backslash \ will be assumed to be continued.  Vensim will add line continuation characters automatically when you move between the Text and Equation Editors.

Variable names are not case sensitive, but Vensim is case retentive==F_11}.  Vensim will use the capitalization that first appears for a variable name.  If you use the Text editor to enter a model, it is the first occurrence (not the defining equation) of a variable that defines the case that will be retained.  With the Sketch editor it is the way you first enter it. You can change the capitalization of a variable name by retyping it in the Sketch Editor or by replacing all occurrences of the variable in the Text Editor.

With the exception of String Variables, all variables in Vensim are treated as single-precision floating point numbers.   Vensim DSS is optionally available in configuration that uses double precision computation (but single precision storage).

### Examples


TOTAL_COST

total cost

Total _ Cost

The above would all be recognized as the same variable

 

"Color TV Sets & VCRS"

Color TV Sets[SONY]

"R & D"["Gov & Foreign"]

Using quotes in subscripts can be confusing and is not recommended.

 

"HiRes TV/Web Sets"[ASIA,country,SONY]

"The \"Final\" Frontier"

Quotes embedded within variable names must be preceded by a backslash \

 

érosion d'action

Uses international characters but does not require quotes (though there would be no harm in using them).
 

## Equation Format and Conventions
 
Vensim uses standard algebraic expressions with the same rules for precedence as those used by JAVA, DYNAMO, C, BASIC and other common languages.  Vensim also supports standard mathematical functions and has additional functions that make writing equations faster and simpler.  Every equation has a field for the units of measure and for a short description of the variable on the left as in:
```
profit = revenue - cost

~$/year

~The profit of our company. |
```

### Units and Range

If you include the units of measure and description, you can take advantage of Vensim's on-line documentation and units-checking capabilities.

In addition to the units of measure, you can include the range that is allowable or definitionally possible for a variable, as in:
```
cost = fixed cost + variable cost

~ $/year [0,500E6]

~ The total cost of operations.  

|
```
During simulation any variable that goes outside of its range will be flagged with a warning message.

### Increment

You can include the increment by adding a third number in the range as in:
```
Time to adjust workforce

~ Month [1,30,.5]

~ The time to adjust the workforce up and down.  

|
```
The increment specified is only used for constants to determine the amount of change in response to slider movements when SyntheSim is active.  You can make the increment the same as the full range as in
```
Switch for quality correction

~ Dmnl [0,1,1]

~ Switch to indicate that speed is adjusted when quality changes.  

|
```
This will cause the slider in SyntheSim to have only two positions (on/off).

### Supplementary

You can also mark a variable as supplementary in order to suppress the USE FLAG messages.  When working with the Equation Editor, you mark a variable as supplementary by clicking on the supplementary checkbox.  In the Text Editor, you can mark a variable as supplementary by using the :SUP flag after the comment.

### Examples

Spacing and line breaks are ignored within equations (except that line breaks are not allowed within a variable name as described above).  You can include comments in an equation by enclosing them in paired braces { }.    The examples below illustrate some different formats for defining equation information.

Best Practice
```
sales = salesmen * sales productivity

~ $/year [0,1.0E6]

~ Dollar volume of sales.

|
```
Quick and Dirty

```
sales = salesmen * sales productivity ~~| 
```
No units or comment.  It is always recommended that you include units.

### Multiple Definitions for Subscripts

Sometimes when variables are subscripted, you need to write more than one equation, because some or all of the subscripts require a separate equation.  Because  comments and units are associated with variable names, not with equations, you only need to fill in the units and comment once.  In the Equation Editor this is automatically taken care of for you.  In the Text Editor you will need to end all but one equation with a ~~| or simply a |.  If more then one set of comments or units is specified for a variable you will receive a warning message, and only the first will be used.
```
population[AgeGroup1] = INTEG(births – deaths[AgeGroup1] – aging[AgeGroup1],init population[AgeGroup1])~~|


population[AgeOlder] = INTEG(aging[AgeYounger]-deaths[AgeOlder]-aging[AgeOlder],init population[AgeOlder]) 


 ~ Rabbit 


 ~ The population of rabbits – births only add to the first cohort  

|
```

### {inline comments}

 

```
unit cost = ( 1 + interest rate ) 


        * ( investment / ( 1 - tax rate ) + operating cost - 


         tax rate * depreciation / (1-tax rate) )/ 


        {Formulation provided by 

 John Jackson (phone: 2-3433)}


( ( 1 + interest rate ) * 


        quantity produced ) 

~ $ / unit

~ unit cost of product built up from definitions used by the company cost accountants.

|
```
This also illustrates an equation format that uses spacing and multiple lines to make a complicated equation as transparent as possible.  You can place braces { } anywhere inside of an equation.  Vensim ignores everything appearing within the braces when the equation is read in.  Comments within braces will appear in text view and model documentation, and in the Equation Editor if they are embedded in the expression for a variable.
 


## License

Copyright 2026 Ventana Systems, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
