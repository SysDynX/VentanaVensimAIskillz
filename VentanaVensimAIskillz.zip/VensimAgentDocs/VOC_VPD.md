# Vensim Optimization Control (.voc) and Payoff Definition (.vpd) Files

Reference documentation with annotated ElkWolves examples.

Vensim Help references: `optimizationcontrol.html`, `payoffcomputation.html`, `extended_payoffs.html`, `mcmc_options.html`.
Online: `www.vensim.com/documentation/`

---

## Overview

Calibration in Vensim requires three types of specification:

1. **`.voc`** — what to optimize (parameters, bounds, priors) and *how* to optimize (method, stopping criteria, MCMC settings)
2. **`.vpd`** — what to minimize/maximize (the payoff function: which model variables to compare to which data, with what weighting)
3. **`.cmd`** — the script that wires everything together (`SIMULATE>PAYOFF`, `SIMULATE>OPTIMIZE`, etc.)

These interact with the Kalman filter (`.prm`) and sensitivity (`.vsc`) systems — see `KALMAN.md` and `SENSITIVITY.md`.

---

## 1. `.voc` File Structure

A `.voc` file has two sections:
1. **Header**: `:KEYWORD=value` lines controlling the optimizer
2. **Parameter block**: one line per free parameter, format `lower<=Name<=upper[,PRIOR]`

The `.out` file produced after a run is a valid `.voc` with the best-fit parameter values embedded. It can be fed back in with `SIMULATE>READCIN` or `SIMULATE>ADDCIN` to continue from that point.

---

## 2. Optimizer Control Keywords

Only subsets of the parameters are relevant to each optimizer. The MCMC parameters beginning with `:MC` do not affect Powell optimization.

### Optimizer Selection

```
:OPTIMIZER=Powell       # Powell conjugate direction method (fast, local)
:OPTIMIZER=MCMC         # Markov Chain Monte Carlo (global, uncertainty) - see Section 3
```

- **Powell**: fast gradient-free local optimizer. Suitable for finding a good starting point or when you only need point estimates.
- **MCMC**: Differential Evolution Markov Chain (DE-MC). Explores the full posterior; requires more computation but quantifies uncertainty. Vensim uses a parallel-chain DE-MC variant.

### Random number control

```
:SEED=123               # Seed for random number generator, a positive integer - if present, makes simulations replicable
:RANDOM_NUMBER=Default  # RNG seeding: Default = time-based, or specify integer seed (other settings are deprecated)
```

### Multiple-Start Mode

```
:MULTIPLE_START=Off        # Single optimization from current parameter values
:MULTIPLE_START=XParallel  # Run RESTART_MAX+1 chains simultaneously (parallel threads)
:MULTIPLE_START=RRandom    # Sequential restarts from random prior draws
```

**`XParallel`** (ElkWolves MCMC): launches `RESTART_MAX + 1` chains simultaneously, distributing them across available CPU threads (controlled by `MAX THREADS` model variable). This is the correct choice for MCMC — each chain samples independently, and together they enable the Gelman-Rubin convergence check.

**`RRandom`**: runs `RESTART_MAX + 1` sequential optimizations starting from random draws from the prior. Useful for Powell when exploring multiple local optima. Less efficient than `XParallel` for MCMC.

**`Off`**: single run. Default for Powell in simple cases.

### Convergence and Stopping

```
:MAX_ITERATIONS=1000          # Maximum function evaluations per optimization pass
:RESTART_MAX=4                # Number of restarts (for Multiple_Start) or chains (MCMC XParallel)
:PASS_LIMIT=2                 # Number of Powell passes (direction sweeps) per restart
:FRACTIONAL_TOLERANCE=0.0003  # Stop when improvement < this fraction of current payoff
:TOLERANCE_MULTIPLIER=21      # Scale factor for tolerance relative to parameter range
:ABSOLUTE_TOLERANCE=1         # Absolute payoff improvement threshold
:SCALE_ABSOLUTE=1             # Scale absolute tolerance by number of data points
```

### Output Control

```
:OUTPUT_LEVEL=On    # Write optimization progress to .out file
:TRACE=Off          # Detailed per-iteration trace (verbose; use for debugging)
:RANDOM_NUMBER=Default  # RNG seeding: Default = time-based, or specify integer seed
```

---

## 3. MCMC Control Keywords

MCMC uses a **Differential Evolution Markov Chain** algorithm. These settings control chain length, adaptation, convergence, and parallel structure.

Most MCMC control keywords begin with `:MC`

### Random number control

MCMC reuses the random number controls from the Powell optimizer

```
:SEED=123               # Seed for random number generator, a positive integer - if present, makes simulations replicable
:RANDOM_NUMBER=Default  # RNG seeding: Default = time-based, or specify integer seed (other settings are deprecated)
```

### Chain Length and Burn-in

The algorithm has two phases: burn-in and sampling. The preferred setting is to choose `MCSAMPLE` and `MCDECIMATE`, then choose `MCBURNIN` which may be 5 to 10 times the sample size, and set `:MCLIMIT=0` to set the limit automatically to burnin+sample*decimation
```
:MCSAMPLE=1000    # Burn-in iterations discarded from posterior sample
:MCDECIMATE=5     # Decimation of the sample to reduce serial correlation (computationally somewhat wasteful)
:MCBURNIN=30000    # Burn-in iterations discarded from posterior sample; 0 means determine automatically from convergence
:MCLIMIT=0     # Total MCMC iterations per chain (including burn-in); 0 means determine automatically from sample and burn-in size
```
Note that auto-burnin is probably insufficiently conservative at present, but it may be useful for test runs.


**Vensim v10.5+ auto-calculation**: If you set `:MCLIMIT=0`, Vensim automatically computes `MCLIMIT = MCBURNIN + MCSAMPLE × MCDECIMATE`. This is the preferred workflow in newer versions — set the desired sample count and burn-in directly and let Vensim derive the total iteration count. The ElkWolves files set `MCLIMIT` explicitly (older style); both work.

**Help gap**: The relationship between `MCLIMIT` and actual wall-clock time depends heavily on model complexity and hardware parallelism. For the ElkWolves estimator (~1ms per simulation), 32K × 64 chains runs in minutes on 16 threads. For complex models with slow simulations, adjust `MCLIMIT` accordingly, or take a coffee break.

### Proposal and Adaptation

```
:MCJUMP=0.05        # Base jump size (scales proposal step width)
:MCGAMMA=1          # DE-MC gamma scaling factor (baseline ≈ 2.38/sqrt(2d) for d parameters)
:MCEPSILON=0.01     # Small perturbation added to proposals (prevents degeneracy)
:MCDELTA=0.0001     # Minimum fractional move to accept
:MCADAPT=0.1        # Adaptive MCMC: adapt proposal covariance during burnin
                    # (0 = no adaptation; MC-ad version uses 0.1)
```

**`MCGAMMA`** is the most influential tuning parameter. Too small → slow mixing; too large → low acceptance rate. Target acceptance rate ≈ 25-30% for many-parameter problems.

**`MCADAPT`** (adaptive): gain for adaptation of the jump size (scaling all moves) from acceptance rate history. Improves efficiency in high-dimensional problems.

```
:MCNCHAINS=2        # Number of chains per parameter.
```
For high-dimensional problems or rough and multimodal likelihoods, it may be desirable to run more (up to 10; possibly diminishing returns above 4)

### Convergence Diagnostics

**Gelman-Rubin**: Computed from a set of 4 virtual chains (aggregated from a chain population that is typically more numerous); computes R-hat = ratio of between-chain to within-chain variance. R-hat < 1.1 (or 1.2) is conventionally accepted as convergence, though this may be insufficiently conservative.

**Help gap**: The Help does not clearly explain how `MCNCHAINS` interacts with `RESTART_MAX` and `XParallel`. (The answer is that they don't: `MCNCHAINS` affects MCMC while `RESTART_MAX` and `XParallel` affect Powell optimization)

### Outlier and Tempering

```
:MCOUTLIER=0.05     # Fraction of outlier chains to discard (bottom 5% by likelihood) during burnin
:MCTEMP=1           # Temperature for likelihood tempering (1 = standard; >1 = flattened)
:MCFTEMP=1          # Final temperature (for cooling schedule)
:MCCOOLING=1000     # Iterations for temperature ramp from MCTEMP to MCFTEMP
:MCSCHEDULE=0       # Cooling schedule type (0 = linear)
```

### Cross-over and Pairing

```
:MCUPDATEPAIRS=2    # Number of chain pairs used for DE-MC proposals
:MCXOVER=0.2        # Probability of using cross-over (vs. simple Gaussian jump)
```

### Sampling and Thinning

```
:MCDECIMATE=10      # Record every Nth posterior draw (thinning factor)
:MCSAMPLE=1000      # Target number of posterior samples to retain
:MCRECORD=0         # 0 = record all; 1 = record only improvements
:MCPAYOFFTYPE=0     # Payoff type: 0 = minimize, 1 = maximize
:MCINITMETHOD=0     # Chain initialization: 0 = from current best, 1 = from prior
:MCKMEANS=10        # K-means clustering for posterior summary (MC-ad)
```

---

## 4. Parameter Block

Each free parameter occupies one line:

```
lower <= Parameter Name <= upper [, PRIOR(mu, sigma)]
```

### Format Details

- **Parameter Name**: must match the MDL variable name exactly (case-insensitive in practice)
- **Bounds**: enforce hard constraints during optimization; treated as uniform prior boundaries for MCMC
- **Prior**: optional; if omitted, uniform over [lower, upper] is assumed

### Prior Distributions

Supported prior types (from `optimizationcontrol.html`):

| Syntax | Distribution | Use case |
|--------|-------------|---------|
| `NORMAL(mu, sigma)` | Normal | Parameters with known estimate and uncertainty |
| `LOGNORMAL(mu, sigma)` | Log-normal | Positive parameters; scale-invariant; mu = mean, sigma = CV |
| `UNIFORM(lo, hi)` | Uniform | Vague prior; same as no prior spec |
| `PERT(lo, mode, hi)` | PERT (beta-like) | Bounded, expert-judgment; mode is most likely value |
| `CAUCHY(x0, gamma)` | Cauchy | Heavy-tailed; robust to outliers; use carefully |
| `SCALE(lo, hi)` | Scale (log-uniform) | non-informative prior for scale parameters; equal weight per decade |

A missing prior (i.e. no entry) is implicitly uniform over the parameter's bounds.

**ElkWolves example**: noise parameters use `LOGNORMAL(1, 1)` — centered at 1.0 (plausible if the Poisson assumption is right) with CV=1 (very diffuse; allows values from ~0.1 to ~10). The tight version in `MC-ad.voc` uses `LOGNORMAL(1, 0.2)` and `LOGNORMAL(0.1, 0.2)` — tighter, informed by prior optimization runs.

**Help gap**: The Help documents `LOGNORMAL` but is ambiguous about whether `mu` and `sigma` are the log-space parameters or the natural-space mean and CV. From ElkWolves usage, `LOGNORMAL(1, 1)` centers at 1.0 in natural space with CV=1, consistent with natural-space parameterization. (Answer: `mu` is in the natural space; `sigma` is the geometric standard deviation and therefore proportional to the mean.)

### ElkWolves Parameter Examples

**`Parameters.voc`** — dynamics only, uniform priors:
```
0<=Reference wolf growth rate<=1
0<=Reference elk per wolf<=1
0<=Relative initial elk<=2
0<=Relative initial wolves<=2
0<=Elk fractional growth rate alpha<=1
0<=Wolf mortality rate<=1
```

**`Parameters+Filter.voc`** — dynamics + noise, log-normal priors on noise:
```
[dynamics params as above, plus:]
0.01<=Est Wolf measurement var frac<=2,LOGNORMAL(1,1)
0.01<=Est Elk measurement var frac<=2,LOGNORMAL(1,1)
0.01<=Est Elk driving noise scale<=2,LOGNORMAL(1,1)
0.01<=Est Wolf driving noise scale<=2,LOGNORMAL(1,1)
0<=Elk other mortality rate<=1
```

**`Parameters+Filter MC-ad.voc`** — tightened priors after prior Powell run:
```
0.01<=Est Wolf measurement var frac<=2,LOGNORMAL(1,.2)
0.01<=Est Elk measurement var frac<=2,LOGNORMAL(1,.2)
0.01<=Est Elk driving noise scale<=2,LOGNORMAL(1,.2)
0.01<=Est Wolf driving noise scale<=2,LOGNORMAL(1,.2)
0<=Elk other mortality rate<=1,LOGNORMAL(.1,.2)
```
Note `Elk other mortality rate` now has a `LOGNORMAL(0.1, 0.2)` prior — centered at 0.1 (the true value) with tight CV=0.2. This incorporates knowledge from prior calibration.

---

## 5. The `.out` Output File

After an optimization run, Vensim writes a `.out` file. This file is a valid `.voc` with additional header lines:

```
:COMSYS After 32011 simulations
:COMSYS Best payoff is -177.413
:COMSYS Normally terminated optimization
:OPTIMIZER=MCMC
...
[all :KEYWORD lines from the original .voc]
...
:MCADAPT=0.05        # Adaptive settings as actually used
:MCDECIMATE=10
:MCSAMPLE=1000
lower <= Parameter Name = BestValue <= upper
```

The key difference from the input `.voc`: parameter lines now include an `= BestValue` field:
```
0 <= Elk fractional growth rate alpha = 0.819134 <= 1
```

**How to use `.out` files**:
- `SIMULATE>READCIN|Est-data-MCad-sparse.out` — loads the best-fit parameter values into the model. If there are additional change files (`.cin` or `.out`) they can be loaded with additional `ADDCIN` commands, or as a comma separated list.
- Then re-optimize: starts from the best point, enables warm-starting MCMC
- `SIMULATE>PAYOFF|...` still needed separately — the `.out` does not embed the payoff definition

---

## 6. `.vpd` Payoff Definition File Structure

The `.vpd` file defines the objective function — which model variables to compare to which data, and how.

### Line Format

```
*DIRECTIVE
ModelVariable|DataVariable/WeightExpression
```

Each observation contributes to the payoff based on the directive and weight.

### Directives

| Directive | Formula (per observation) | Use case |
|-----------|--------------------------|---------|
| `*C` | `−(model − data)²/weight` | Unweighted or fixed-weight squared error |
| `*CK` | Full Kalman log-likelihood | Gaussian likelihood with time-varying variance; requires Kalman filter active |
| `*CKE` | Kalman update but **excluded** from likelihood | Update filter state but don't score this variable |
| `*CGL` | `−(log(model) − log(data))²/weight` | Log-Gaussian; multiplicative errors; weight is SD fraction |

**`*C` vs `*CK`**: `*C` is simple weighted squared error; `*CK` adds the log-determinant of the innovation covariance (the Kalman "price" for a large uncertainty). With `*CK`, inflating variance doesn't cheat — the log-det term penalizes large variances.

**`*CKE` usage**: In `KalmanFit-ElkOnly.vpd`, Wolves uses `*CKE` — the Kalman filter still tracks wolf state (updating its covariance) but wolves don't contribute to the payoff. This is useful when wolf data is unreliable but you still want Kalman smoothing of the wolf state.

### Weight Expression

The weight field is a model variable name or expression evaluated at each observation time:

```
Wolves|Measured Wolves/Est wolf measurement var
```

- `Measured Wolves`: the data variable (`:NA:` → observation missing, skipped)
- `Est wolf measurement var`: model variable containing the time-varying variance
- The weight is the **variance**, not the standard deviation (unlike some other tools)

For `*C` with fixed weight: `Wolves|Measured Wolves/1` (equal weighting).

For `*CGL` (log-Gaussian): `Wolves|Measured Wolves/Est Wolf measurement SD frac` — weight is the SD fraction, because log-space errors are dimensionless fractions.

### ElkWolves `.vpd` Examples

**`KalmanFit.vpd`** — primary Kalman likelihood:
```
*CK
Wolves|Measured Wolves/Est wolf measurement var
*CK
Elk|Measured Elk/Est elk measurement var
```

**`KalmanFit-ElkOnly.vpd`** — filter wolves, fit elk only:
```
*CKE
Wolves|Measured Wolves/Est wolf measurement var
*CK
Elk|Measured Elk/Est elk measurement var
```

**`LogWeightedFit.vpd`** — log-Gaussian:
```
*CGL
Wolves|Measured Wolves/Est Wolf measurement SD frac
*CGL
Elk|Measured Elk/Est Elk measurement SD frac
```

**`UnweightedFit.vpd`** — baseline (no variance):
```
*C
Wolves|Measured Wolves/1
*C
Elk|Measured Elk/1
```

### Handling Missing Data

`:NA:` values in the data variable are automatically skipped — that time point does not contribute to the payoff. This enables sparse datasets without any special configuration in the `.vpd`.

---

## 7. Wiring It Together: `.cmd` Script

A minimal Kalman calibration `.cmd`:

```
SIMULATE>RUNNAME|MyRun
SIMULATE>PAYOFF|KalmanFit.vpd         ! payoff definition
SIMULATE>OPTIMIZE|Parameters+Filter MC.voc  ! optimizer config
SIMULATE>KALMAN|1                      ! 1 = use Kalman filter
SIMULATE>DATA|"DataSparse.vdfx"        ! observed data
MENU>RUN_OPTIMIZE|o                    ! run; 'o' suppresses dialog
```

For sensitivity runs using posterior samples:
```
SIMULATE>READCIN|Est-data-MCad-sparse.out    ! load best-fit parameters
SIMULATE>KALMAN|0                            ! forward simulation (no filter)
SIMULATE>SENSITIVITY|posterior_sample.vsc   ! sensitivity spec with MCMC draws
SIMULATE>SENSSAVELIST|wolf elk state.lst    ! which variables to save
MENU>RUN_SENSITIVITY|o
MENU>SENS2FILE|!|!|>T                       ! export all to TAB files
```

---

## 8. Known Help Gaps and Confusing Aspects

1. **`LOGNORMAL` parameterization**: the Help lists `LOGNORMAL(mu, sigma)` but does not clearly state whether these are natural-space or log-space parameters. The ElkWolves usage `LOGNORMAL(1, 1)` confirms natural-space (mu=1.0 = mode ≈ 1, sigma=1 = CV).

2. **`XParallel` + `MCNCHAINS` interaction**: the Help describes both but not how they combine. From ElkWolves: `RESTART_MAX=64, MCNCHAINS=2` means 64 parallel chains grouped in pairs for R-hat; Gelman-Rubin is computed within each pair.

3. **`*CKE` directive**: documented in extended payoffs but the distinction from `*CK` is subtle. `*CKE` means "use this observation to update the Kalman state (P, x) but don't add its residual contribution to the log-likelihood."

4. **`MCADAPT` vs `MCDECIMATE` vs `MCSAMPLE`**: these three interact: `MCSAMPLE` sets the final number of retained draws; `MCDECIMATE` sets the thinning factor; actual thinned draws ≈ `(MCLIMIT − MCBURNIN) / MCDECIMATE`. If `MCSAMPLE` < thinned draws, further thinning is applied. The Help does not make this clear.

5. **Prior contribution to payoff**: priors are included in the MCMC acceptance criterion (they affect the target distribution) but are NOT reported separately in the `.out` payoff value. The reported payoff is the pure likelihood component only. (TODO: this is not true, but may be an output formatting issue.)

6. **`.out` file and MCMC continuation**: loading `.out` with `READCIN` sets parameter starting values only. Full chain history (for warm-starting) is not preserved across sessions — each MCMC run starts fresh chains. This means `MCBURNIN` should always be set conservatively.

7. **Repeated parameter values in MCMC posterior `.vsc` files**: The MCMC sample `.vsc` blocks will sometimes contain repeated identical parameter rows. This is correct and expected — it reflects the Metropolis-Hastings acceptance/rejection step. When a proposed move is rejected, the chain stays at its current position; that position appears multiple times in the retained sample. Do **not** deduplicate: the frequency with which a point appears encodes its posterior probability mass.


## License

Copyright 2026 Ventana Systems, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
