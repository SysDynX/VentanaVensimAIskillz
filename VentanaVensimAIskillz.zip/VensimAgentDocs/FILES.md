# Vensim File Types

## Overview


BMP
 
BitMaP file. Used to store embedded bitmaps when a file is saved in .mdl format. The filenames are the same as the model name with numbers added.
 

DAT
 
DATa input file. This is a simple text file.
 

CIN
 
Constant INput file used to change Constants and Lookups in simulation (text file).
 

GIN
 
Gaming Input file use to change gaming variables when running games (text file).
 

CMD
 
CoMmanD file used to run a series of commands in batch mode (DSS only) (text file)
 

FRM
 
FoRM file used to tell Vensim how to import tab delimited and spreadsheet files.
 

LST
 
LiST file containing a savelist, i.e. set of variables to be saved either for a sensitivity simulation or to decrease the output size for large models.
 

MDL
 
MoDeL format file used to transfer Vensim models from one platform to another.
 

OUT
 
OUTput file from an optimization giving the best parameter results (Pro/DSS only text file).
 

PRM
 
PaRaMeter control file used to describe the Kalman filter. Formerly used to control optimizations, but replaced by .vpd and .voc.
 

REP
 
REPort file created when the payoff report option is selected (Pro/DSS only text file).
 

VCD
 
Vensim Custom Description file used to create a scripted Venapp (DSS only).
 

VCF
 
A binary  version of a .vcd file.
 

VDFX
 
Vensim Data Format file used to store simulation results and converted data. Binary file. Legacy files were VDF.
 

VDI
 
Vensim Data Input file used to query an ODBC connection for Constants and Data (DSS Only text file).
 

VDO
 
Vensim Data Output file used to output data to an ODBC connection (DSS Only text file).
 

VGD
 
Vensim Graph Definition file used to set up custom graphics.
 

VGF
 
A binary version of a .vgd file.
 

VOC
 
Vensim Optimization Control file. Used to specify how to optimize a model. This is a text file (Pro/DSS only).
 

VPD
 
Vensim Payoff Definition. Used to define the payoff for optimization (text file Pro/DSS only).
 

VMFX
 
Vensim Model Format file used to store models.  This is a binary file. Legacy files were VMF.
 

VPAX
 
Vensim Packaged Application containing a model and Venapp definition file (DSS only binary file).
 

VPMX
 
Vensim Packaged model containing a model and support files (binary file). Legacy files were VPM.
 

VSC
 
Vensim Sensitivity Control. Control file for doing sensitivity simulations (text file).
 

STS
 
Vensim Sketch ToolSet file.  A file containing a  Sketch toolset.
 

VTS
 
Vensim Analysis ToolSet file.  A file containing an Analysis toolset.
 

 
## Backup files 

All of the following are backup files, you can delete these if they are no longer needed.

.2mdl

.3vm

.3vmfx

.4vm

.4vmfx


## License

Copyright 2026 Ventana Systems, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
