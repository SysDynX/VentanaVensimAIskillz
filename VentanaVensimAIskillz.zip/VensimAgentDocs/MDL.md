# Vensim .mdl formats

## Overview

There are two .mdl formats in current use, differing primarily in the sketch component. The older format (prior to version 9.2) has a v300 sketch documented in SKETCH.md. The optional new format has a v301 sketch documented in newsketch.md.

In other ways the files should be the same or very similar.

## Blocks

### Codepage tag

The file usually starts with a codepage tag like {UTF-8}

### Macros

This may be followed by macros like:
```
:MACRO: CLIP(true,false,a,b)
CLIP=IF THEN ELSE(a>=b,true,false)
	~	true
	~		|

:END OF MACRO:
```
Macros are optional and only available in advanced versions, so these may be missing.

### Group headers

Also optional, there may be group headers like,
```
********************************************************
	.scirev7
********************************************************~
		"Path Dependence, Competition and Succession in the Dynamics of Scientific \
		Revolution," John Sterman & Jason Wittenberg. Organization Science Vol. 10 \
		No. 3, 1999. Translated to Vensim by Tom Fiddaman, 2011. models.metasd.com
	|
```
Group names often employ hierarchy, like
.SS
.SS.City
.SS.Age

### Equations

Then there are equations (possibly interspersed with more group headers), like
```
PCNP=PPCPS*PPSD+PPCAR*PARD+PPCOA*(PDP-PPSD-PARD)
	~	fraction/Year
	~	PROBABILITY OF CREATING NEW PARADIGM (FRACTION/YEAR)
	|
```
Generally these take the form <variable name> <assignment operator> <expression> ~ <units> ~ <comment> ~ <optional flag> |

There are variants that omit the assignment operator (for data) or use operators other than = like := for data equations, : and <-> for subscripts.

### Sketch

The sketch, as mentioned above, begins with 
```
\\\---/// 
```
with the version number identified on the following line.

The sketch is described in SKETCH.md and NEWSKETCH.md.

### Custom graphs, tables and reports

After the sketch, there may be embedded custom graphs, what would otherwise be in a .vgd file, beginning with
```
///---\\\
```
In some cases this block is empty.

The format here is the same as a .vgd file, and described in CUSTOM.md.

### Settings

Finally, there is a settings block, with initial delimiter
```
:L<%^E!@
```
**⚠️ DEL byte**: In files written by Vensim the delimiter actually contains a DEL
character (U+007F, byte `0x7f`) between `<` and `%`, giving `:L<%^E!@`. Text editors
render this as invisible or `^?`, so the line looks like `:L<%^E!@`. When writing or
replacing this marker programmatically, always include the DEL byte. When searching for it
in Python, search for the DEL form first, then fall back to the plain form:
```python
for marker in (':L<%^E!@', ':L<%^E!@'):
    pos = text.find(marker)
    if pos != -1:
        break
```
These settings are listed as numbered lines. A few key items are:
22: units equivalents

Some of the lines identify supporting files:
10: .cin, .out - constant (parameter) change files
13: data
11: .voc - optimization or MCMC control
12: .vpd - optimization or MCMC payoff
18: .vsc - sensitivity control file
20: .lst - savelist for sensitivity
106: .prm - Kalman filter specification
106: Kalman payoff (if not provided for optimization)

In the new file format, there may also be a sidecar <modelname>.mdls file containing volatile elements of the model settings. It should not be necessary to edit the sidecar.

#### Full list of settings

Missing numbers in the sequence are likely retired. 

M_LOAD_RUN		1
M_TIME_BASE		4
M_BENCH_VAR		5
M_SELECTED_SUBS 6

M_GRAPH_DESC 8  /* ignore for PLE */

M_RUN_NAME               9
M_RUN_CHANGES            10
M_RUN_OPTPARM            11
M_RUN_PAYOFF             12
M_RUN_DATA               13
M_RUN_RESUME             14
M_RUN_SWITCHES           15

M_PARTIAL_RUN_SAVE_FILE  17
M_RUN_SENS_CONTROL_FILE  18
M_SKETCH_ZOOM_AND_CURRENT_VIEW           19
M_RUN_SENSITIVITY_SAVE_LIST              20
M_RUN_COMMENT            21
M_UNITS_EQUIV            22 /* one or more lines of comma separated names */
M_RUN_RESUMETIME         23
M_GRAPH_START_TIME             24
M_GRAPH_END_TIME               25
M_GRAPH_SPECIAL_TIME           26
M_OPT_BITS               27
M_RUN_POST               28
M_RUN_PRE                29
M_XLS_REDIRECT           30
M_REFDATASET             31 /* numberseries,name */
M_REFDATAVAR             32 /* numberpairs,var[sub1a,sub2a]  */
M_REFDATA                33 /* (x1,y1),(x2,y2),... (xn,yn) might be continued so that lines are not too long */
M_OPT_BITS2              34 //This contains the "Run model from disk" setting.
M_TM_NAME                35
M_TM_FORMAT              36
M_TM_BASE_YEAR           37
M_TM_BASE_MONTH          38
M_TM_BASE_DAY            39
M_TM_UNITS               40
M_USE_DATE_LABELING      41
M_PROCESS_CIN_AS_FLOAT			42
M_VDF_EXPORT_EXPORT_TO			43
M_VDF_EXPORT_CHAR_ENC			44
M_VDF_EXPORT_EXPORT_AS			45
M_VDF_EXPORT_ADD_COLS			46
M_VDF_EXPORT_ADD_COLS_STRING	47
M_VDF_EXPORT_SAVE_LIST			48
M_VDF_EXPORT_TIME_RUNNING		49
M_VDF_EXPORT_PUT_SUBSCRIPTS		50
M_VDF_EXPORT_TIME_FROM			51
M_VDF_EXPORT_TIME_TO			52
M_VDF_EXPORT_TIME_INTERVAL		53
M_VDF_EXPORT_APPEND				54
M_VDF_EXPORT_DONT_SHOW_TIME		55
M_VDF_EXPORT_EURO_FORMAT		56
M_VDF_EXPORT_SETTINGS_INITIALISED	57
M_VDF_EXPORT_EXCEL_DATE_CODE		58
M_VDF_EXPORT_INCLUDE_RUNNAME_AS_FIELD	59

M_SENS_VDF_Export_Export_to_STR			60
M_SENS_VDF_Export_CharEncoding			61
M_SENS_VDF_TimeRunning					62
M_SENS_VDF_ExportOnlyFinalTime			63
M_SENS_VDF_EuroFormatNumbers			64
M_SENS_VDF_ModifyVarNamesBy				65
M_SENS_VDF_ModifyNamesUsing				66
M_SENS_VDF_percentiles					67
M_SENS_VDF_Export_UseExcelDateCode		68
M_SENS_VDF_Export_IncludeRunnameAsField	69
M_VDF_SENS_EXPORT_SETTINGS_INITIALISED  70
M_VDF_EXPORT_XLSX_SEPARATE_SHEETS		71

M_COMPRESS_RUN							72
M_OVERWRITE_GET_CONST_CALLS				73

M_ADDITIONAL_SPELLING					74
M_SPELL_CHECK_DICTIONARY				75


M_REFORM_CLEAN_REORDER_EQ				77 //GV.reorder_eq
M_REFORM_CLEAN_REFORMAT_EQ				78 //GV.reformat_eq

M_REFORM_CLEAN_ON_SAVE					81 //

M_VDF_EXPORT_EXPORT_UNITS				82
M_CO_MODEL									83
M_CO_MODEL_SHARED_PARAMETER_MODEL			84	
M_CO_MODEL_SHARED_PARAMETER_PARAMETERNAME	85
M_VDF_EXPORT_EXPORT_TIDY_CSV				86

// TONY : The following indicates that the model is saved using "universal format".
// by this I mean on the Mac, the sketch co-ords are automatically rescaled when the model is saved.
// This means that models saved on the Mac now have co-ords of the Windows version.
M_SAVE_MODELS_IN_UNIVERSAL_FORMAT			87

M_ACTIVE_INITIAL_ABS_ERR	90
M_ACTIVE_INITIAL_REL_ERR	91

M_MODEL_TREAT_UNITS_MISMATCHES_AS_ERRORS	92

M_ONSAVE_REORDER_EQ				93 //GV.reorder_eq
M_ONSAVE_REFORMAT_EQ			94 //GV.reformat_eq

M_STORE_MODEL_SETTINGS_SEPARATELY_FLAG	95
M_SKETCH_ZOOM_OVERRIDE					96

M_IGNORE_NOT_USED_ERROR_ON_MODEL_CHECK	97
M_DISABLE_SKETCH_RECENTER	98

M_GENERATE_LINEARIZED_MODEL		99
M_RUN_MCMCPARM					100
M_RUN_MCMCPAYOFF             101

M_USE_OLD_SKETCH_STYLE	102

M_BY_TYPE_SHAPES	103
M_APPEARANCE	104

M_SIMUALTION_COMPLETE_ACTION	105

M_KALMAN_PAYOFF		106
M_KALMAN_PARAMETER	107
M_USE_LEGACY_SIZED_SLIDERS	108

M_SLIDERCOLOURS	109

M_VDF_EXPORT_HIDE_HEADER_ROW		110
M_VDF_EXPORT_INCLUDE_STRINGS		111

M_ACTION_RECORDER_COMMAND			112
M_PROVIDE_SIM_TIMING				113

M_DEFAULT_SLIDER_FONT					114


M_LOADED_RUN_CONFIG_FILE			120

M_SKETCH_TOOLTIP_OPTIONS	121

M_GUI_OBJECT_SESSION_SETTINGS_Slider	 122
M_GUI_OBJECT_SESSION_SETTINGS_wxNotebook 123

M_USE_SIMULATION_PAUSE_IN_SYNTHESIM	124


## License

Copyright 2026 Ventana Systems, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
