# Custom graphs, tables and reports

Although the .vgd file commands for each tool can contain different information, there are common elements and rules governing the use of keywords, labels, references to runs, and variables in all .vgd files.  A sample .vgd file might contain:
:GRAPH Test Graph one
	:VAR V1|Volume
	:DATASET *2
:GRAPH Test Graph 2
	:Var myvar[ott]
	:DATASET exper1

Two graphs are defined.  The following concepts help structure these graph definitions.

Keywords (such as ":GRAPH") are used to describe output.All keywords must begin with a colon :.  The keyword can begin anywhere on a line, but must be the first element on the line.  The keyword must be separated from the rest of the line by a space    or an equal sign =.

Labels  (such as "Volume") are strings that will appear in the output exactly as entered in the .vgd file.Labels appear after a vertical bar | and continue to the first comma , or until the end of the line .  Quotes, more vertical bars, and everything else except commas , are included directly in the label without alteration.  Labels cannot include new lines or commas.

Nesting  is shown with indentation but interpreted solely by context.  Graph and table descriptions are often hierarchical.  In the documentation, this hierarchy is indicated with indentation, but Vensim itself does not pay attention to indentation.  Vensim keeps track of hierarchy by keywords and acts accordingly.  For example, the beginning of a graph or table description, as occurs with the second ":GRAPH" above,  always ends the current graph or table description.

Datasets  (such as "exper1") can be accessed whether or not they are loaded.  When you refer to a dataset in a description, Vensim searches the disk to find the dataset.  If the dataset is not already loaded in Vensim, it will be loaded while the output is produced and then unloaded.  If the dataset does not exist, an error message is displayed.

Wildcard datasets (such as "*1") can be used to refer to one of the currently loaded datasets.  Instead of explicitly naming a dataset, you may use an asterisk * and a number from 1 to 9 to denote the corresponding dataset in the Dataset Control dialog.  For example, "baserun" would use values from the file baserun.vdf, whereas *2 would use the second loaded dataset.  If you omit references to a dataset, Vensim uses the first or last loaded dataset (depending on whether Vensim is configured to load datasets in first or last position - see Dataset Control Panel). Use -1 to refer to the first loaded dataset, *B to refer to the last loaded dataset. Use * to refer to all loaded datasets.  Use # followed by a number (such as "#3") to refer to all loaded datasets up to and including that one.  For example #3 will use the first, second, and third loaded datasets.

Wildcard variables (such as "myvar[ott]") can be used to access different instances of subscripted variables.  A subscripted variable can represent more than a single value.  If you enter a variable name with no subscripts and that variable is subscripted, Vensim searches the associated Subscript Selection dialog and uses the first entry determined from these.  If you explicitly include Subscript Ranges in the variable name, Vensim will refer to the subscript selection list and use all entries determined from these.  For example, if ott is a Subscript Range having elements ONE,TWO,THREE, with TWO and THREE selected, then myvar is the same as myvar[TWO], and myvar[ott] yields myvar[TWO] and myvar[THREE].

Long lines can be continued with a backslash \ followed immediately by a new line.

NOTE.vgd files are not case sensitive.

## Graphs

The Graph tool has a three-level hierarchy:  graph labeling and control, scale grouping, and descriptors for the individual variables to be included in the graph.  For each hierarchical level the order, after the keyword beginning the hierarchy (:GRAPH, :SCALE and :VAR respectively), is unimportant and keywords are shown alphabetically below.

Scales can be specified with the :SCALE keyword or by separating the names of variables with commas , using the :VAR keyword.  Both of these work the same way.  The :SCALE keyword is more flexible but also more cumbersome.  Use the one most convenient for you.  

NOTE A complete Custom Graph definition requires one :GRAPH and one :VAR line.

### Graph Labeling and Control

:GRAPH name begins the description of a graph.  The name appears in the Custom Output Selection dialog as an identifier for the graph.

:CUMULATIVE plots the cumulative (integrated) value of the graph variable.

:DOTS does not interpolate between points when drawing the graph lines.  This option is handy for creating scatter plot of noisy data where connecting the dots would make the graph hard to read.  It is also useful for looking at Data variable to see exactly where they fall.

:HEIGHT value specifies the height of the graph (including all labels).  The value for height is in inches or centimeters depending on what you have set in the Global Options dialog.

:LABEL-LINES specifies x-axis labels centered on vertical grid lines.  This is the default.

:LABEL-INTERVALS specifies x-axis labels centered between the vertical grid lines.  A plot on a scale presented in calendar years usually looks best if it is graphed with the labels placed between vertical lines; other plots make sense only if the grid lines are marked.

:LANDSCAPE specifies horizontal printed orientation.  This does not affect the appearance of the graph on the screen.  This option will only take effect if orientation is set to Best Choice in the Print Options dialog.

:MAX-POINTS n specifies the maximum number of points to be used in a work in progress graph.  This value default to 100 and should be set larger if you are making simulations in which (FINAL TIME-INITIAL TIME)/SAVEPER is bigger than 100.

:NO-LEGEND n suppresses the legend at the bottom of the graph, the title of the graph and labels.  Use 1 to suppress the legend, 2 to suppress the title and 4 to suppress the x-axis labels. Adding these up will suppress more than one thing (for example 3 suppressed the legend and title). This is useful if it is obvious from the graph lines what they are, or if you want to add a legend in a different format after exporting the graph.

:PORTRAIT specifies vertical printed orientation.  This does not affect the appearance of the graph on the screen.  This option will only take effect if orientation is set to Best Choice in the Print Options dialog.

:STACK  N plots the graph variables as a stackup, that is, VAR_1, VAR_1 + VAR_2, VAR_1 + VAR_2 + VAR_3, and so on.  Only variables grouped under a single :SCALE will be stacked.   If N is specified and nonzero only the first N variables will be stacked – additional variables will be graphed normally.

:STACK-FILL like stack except that the area between the graph lines is filled with the graph line color.  Generally useful with only a single :SCALE.

:STAMP text|ident defines a stamp that appears on a printed version of the graph such as CONFIDENTIAL. text appears in a large font that overwrites the lower right part of the graph.  A vertical bar | separates the text from identifier. identifier appears in the lower left-hand corner of the printed graph.  Neither the stamp nor the identifier appear on the screen.

:TITLE text gives the title of the graph.  This appears centered over the top of the graph.  If no title is specified, the graph name is used.

:WIDTH value specifies the width of the graph (including labels).  The value for width is in inches or centimeters depending on what you have set in the Global Options dialog.

:WIP marks the graph as a work in progress graphs.  Work in progress graphs are displayed automatically during a simulation.  Work in progress graphs are not scaled automatically so it is usually necessary to specify the minimum and maximum values for all the axis.  You can have up to 10 work in progress graphs defined.

:X-AXIS name gives the name of the graph's independent variable.  If :X-AXIS is not specified, the Time Base currently selected in the Time Axis Control dialog is used.  The y-axis names depend on which variables are selected for graphing.

:X-DIV value or :XDIV ?value=label?value=label... specifies the number of horizontal graph divisions.  If :X-DIV is left set to 0 or not included, the number of divisions will be determined based on the x-axis values in the graph.  If you want the number of divisions as set in the Time Axis Control dialog use :X-DIV -1.  You can also use the :XDIV keyword to break up the x axis with qualitative labels.  Just follow :X-DIV with a series of values and labels and the x-axis will be broken up according to the values and given to corresponding labels.

:X-LABEL text defines the label to be displayed on the x-axis. By default this is the name of the graph's independent variable.  The labeling on the y-axis is modified variable by variable using the :VAR keyword.

:X-MAX value specifies the maximum value on the x-axis.

:X-MIN value specifies the minimum value on the x-axis.

:Y-DIV value specifies the number of vertical graph divisions.  If you do not specify a value the number set in the Scale Control dialog will be used.

:Y-LABEL ?value=label?value=label... specifies that the Y axis should be given special labels according the values specified.  The values should be increasing but need not be equally spaced.  This allows explicit entry of important value break points.  All variables must share the same scale when :Y-LABEL is used.

:Y-MAX value specifies the maximum value on the y-axis.  This value is overridden whenever a specific variable is given a value for :Y-MAX.

:Y-MIN value specifies the minimum value on the y-axis.  This value is overridden whenever a specific variable is given a value for :Y-MIN.

### Scale Grouping

:SCALE groups variables to appear on a single vertical scale.  If :SCALE is not specified, variables appearing on separate lines will appear on separate scales.  If conflicting :UNITS, :Y-MIN or :Y-MAX values are specified for variables in a single scale, those from the last variable will be used.

### Variables on the Graph

:VAR name1|label1,name2|label2, ... specifies one or more variables that will appear on the graph, on the same scale.  The labels are optional.  If not specified, the variable's name will be combined with the name or a dataset.

:CONFIDENCE %=color, %=color, ... specifies that the variable will be displayed as a percentile graph if it is a saved variable from a sensitivity simulation.  % is a number between 1 and 100 that describes the percentile range.  Color is a RGB color specification with the values separated by vertical bars | as in 255|0|0 for pure red.  You can specify as many ranges as you want or leave them blank to get defaults.  You can also include more than one confidence plot on a graph, though the results might be confusing.  If the dataset is not a sensitivity simulation or the variable was not saved nothing will be displayed.  This cannot be used with :SENS-LINES

:DATASET filename|label specifies the name of the dataset in which values for the variable will be found.  The label is optional and will be used only if there is no label for the variable. If no dataset is named, the first loaded dataset will be used.
	-        Wildcard datasets (such as "*1") can be used to refer to one of the currently loaded datasets.  Instead of explicitly naming a dataset, you may use an asterisk * and a number from 1 to 9 to denote the corresponding dataset in the Dataset Control dialog.  For example, "baserun" would use values from the file baserun.vdf, whereas *2 would use the second loaded dataset.  If you omit references to a dataset, Vensim uses the first or last loaded dataset (depending on whether Vensim is configured to load datasets in first or last position - see Dataset Control Panel). Use *B to refer to the last loaded dataset. Use * to refer to all loaded datasets.  Use # followed by a number (such as "#3") to refer to all loaded datasets up to and including that one.  For example #3 will use the first, second, and third loaded datasets.

:LINE-COLOR r-g-b specifies the color for the graph line (or shapes). The color is specified as a combination or red, green and blue components each of which must be between 0 and 255. If this is blank the standard graph line colors (as set in the global options for Vensim) are used.

:LINE-STYLE style specifies the style for a line. The choices are DOT, DASH, DASHDOT and DASHDOTDOT. Note that this can’t be mixed with a line width (styled lines must have width 1).

:LINE-WIDTH width specifies the width that the graph line will have.  Normally graph lines have the same width, but different colors. Can’t be mixed with line style.

:MEAN color  specifies that the mean of the sensitivity simulation should be displayed as a line of the specified color.  This option will only have an effect if one of :SENS-LINES or :CONFIDENCE is specified.

:SENS-LINES color specifies that the results from a sensitivity simulation should be displayed as line traces.  You can specify the color to show the traces with or leave it blank for black.   This cannot be used with :CONFIDENCE.

:SHAPE shape,size(for use with :DOTS only) lets you specify the shape that the dots will take on.  Acceptable shapes are SQUARE, SOLID-SQUARE, CIRCLE, SOLID-CIRCLE, CROSS, X, DIAMOND, TRIANGLE, and UPTRIANGLE (upside down triangle).  The size is in pixels and gets properly translated on printing.

:RUN filename|label is a synonym for :DATASET.

:UNITS units defines the units label for the variable(s).  If no units label is given, the Workbench model will be searched to see if it can determine a units label.  If not, nothing will be shown.

:Y-MIN value specifies the local minimum value for the y-axis.

:Y-MAX value specifies the local maximum value for the y-axis.

### Example 1 - Multiple Variable Graph
:graph world base (#3)
	:title Base run from the WORLD model.
	:var Capital
	:var Natural_Resources
	:var quality_of_life
	:var Population
	:var Pollution
	
### Example 2 - Dataset Control
:GRAPH SPEED
	:TITLE Work Speed
	:X-AXIS time
	:X-LABEL Month
	:X-MIN 0
	:X-MAX 100
	:Y-MIN 0
	:Y-MAX 1.0
	:VAR wrk_speed[ASSY]
	       :DATASET simulation.vdf
	       :UNITS dimensionless
	:VAR experience_effect[ASSY],fatigue_eff[ASSY]
	       :DATASET simulation.vdf
	       :UNITS dimensionless

### Example 3 Scaling Control
:GRAPH LABOR
	:TITLE Assembly Headcount
	:X-MIN 1980
	:X-MAX 1990
	:Y-MIN 0
	:Y-MAX 1000
	:SCALE
	:VAR direct_labor[ASSY]|Direct Labor
	       :RUN simulation.vdf
	:VAR direct_labor[ASSY]|. . . . . . . . .actual
	       :DATASET actual.vdf
	       :UNITS people
	       :Y-MAX 10000
	:SCALE
	       :VAR indirect_labor[ASSY]
	               :RUN simulation.vdf
	               :UNITS people
	               :Y-MAX 500

Note that variable-specific limits override the global :Y-MAX values on this graph.

### Example 4 - Sensitivity Graphs

:GRAPH Sens1
:var net cash flow 
	:confidence 50=255|244|128,75=0|255|0,95=0|0|255,100=128|128|128

### Example 5 - Qualitative Display

:GRAPH Qualitative

:TITLE Natural Resources over Time

:X-DIV ?1900=Early?1997=Now?2100=A century later

:X-LABEL During the Industrial Age

:Y-LABEL ?0=None?4E11=Not Much?1E12=Lots

:VAR Natural Resources

:NO-LEGEND
	
## Bar graphs

There is very little real hierarchy in the Bar Graph. However, it is convenient to think of variable and dataset selection as different levels in the hierarchy.  Except for the initial keyword (:BAR-GRAPH), any :AS-RUN keys and :BAR-VAR-TIME, the order of keywords is unimportant.

NOTE A complete Custom Bar Graph definition requires one :BAR-GRAPH and one :VAR line.

### Graph Labeling and Control

:BAR-GRAPH name begins the description of a bar graph.  The name appears in the Graphs tab of the Control Panel as an identifier for the graph.

:BAR-BY-TIME - display the first variable as a bar graph over time.  Additional variables will be ignored.

:BAR-TIME value specifies the time at which the bar values are to be taken.  This time is interpreted in the context of the currently selected Time Base.  If :BAR-TIME is not specified, Special time is used.

:FORCE - prevents the display of a Bar Graph as a modified Graph when the number of bars grows large.  This is useful if you are trying to display a lot of things on a Bar Graph.

:HEIGHT value specifies the width of the bar graph (including labels).  The value for width is in inches or centimeters depending on what you have set in the Global Options dialog.

:HORIZONTAL makes the bars horizontal (the default is vertical).

:NO-LEGEND n suppresses the legend at the bottom of the graph, the title of the graph and labels.  Use 1 to suppress the legend, 2 to suppress the title and 4 to suppress the division labels. Adding these up will suppress more than one thing (for example 3 suppresses the legend and title).

:OSUBTITLE text -  defines a text string that will be displayed above the Bar Graph rectangle on the left.  This keyword is ignored unless the :HORIZONTAL keyword has been used and at least one :OVAR keyword have been used specified.

:SOFT-BOUNDS - allows the Bar Graph to reset the scaling if the bounds are exceeded.  This is typically most useful in conjunction with the :WIP keyword.

:SUBTITLE text - defines a text string that will be displayed above the Bar Graph rectangle.  This keyword will be ignored unless the :HORIZONTAL keyword is also used.

:TITLE text defines the title of the bar graph.  If not specified, the name of the bar graph will be used as its title.

:WIDTH value specifies the width of the bar graph (including labels).  The value for width is in inches or centimeters depending on what you have set in the Global Options dialog.

:WIP - forces the bar graph to display itself during the simulation.  This can be an effective animation technique for larger models but the Bar Graph may change to quickly to prove interesting in smaller models.

:X-LABEL text specifies the x-axis label.

:Y-MAX value defines the maximum value on the y-axis.

:Y-MIN value defines the minimum value on the y-axis.

### Variables on the Bar Graph

:VAR var1|label1,var2|label2, ... supplies a list of variables to be included.  It makes no difference whether you place multiple variables on a single line or one variable per line.  The labels are optional.

:OVAR var1|label1,var2|label2, ... supplies a list of variables to be included for display on the left which is opposite to the display of a :VAR.  This allows you to make two sided bar graphs which are especially useful for comparing two things that differ along one dimension.  The most common use for this would be to create population pyramids as shown in the example.  This keyword will be ignored unless the :HORIZONTAL keyword is also used.

:BAR-VAR-TIME - display the variable at a time.  This allows you to display different variables at different times (or the same variable at different times).  This applies only to the :VAR that directly precedes it.

### Datasets on the Bar Graph

:DATASET filename|label specifies the name of the dataset in which values for the variable will be found.  The label is optional.  You can used wildcards in specifying datasets as described in the "The Structure of .vgd Files" above.  If no dataset is named, all of the loaded datasets will be used.

:RUN name|label is a synonym for dataset.

### Example

:bar-graph Cost_bar

:title A Simple bar graph of cumulative cost

:horizontal

:var cum cost[design]|Design

:var cum cost[produce]|Production

:var cum cost[test]|Testing

:run basequal.vdf|Base Quality

:run highqual.vdf|Improved Quality Control

 

### Grouping Variables as Runs

Normally, Bar Graphs display each variable in a group with the same variable from different runs as shown above. In some cases, however, it is desirable to group different variables together by a subscript or another attribute.

:AS-RUN label indicates that the variables that follow are to be treated as if they were from a single run – with label representing the name of that run. For example

:BAR-GRAPH WORK_DONE

:TITLE Work Done

:HORIZONTAL

:AS-RUN Task Definition

:VAR TASK DEFINITION[TASK1]|Task1

:VAR TASK DEFINITION[TASK2]|Task2

:VAR TASK DEFINITION[TASK3]|Task3

:VAR TASK DEFINITION[TASK4]|Task4

:AS-RUN Work Completed

:VAR Work Completed Correctly[TASK1]

:VAR Work Completed Correctly[TASK2]

:VAR Work Completed Correctly[TASK3]

:VAR Work Completed Correctly[TASK4]

:DATASET Base



Note that you can combine multiple datasets with :AS-RUN though it is not recommended. In this case the datasets will be grouped most closely together.

If you use :AS-RUN make sure that the same number of variables appear under each :AS-RUN group and that the orders are consistent. Only the first set of variable labels will be used.

### Population Pyramids

Custom bar graphs can be used to create and animate population pyramids.  Consider a model that has population by age and sex with 5 year cohorts.  The Bar-Graph definition

:BAR-GRAPH POPPYR

:TITLE Population Pyramids

:SUBTITLE Female

:OSUBTITLE Male

:WIP

:FORCE

:HORIZONTAL

:Y-MIN 0

:Y-MAX 300

:VAR Population Group[FEMALE,age group]

:OVAR Population Group[MALE,age group]

:SOFT-BOUNDS

## tables

Custom Tables allow you to display the values of variables as numbers at different times.  They work the same as the Table tool, except you have more control over appearance.

Custom Tables have a number of global keywords and there are two that are variable specific.

### Label and Scaling Keywords

:TABLE tablename begins the definition of a custom table.  tablename will appear in the Graphs tab of the Control Panel.

:CELLWIDTH n  defined the width of the cells after the first.  This width is specified in characters and should be made big enough so that the table entries do not overrun one another.  The default value is 10.

:COMLINE comline specifies a comment to appear on a line.  If the comment contains tabs each of the tabs will be placed over a column.  The comment before the first tab will not scroll and the parts after the first tab will scroll just as time values do when the user scrolls the table.  Note that you can use variable specification ( for example \Population/) in :COMLINE to get values. To enter leading spaces start comline with a vertical bar |. The bar will not be displayed in the output table.

:FIRST-CELLWIDTH n defines the width of the first cell in the table.  This width is specified in characters and should be made big enough so that the table entries do not overrun one another.  The default value is 20.

:FONT face|size|attrib|color specifies the font to be used in displaying and printing the table.  The font has the standard Vensim font (for example Arial|12||0-0-0).

:NOTIMEsuppresses the reporting of Time at the top of the table.  The first :VAR or :COMLINE will replace the top line of the table and not scroll out of view.

:PRETTYNUM causes numbers to formatted using Vensim's pretty number formatting conventions.  If this is not specified numbers will be printed using scientific notation.

:PRINT-EVERY number - controls the frequency with which results are displayed.   This allows you to customize the amount of information being displayed.

:SPECIAL-TIME number - sets the special time for reporting values.  The values at SPECIAL-TIME are reported last in the table.  If SPECIAL-TIME and X-MAX are the same no values are  reported at SPECIAL-TIME.

:TIME-DOWN causes time to run down instead of across.

:TITLE text defines the title of the table.  If not specified, the name of the table will be used as its title.

:X-MAX number sets the last time for reporting values.

:X-MIN number sets the first time for reporting values.

### Variables on the Table

:VAR var|label specifies the variable to be reported and the label to be used in its reporting.  The numbers for the variable will be displayed.  You can use Subscript Ranges in the variable name just as for the graph tool.  Note that if you use a label for a subscripted variable the label will simply repeat.

:DATASET dataset specifies the dataset to get the variables values from.  This applies only to the current :VAR.

:FORMAT format determines the format with which the current variable will be displayed in the table.  This can be a prefix for each number such as $ or a standard C language formatting string such as %6.0f to display numbers as whole number. For example you could use %.0f%% for display of percentages as whole numbers (note the final % is doubled following C formatting conventions).  This applies only to the current :VAR.

### Example

:table table1

:title Population overview

:prettynum

:comline Population runs from \population@1900/ to \population@2100/

:font Arial|10||0-0-0

:var population|How many

:var births

:var deaths

## Reports

Custom reports allow you to type in text intermixed with simulation results as a means of giving useful text-based information.

The custom report definition has only a few keywords.  Normally the bulk of reports is simply typed in text, and it is placed in the output as it is typed in.  Custom reports must start with the :REPORT keyword and end with the :END-OF-REPORT keyword.

NOTE A complete Custom Report definition requires a :REPORT line and an :END-OF-REPORT line.

:REPORT name begins the definition of a custom report.

:FONT fontname specifies the font to be used in the report.  The font name follows the standard Vensim convention.  You can insert the name of a font using the Edit>Insert>Font command in the Text Editor.  You can only have one font per report.  If you have more than one :FONT line only the last one will be used.

:NEWPAGE will cause a page break to be inserted in the report when it is printed.  There will be a blank line in the output showing on the screen.  Nothing following the :NEWPAGE keyword  on a line will appear or be used.

:TITLE specifies the title for the report.

:VAR varname #timebase@time&dataset%format?val=label?val=label...|Label specifies the name of a variable to report a value for in the report.  The options following the name follow the conventions described in "Getting Variable Values" above. The label is the text that will appear in the report before the numbers, the variable name is used if no label is included.

:END-OF-REPORT marks the end of the report.


## License

Copyright 2026 Ventana Systems, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
