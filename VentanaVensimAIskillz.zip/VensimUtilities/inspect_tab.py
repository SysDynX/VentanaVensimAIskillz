#!/usr/bin/env python3
"""
inspect_tab.py
Summarise a Vensim VDF2TAB output at landmark time points.

The VDF2TAB format is transposed: row 0 is the time header,
each subsequent row is one variable (name in column 0, values in columns 1+).

Usage:
    python inspect_tab.py <tabfile> [var1 var2 ...] [--times 0 10 50 100]

    If no variables are listed, all variables are shown.
    If no --times are given, defaults to 6 evenly-spaced landmarks
    spanning the full simulation range.

Examples:
    python inspect_tab.py oak_squirrel_run.tab
    python inspect_tab.py oak_squirrel_run.tab "Oak Trees" Squirrels
    python inspect_tab.py oak_squirrel_run.tab --times 0 25 50 100 200
"""

import csv
import sys


def load_tab(path):
    """Return (times list, data dict {name: [values]}) from a VDF2TAB file."""
    with open(path, 'r') as f:
        reader = csv.reader(f, delimiter='\t')
        rows = [r for r in reader if r]
    times = [float(x) for x in rows[0][1:]]
    data = {}
    for row in rows[1:]:
        if row and row[0]:
            data[row[0]] = [float(x) for x in row[1:]]
    return times, data


def fmt(x):
    """Format a number compactly."""
    if x == 0:
        return '0'
    if abs(x) >= 1e6 or (abs(x) < 0.01 and abs(x) > 0):
        return f'{x:.3e}'
    if abs(x) >= 100:
        return f'{x:.1f}'
    return f'{x:.3f}'


def nearest_idx(times, t):
    return min(range(len(times)), key=lambda i: abs(times[i] - t))


def summarise(tab_path, var_names=None, landmark_times=None):
    times, data = load_tab(tab_path)

    if landmark_times is None:
        # 6 evenly-spaced points across the simulation
        n = 6
        step = (len(times) - 1) // (n - 1)
        landmark_times = [times[min(i * step, len(times) - 1)] for i in range(n)]

    t_idx = [nearest_idx(times, t) for t in landmark_times]
    actual_times = [times[i] for i in t_idx]

    if var_names:
        missing = [v for v in var_names if v not in data]
        if missing:
            print(f'Warning: variables not found: {missing}', file=sys.stderr)
        show = [v for v in var_names if v in data]
    else:
        show = list(data.keys())

    col_w = 14
    name_w = max(30, max((len(v) for v in show), default=0) + 2)

    header = f'{"Variable":<{name_w}}' + ''.join(f'{t:>{col_w}.4g}' for t in actual_times)
    print(header)
    print('-' * len(header))
    for v in show:
        vals = [data[v][i] for i in t_idx]
        print(f'{v:<{name_w}}' + ''.join(f'{fmt(x):>{col_w}}' for x in vals))


def main():
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        sys.exit(1)

    tab_path = args[0]
    args = args[1:]

    landmark_times = None
    var_names = []
    i = 0
    while i < len(args):
        if args[i] == '--times':
            landmark_times = []
            i += 1
            while i < len(args) and not args[i].startswith('--'):
                landmark_times.append(float(args[i]))
                i += 1
        else:
            var_names.append(args[i])
            i += 1

    summarise(tab_path, var_names or None, landmark_times)


if __name__ == '__main__':
    main()
