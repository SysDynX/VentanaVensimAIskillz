#!/usr/bin/env python3
"""Render the oak_squirrel model layout as a PNG using matplotlib."""

import math, sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle, Polygon

sys.path.insert(0, '.')
from generate_sketch import (
    parse_mdl_model, compute_layout, _infer_eq_links,
    CW, CH, CLOUD_GAP, STOCK_W, STOCK_H
)

MDL_PATH = 'oak_squirrel.mdl'
OUT_PATH = 'oak_squirrel_diagram.png'

# ── Load model and compute layout ─────────────────────────────────────────────
model   = parse_mdl_model(MDL_PATH)
pos     = compute_layout(model)
variables = model['variables']
rels      = model.get('relationships', [])

stocks_set = {v['name'] for v in variables if v['type'] == 'stock'}
flows_set  = {v['name'] for v in variables if v['type'] == 'flow'}
auxes_set  = {v['name'] for v in variables if v['type'] == 'variable'}

# ── Figure ────────────────────────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(18, 11))
ax.set_xlim(0, CW)
ax.set_ylim(CH, 0)          # y increases downward to match Vensim
ax.set_aspect('equal')
ax.set_facecolor('#f0f4f0')
ax.axis('off')
fig.patch.set_facecolor('#f0f4f0')

# ── Colours ───────────────────────────────────────────────────────────────────
COL_STOCK   = ('#c8e6c9', '#2e7d32')   # face, edge
COL_FLOW    = ('#bbdefb', '#1565c0')
COL_AUX     = ('#fff9c4', '#f57f17')
COL_CLOUD   = ('#e0e0e0', '#757575')
COL_PIPE    = '#1565c0'
COL_CAUSAL  = '#555555'

# ── Helper: cloud endpoint positions ─────────────────────────────────────────
def cloud_endpoints(fname):
    vx, vy = pos[fname]
    src_stock = next((sv['name'] for sv in variables
                      if sv['type'] == 'stock' and fname in sv.get('outflows', [])), None)
    snk_stock = next((sv['name'] for sv in variables
                      if sv['type'] == 'stock' and fname in sv.get('inflows', [])), None)

    if src_stock:
        up_x, up_y = pos[src_stock]
    elif snk_stock:
        dx2, dy2 = pos[snk_stock]
        ddx, ddy = vx - dx2, vy - dy2
        dlen = math.sqrt(ddx**2 + ddy**2) or 1
        up_x, up_y = vx + ddx/dlen*CLOUD_GAP, vy + ddy/dlen*CLOUD_GAP
    else:
        up_x, up_y = vx - CLOUD_GAP, vy

    if snk_stock:
        dn_x, dn_y = pos[snk_stock]
    elif src_stock:
        sx2, sy2 = pos[src_stock]
        ddx, ddy = vx - sx2, vy - sy2
        dlen = math.sqrt(ddx**2 + ddy**2) or 1
        dn_x, dn_y = vx + ddx/dlen*CLOUD_GAP, vy + ddy/dlen*CLOUD_GAP
    else:
        dn_x, dn_y = vx + CLOUD_GAP, vy

    return src_stock, snk_stock, up_x, up_y, dn_x, dn_y

# ── Helper: draw a thick pipe arrow ──────────────────────────────────────────
def pipe_arrow(x1, y1, x2, y2):
    ax.annotate('',
        xy=(x2, y2), xytext=(x1, y1),
        arrowprops=dict(
            arrowstyle='->', color=COL_PIPE, lw=2.2,
            mutation_scale=14,
            connectionstyle='arc3,rad=0'))

# ── Helper: draw a thin causal arrow ─────────────────────────────────────────
def causal_arrow(x1, y1, x2, y2, rad=0.15):
    ax.annotate('',
        xy=(x2, y2), xytext=(x1, y1),
        arrowprops=dict(
            arrowstyle='->', color=COL_CAUSAL, lw=0.9,
            mutation_scale=9,
            connectionstyle=f'arc3,rad={rad}'))

# ── Helper: is this link already shown as a pipe? ────────────────────────────
def is_pipe_link(src, tgt):
    sv = next((v for v in variables if v['name'] == src), None)
    tv = next((v for v in variables if v['name'] == tgt), None)
    if sv is None or tv is None:
        return False
    if sv['type'] == 'flow' and tv['type'] == 'stock':
        return src in tv.get('inflows', []) + tv.get('outflows', [])
    if sv['type'] == 'stock' and tv['type'] == 'flow':
        return tgt in sv.get('inflows', []) + sv.get('outflows', [])
    return False

# ══════════════════════════════════════════════════════════════════════════════
# 1. Causal arrows (drawn first, behind everything)
# ══════════════════════════════════════════════════════════════════════════════
drawn_causal = set()

def draw_causal(src, tgt, rad=0.15):
    if is_pipe_link(src, tgt):
        return
    if src not in pos or tgt not in pos:
        return
    key = (src, tgt)
    if key in drawn_causal:
        return
    drawn_causal.add(key)
    causal_arrow(*pos[src], *pos[tgt], rad=rad)

for rel in rels:
    draw_causal(rel.get('from', ''), rel.get('to', ''), rad=0.12)

for src, tgt in _infer_eq_links(model):
    draw_causal(src, tgt, rad=0.08)

# ══════════════════════════════════════════════════════════════════════════════
# 2. Flow pipes
# ══════════════════════════════════════════════════════════════════════════════
for v in variables:
    if v['type'] != 'flow':
        continue
    fname = v['name']
    vx, vy = pos[fname]
    src_stock, snk_stock, up_x, up_y, dn_x, dn_y = cloud_endpoints(fname)

    # Upstream pipe (source → valve)
    pipe_arrow(up_x, up_y, vx, vy)
    # Downstream pipe (valve → sink)
    pipe_arrow(vx, vy, dn_x, dn_y)

    # Draw cloud symbols for open ends
    if not src_stock:
        cloud_r = 10
        for dx, dy in [(-4,-3),(0,-4),(4,-3),(5,1),(3,4),(-3,4),(-5,1)]:
            ax.plot(up_x+dx, up_y+dy, 'o', markersize=5,
                    color=COL_CLOUD[0], markeredgecolor=COL_CLOUD[1], lw=0.8, zorder=3)
    if not snk_stock:
        for dx, dy in [(-4,-3),(0,-4),(4,-3),(5,1),(3,4),(-3,4),(-5,1)]:
            ax.plot(dn_x+dx, dn_y+dy, 'o', markersize=5,
                    color=COL_CLOUD[0], markeredgecolor=COL_CLOUD[1], lw=0.8, zorder=3)

# ══════════════════════════════════════════════════════════════════════════════
# 3. Stock rectangles
# ══════════════════════════════════════════════════════════════════════════════
for v in variables:
    if v['type'] != 'stock':
        continue
    x, y = pos[v['name']]
    rect = FancyBboxPatch(
        (x - STOCK_W/2, y - STOCK_H/2), STOCK_W, STOCK_H,
        boxstyle='square,pad=1',
        facecolor=COL_STOCK[0], edgecolor=COL_STOCK[1], lw=2, zorder=5)
    ax.add_patch(rect)
    # Wrap name: split on space into max 2 lines
    words = v['name'].split()
    mid   = len(words)//2 or 1
    label = ' '.join(words[:mid]) + '\n' + ' '.join(words[mid:]) if len(words) > 2 else v['name']
    ax.text(x, y, label, ha='center', va='center', fontsize=6, fontweight='bold',
            color=COL_STOCK[1], zorder=6, linespacing=1.2)

# ══════════════════════════════════════════════════════════════════════════════
# 4. Flow valve diamonds
# ══════════════════════════════════════════════════════════════════════════════
for v in variables:
    if v['type'] != 'flow':
        continue
    x, y = pos[v['name']]
    # Determine orientation for label placement
    src_stock, snk_stock, up_x, up_y, dn_x, dn_y = cloud_endpoints(v['name'])
    if src_stock and snk_stock:
        sx, sy = pos[src_stock]; dx2, dy2 = pos[snk_stock]
        orient = 1 if abs(dx2-sx) >= abs(dy2-sy) else 4
    elif src_stock:
        sx, sy = pos[src_stock]
        orient = 1 if abs(x-sx) >= abs(y-sy) else 4
    elif snk_stock:
        dx2, dy2 = pos[snk_stock]
        orient = 1 if abs(x-dx2) >= abs(y-dy2) else 4
    else:
        orient = 1

    r = 7
    diamond = Polygon([[x, y-r],[x+r, y],[x, y+r],[x-r, y]],
                      closed=True, facecolor=COL_FLOW[0],
                      edgecolor=COL_FLOW[1], lw=1.5, zorder=5)
    ax.add_patch(diamond)

    # Rate label
    words = v['name'].split()
    mid   = max(1, len(words)//2)
    label = ' '.join(words[:mid]) + '\n' + ' '.join(words[mid:]) if len(words) > 2 else v['name']
    if orient == 4:
        lx, ly = x + 52, y
    else:
        lx, ly = x, y + 28
    ax.text(lx, ly, label, ha='center', va='center', fontsize=5,
            color=COL_FLOW[1], zorder=6, linespacing=1.2)

# ══════════════════════════════════════════════════════════════════════════════
# 5. Aux / constant circles
# ══════════════════════════════════════════════════════════════════════════════
for v in variables:
    if v['type'] != 'variable':
        continue
    x, y = pos[v['name']]
    r = max(22, len(v['name']) * 3.2)
    circle = mpatches.Ellipse((x, y), width=r, height=18,
                               facecolor=COL_AUX[0], edgecolor=COL_AUX[1], lw=1.2, zorder=5)
    ax.add_patch(circle)
    words = v['name'].split()
    mid   = max(1, len(words)//2)
    label = ' '.join(words[:mid]) + '\n' + ' '.join(words[mid:]) if len(words) > 2 else v['name']
    ax.text(x, y, label, ha='center', va='center', fontsize=5,
            color='#4a3000', zorder=6, linespacing=1.2)

# ── Title ─────────────────────────────────────────────────────────────────────
ax.set_title('Oak–Squirrel Mutualism', fontsize=14, fontweight='bold',
             color='#2e7d32', pad=8)

fig.savefig(OUT_PATH, dpi=130, bbox_inches='tight', facecolor=fig.get_facecolor())
print(f'Saved {OUT_PATH}')
