#!/usr/bin/env python3
"""
translate_json_to_mdl.py
Translate an SD JSON model description to Vensim .mdl format.

Usage:
    python translate_json_to_mdl.py input.json output.mdl

Mapping notes (from CLAUDE.md):
- type "stock"    -> INTEG equation; "equation" field is the initial value
- type "flow"     -> auxiliary (Vensim has no distinct flow type)
- type "variable" -> auxiliary or constant
- specs section   -> .Control group
- supportingInfo  -> .Title group
- Equations use underscores as space-equivalents; converted to spaces in output
"""

import json
import re
import sys
from pathlib import Path


def strip_html(text):
    """Remove HTML tags from text and collapse whitespace."""
    text = re.sub(r'<[^>]+>', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def eq_to_vensim(equation):
    """Convert JSON equation (underscores represent spaces) to Vensim format."""
    return equation.replace('_', ' ')


def format_variable(var):
    """Return the Vensim equation block for a single variable."""
    name = var['name']
    vtype = var['type']
    equation = eq_to_vensim(var['equation'])
    units = var.get('units', '')
    doc = var.get('documentation', '')
    inflows = var.get('inflows', [])
    outflows = var.get('outflows', [])

    lines = []

    if vtype == 'stock':
        # Build net-flow expression from inflows and outflows arrays
        net_flow = '+'.join(inflows) if inflows else '0'
        for f in outflows:
            net_flow += '-' + f
        initial = equation  # For stocks, "equation" holds the initial value
        lines.append(f'{name}= INTEG (')
        lines.append(f'\t{net_flow},')
        lines.append(f'\t{initial})')
    else:
        # Flow or variable: both become auxiliaries/constants in Vensim
        lines.append(f'{name}=')
        lines.append(f'\t{equation}')

    lines.append(f'\t~\t{units}')
    lines.append(f'\t~\t{doc}')
    lines.append('\t|')
    lines.append('')

    return '\n'.join(lines)


def format_control(specs):
    """Return the .Control group block."""
    start = specs['startTime']
    stop = specs['stopTime']
    dt = specs['dt']
    time_units = specs.get('timeUnits', 'year')

    return '\n'.join([
        '********************************************************',
        '\t.Control',
        '********************************************************~',
        '\t\tSimulation Control Parameters',
        '\t|',
        '',
        f'FINAL TIME  = {stop}',
        f'\t~\t{time_units}',
        '\t~\tThe final time for the simulation.',
        '\t|',
        '',
        f'INITIAL TIME  = {start}',
        f'\t~\t{time_units}',
        '\t~\tThe initial time for the simulation.',
        '\t|',
        '',
        'SAVEPER  =',
        '        TIME STEP',
        f'\t~\t{time_units} [0,?]',
        '\t~\tThe frequency with which output is stored.',
        '\t|',
        '',
        f'TIME STEP  = {dt}',
        f'\t~\t{time_units} [0.001,8]',
        '\t~\tThe time step for the simulation.',
        '\t|',
        '',
    ])


def find_unit_equivalents(variables):
    """
    Scan all unit strings in the model and return a list of (singular, plural)
    pairs where both forms appear as unit tokens.  These become '22:' lines in
    the settings block, telling Vensim's unit checker to treat them as equivalent.

    Example: units 'squirrels' and 'acorns/squirrel/year' both reference squirrel*
    tokens, so ('squirrel', 'squirrels') is returned.
    """
    all_tokens: set[str] = set()
    for var in variables:
        units = var.get('units', '')
        # Extract bare alphabetic tokens (unit names, not operators/numbers)
        for token in re.findall(r'[a-zA-Z]+', units):
            all_tokens.add(token.lower())

    pairs = []
    for token in sorted(all_tokens):
        if token.endswith('s') and token[:-1] in all_tokens:
            pairs.append((token[:-1], token))   # (singular, plural)
    return pairs


def format_sketch_and_settings(run_name, final_time, initial_time, unit_equiv=None):
    """Return a minimal V300 sketch block and settings block."""
    # Three backslashes: each \\ in Python = one \ in the string
    sketch_start = '\\\\\\'  + '---///'   # \\\---///
    sketch_end   = '///---' + '\\\\\\'    # ///---\\\

    lines = [
        f'{sketch_start} Sketch information - do not modify anything except names',
        'V300  Do not put anything below this section - it will be ignored',
        '*View 1',
        '$192-192-192,0,Arial|12||0-0-0|0-0-0|0-0-255|-1--1--1|-1--1--1|96,96,75,0',
        sketch_end,
        ':L<%^E!@',
        f'1:{run_name}.vdfx',
        '4:Time',
        '5:Time',
        f'9:{run_name}',
        '19:74,0',
        f'24:{initial_time}',
        f'25:{final_time}',
        f'26:{final_time}',
        f'23:{initial_time}',
    ]
    # Unit equivalents: '22:singular,plural' before the '15:' line
    for singular, plural in (unit_equiv or []):
        lines.append(f'22:{singular},{plural}')
    lines += [
        '15:0,0,0,1,0,0',
        '27:0,',
        '34:0,',
        '42:0',
        '72:0',
        '73:0',
        '95:0',
        '96:0',
        '97:0',
        '77:0',
        '78:0',
        '102:1',
        '93:0',
        '94:0',
        '92:0',
        '91:0',
        '90:0',
        '87:0',
        '75:',
        '43:',
        '103:8,8,8,3,8',
        '105:0,0,0,0,0,0,0,0,0,0',
        '104:Vensim Sans|12||0-0-0|0-0-0|-1--1--1|0-0-255|192-192-192|-1--1--1',
        '',
    ]
    return '\n'.join(lines)


def translate(json_path, mdl_path):
    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    model = data['model']
    supporting_info = data.get('supportingInfo', {})
    title = supporting_info.get('title', '')
    explanation = strip_html(supporting_info.get('explanation', ''))

    sections = []

    # Codepage header
    sections.append('{UTF-8}')

    # Title group from supportingInfo
    title_text = title
    if explanation:
        title_text = explanation if not title else f'{title}: {explanation}'
    if title_text:
        title_block = '\n'.join([
            '',
            '********************************************************',
            '\t.Title',
            '********************************************************~',
            f'\t\t{title_text}',
            '\t|',
        ])
        sections.append(title_block)

    # Equations
    sections.append('')
    for var in model['variables']:
        sections.append(format_variable(var))

    # Control group
    sections.append(format_control(model['specs']))

    # Sketch and settings (with auto-detected unit equivalents)
    run_name = Path(mdl_path).stem.replace(' ', '_')
    final_time = model['specs']['stopTime']
    initial_time = model['specs']['startTime']
    unit_equiv = find_unit_equivalents(model['variables'])
    sections.append(format_sketch_and_settings(run_name, final_time, initial_time, unit_equiv))

    content = '\n'.join(sections)

    with open(mdl_path, 'w', encoding='utf-8') as f:
        f.write(content)

    print(f'Written: {mdl_path}')


if __name__ == '__main__':
    if len(sys.argv) < 3:
        print(f'Usage: {sys.argv[0]} input.json output.mdl')
        sys.exit(1)
    translate(sys.argv[1], sys.argv[2])
