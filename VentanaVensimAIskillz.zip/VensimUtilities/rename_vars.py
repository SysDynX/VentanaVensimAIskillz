#!/usr/bin/env python3
"""
rename_vars.py — rename DYNAMO-abbreviated variables in a Vensim MDL file.

Usage: python rename_vars.py <input.mdl> <output.mdl>

For each variable whose doc field is an ALL-CAPS DYNAMO long name, renames the
variable to "OLDNAME TitleCaseLongName" and propagates throughout the model
(equations, sketch diagram, custom graphs).
"""

import re
import sys

# Vensim built-in variables — never rename these
BUILTINS = {'NOISE SEED', 'INITIAL TIME', 'TIME STEP', 'FINAL TIME', 'Time', 'SAVEPER'}


# ---------------------------------------------------------------------------
# Doc-field utilities
# ---------------------------------------------------------------------------

def is_dynamo_doc(text: str) -> bool:
    """Return True if text has ≥70% uppercase letters (DYNAMO convention)."""
    letters = [c for c in text if c.isalpha()]
    if not letters:
        return False
    return sum(1 for c in letters if c.isupper()) / len(letters) >= 0.70


def strip_units_paren(text: str) -> str:
    """
    Strip trailing (UNITS) and [NOTES] annotations from a doc line.
    Repeats until stable so that e.g. '... (PERSONS) [NOT CURRENTLY USED]'
    becomes '...'.
    """
    prev = None
    while prev != text:
        prev = text
        text = re.sub(r'\s*\[[^\]]*\]\s*$', '', text).strip()
        text = re.sub(r'\s*\([^)]*\)\s*$', '', text).strip()
    return text


def title_case(text: str) -> str:
    """'PUZZLES UNDER ATTACK' → 'Puzzles Under Attack', with invalid chars removed.

    Vensim variable names may only contain letters, digits, spaces, and underscores.
    Hyphens and other special chars (e.g. '#') that appear in DYNAMO doc strings are
    stripped here.  An alternative would be to quote the whole name (e.g.
    '"NDP Non-Dominant Paradigm"'), which Vensim also accepts — but sanitization
    produces cleaner unquoted names.
    """
    # Replace hyphens with space so 'Non-dominant' → 'Non Dominant'
    text = text.replace('-', ' ')
    # Remove characters not valid in Vensim variable names (keep letters, digits, spaces)
    text = re.sub(r'[^A-Za-z0-9 ]', '', text)
    # Capitalize each word and collapse extra spaces
    return ' '.join(word.capitalize() for word in text.split())


def extract_long_name(doc_raw: str) -> str | None:
    """
    Given the raw doc-field text (the third ~-section of an equation block),
    return the DYNAMO long name suitable for title-casing, or None.
    """
    # Strip block terminator and trailing whitespace
    doc = doc_raw.rstrip('| \t\n')
    # Join backslash-continuation lines
    doc = re.sub(r'\\\s*\n\s*', ' ', doc)
    # Examine each line; skip translator notes starting with !!
    for line in doc.split('\n'):
        line = line.strip()
        if not line or line.startswith('!!'):
            continue
        stripped = strip_units_paren(line)
        if stripped and is_dynamo_doc(stripped):
            return stripped
    return None


# ---------------------------------------------------------------------------
# Parse equations section → rename map + all variable names
# ---------------------------------------------------------------------------

def parse_equations(text: str):
    """
    Scan the equations section and return:
      rename_map : {old_name: new_name}  — variables that get renamed
      all_names  : set of all variable names seen (including un-renamed ones)
    """
    rename_map = {}
    all_names = set()

    lines = text.split('\n')
    in_macro = False
    in_block = False
    current_block: list[str] = []

    def handle_block(block_lines: list[str]) -> None:
        if not block_lines:
            return
        first = block_lines[0]

        # Skip group headers, BOM marker, directive lines
        if not first or first[0] in ('{', '*', ':'):
            return
        # Skip quoted names like "N-1"
        if first.startswith('"'):
            return
        # Skip subscript range / alias definitions:  NAME : ...  (but not NAME :=)
        if re.match(r'^[A-Za-z][A-Za-z0-9 _$\'"]*\s*(?:\[[^\]]*\]\s*)?:(?!=)', first):
            m = re.match(r'^([A-Za-z][A-Za-z0-9 _$\']*)', first)
            if m:
                all_names.add(m.group(1).rstrip())
            return

        # Extract variable name (stops at [, =, whitespace that ends the name)
        m = re.match(r'^([A-Za-z][A-Za-z0-9 _$\']*)', first)
        if not m:
            return
        name = m.group(1).rstrip()

        if name in BUILTINS:
            return

        all_names.add(name)

        # Extract doc (third ~-section)
        block_text = '\n'.join(block_lines)
        parts = re.split(r'\n[ \t]*~[ \t]*', block_text)
        if len(parts) < 3:
            return  # no doc field (quick-format or macro stub)

        long_name = extract_long_name(parts[2])
        if long_name is None:
            return

        rename_map[name] = f"{name} {title_case(long_name)}"

    for line in lines:
        stripped = line.rstrip()

        # --- Macro tracking ---
        if stripped.startswith(':MACRO:'):
            if in_block and current_block:
                handle_block(current_block)
            current_block = []
            in_block = False
            in_macro = True
            continue
        if stripped.startswith(':END OF MACRO:'):
            in_macro = False
            current_block = []
            in_block = False
            continue
        if in_macro:
            continue

        # --- Block terminators ---
        if stripped.endswith('~~|'):
            # Single-line quick-format equation (always non-indented)
            if in_block and current_block:
                handle_block(current_block)
            handle_block([line])
            current_block = []
            in_block = False
            continue

        if stripped.endswith('|') and not stripped.endswith('~~|'):
            if in_block:
                current_block.append(line)
                handle_block(current_block)
            current_block = []
            in_block = False
            continue

        # --- Start of new equation (non-indented line) ---
        if line and line[0] not in (' ', '\t'):
            if in_block and current_block:
                handle_block(current_block)
            if re.match(r'^[A-Za-z"]', line):
                in_block = True
                current_block = [line]
            else:
                # Group header etc. — reset, don't start a block
                in_block = False
                current_block = []
            continue

        # --- Continuation line ---
        if in_block:
            current_block.append(line)

    # Flush any trailing block (shouldn't normally happen in valid MDL)
    if in_block and current_block:
        handle_block(current_block)

    return rename_map, all_names


# ---------------------------------------------------------------------------
# Build substitution regex
# ---------------------------------------------------------------------------

def build_regex(rename_map: dict, all_names: set):
    """
    Build a compiled regex covering:
      • All names in rename_map  (will be replaced)
      • All multi-word names in all_names  (protected from partial matches)
    Sorted longest-first so 'Init P' is matched before 'P'.
    The replacer returns rename_map.get(matched, matched), so protected-only
    names are returned unchanged.
    """
    protected = set(rename_map.keys())
    for n in all_names:
        if ' ' in n:
            protected.add(n)
    # Also protect multi-word builtins (TIME STEP etc.)
    for b in BUILTINS:
        if ' ' in b:
            protected.add(b)

    sorted_names = sorted(protected, key=lambda x: -len(x))
    parts = [
        r'(?<![A-Za-z0-9_])' + re.escape(n) + r'(?![A-Za-z0-9_])'
        for n in sorted_names
    ]
    return re.compile('|'.join(parts))


def apply_rename(text: str, regex: re.Pattern, rename_map: dict) -> str:
    return regex.sub(lambda m: rename_map.get(m.group(0), m.group(0)), text)


# ---------------------------------------------------------------------------
# Section processors
# ---------------------------------------------------------------------------

def process_equations(text: str, regex: re.Pattern, rename_map: dict) -> str:
    """
    State-machine pass over the equations section.
    Substitutes in equation expressions; leaves units/doc fields unchanged.
    """
    lines = text.split('\n')
    result = []
    tilde_count = 0
    in_macro = False

    for line in lines:
        stripped = line.rstrip()

        # Macro blocks: pass through unchanged
        if stripped.startswith(':MACRO:'):
            in_macro = True
            result.append(line)
            continue
        if stripped.startswith(':END OF MACRO:'):
            in_macro = False
            result.append(line)
            continue
        if in_macro:
            result.append(line)
            continue

        # Quick-format line ending with ~~|  (equation + value, no doc)
        if stripped.endswith('~~|'):
            result.append(apply_rename(line, regex, rename_map))
            tilde_count = 0
            continue

        # Block terminator  |  (may be on its own or at end of ~ line)
        if stripped.endswith('|') and not stripped.endswith('~~|'):
            result.append(line)  # never substitute in the | line
            tilde_count = 0
            continue

        # Tilde separator line  (~  units  or  ~  doc)
        if re.match(r'^[ \t]*~', line):
            tilde_count += 1
            result.append(line)  # don't substitute in units/doc fields
            continue

        # Blank line
        if not stripped:
            result.append(line)
            continue

        # Non-indented line → start of a new equation
        if line[0] not in (' ', '\t'):
            tilde_count = 0
            result.append(apply_rename(line, regex, rename_map))
            continue

        # Indented line
        if tilde_count == 0:
            # Expression continuation — substitute
            result.append(apply_rename(line, regex, rename_map))
        else:
            # Units or doc continuation — do not substitute
            result.append(line)

    return '\n'.join(result)


def process_sketch(text: str, rename_map: dict) -> str:
    """
    Rename variables in sketch lines:
      Type 10: variable name is fields[2]
      Type 12 with fields[11]=='2': next line is 'VARNAME,GraphType'
    """
    lines = text.split('\n')
    result = []
    i = 0
    while i < len(lines):
        line = lines[i]

        if re.match(r'^10,', line):
            fields = line.split(',')
            if len(fields) > 2:
                fields[2] = rename_map.get(fields[2], fields[2])
                line = ','.join(fields)
            result.append(line)
            i += 1
            continue

        if re.match(r'^12,', line):
            fields = line.split(',')
            if len(fields) > 11 and fields[11] == '2':
                result.append(line)
                i += 1
                # Next line: VARNAME,GraphType
                if i < len(lines):
                    nxt = lines[i]
                    if ',' in nxt:
                        var_part, rest = nxt.split(',', 1)
                        nxt = f"{rename_map.get(var_part, var_part)},{rest}"
                    result.append(nxt)
                    i += 1
                continue

        result.append(line)
        i += 1

    return '\n'.join(result)


def process_graphs(text: str, rename_map: dict) -> str:
    """Rename variables on :VAR lines in the custom-graphs section."""
    lines = text.split('\n')
    result = []
    for line in lines:
        m = re.match(r'^(:VAR\s+)([A-Za-z][A-Za-z0-9 _$\']*)', line)
        if m:
            var_name = m.group(2).rstrip()
            new_name = rename_map.get(var_name, var_name)
            result.append(f"{m.group(1)}{new_name}{line[m.end():]}")
        else:
            result.append(line)
    return '\n'.join(result)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    if len(sys.argv) != 3:
        print("Usage: python rename_vars.py <input.mdl> <output.mdl>")
        sys.exit(1)

    input_file, output_file = sys.argv[1], sys.argv[2]

    with open(input_file, 'r', encoding='utf-8-sig') as f:
        content = f.read()

    # Split into sections at sketch and graph markers
    sketch_marker = '\n\\\\\\---///'
    graph_marker  = '\n///---\\\\\\'

    sketch_pos = content.find(sketch_marker)
    graph_pos  = content.find(graph_marker)

    if sketch_pos == -1:
        eq_text, sketch_text, post_sketch = content, '', ''
    elif graph_pos == -1:
        eq_text      = content[:sketch_pos]
        sketch_text  = content[sketch_pos:]
        post_sketch  = ''
    else:
        eq_text      = content[:sketch_pos]
        sketch_text  = content[sketch_pos:graph_pos]
        post_sketch  = content[graph_pos:]

    # Split post_sketch into custom-graphs and settings
    settings_marker = '\n:L<%^E!@'
    settings_pos = post_sketch.find(settings_marker)
    if settings_pos == -1:
        graphs_text, settings_text = post_sketch, ''
    else:
        graphs_text   = post_sketch[:settings_pos]
        settings_text = post_sketch[settings_pos:]

    # --- Build rename map ---
    rename_map, all_names = parse_equations(eq_text)

    print(f"Rename map — {len(rename_map)} variables:")
    for old, new in sorted(rename_map.items()):
        print(f"  {old!r:20s}  ->  {new!r}")
    print()

    # --- Build regex ---
    regex = build_regex(rename_map, all_names)

    # --- Process sections ---
    new_eq = process_equations(eq_text, regex, rename_map)

    # Each sketch view starts with \\\---///; split preserving the marker
    sketch_parts = re.split(r'(?=\n\\\\\\---///)', sketch_text)
    new_sketch = ''.join(process_sketch(p, rename_map) for p in sketch_parts)

    new_graphs   = process_graphs(graphs_text, rename_map)
    # settings_text passes through unchanged

    output = new_eq + new_sketch + new_graphs + settings_text

    with open(output_file, 'w', encoding='utf-8', newline='\n') as f:
        f.write(output)

    print(f"Written -> {output_file}")


if __name__ == '__main__':
    main()
