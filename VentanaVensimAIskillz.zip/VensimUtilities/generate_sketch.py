#!/usr/bin/env python3
"""
generate_sketch.py
Generate a V300 Vensim sketch from an SD JSON model and inject it into a .mdl file.
Uses Fruchterman-Reingold spring layout (numpy only) with SD-specific post-processing.

Usage:
    python generate_sketch.py input.json model.mdl [output.mdl]
    (output.mdl defaults to model.mdl, updated in place)

Layout strategy:
    1. Run FR spring layout on all variables using relationship edges.
    2. Add strong stock<->flow attractions so flows cluster near their stocks.
    3. Post-process: snap flow valve positions to lie on the axis between
       their source and sink stocks.

V300 sketch elements generated:
    - type 10 shape 3  : stock rectangles (green)
    - type 10 shape 8  : auxiliary/constant circles
    - type 10 shape 40 : flow rate labels (blue, below/beside valve)
    - type 11          : flow valves
    - type 12 shape 0  : clouds (source/sink for single-ended flows)
    - type 1  style 22 : pipe arrows (upstream polarity=100, downstream polarity=4)
    - type 1  style 0  : causal arrows (suppressed where pipe already shows the link)
"""

import json
import math
import re
import sys
import numpy as np
from pathlib import Path

# ── Canvas & layout ───────────────────────────────────────────────────────────
CW, CH  = 1400, 850     # Vensim canvas width / height (pixels)
MARGIN  = 120           # margin from edge to outermost node centre

# ── Element sizes ─────────────────────────────────────────────────────────────
STOCK_W,  STOCK_H  = 60, 26    # fixed width for all stocks (text wraps if long)
AUX_W,    AUX_H    = 50, 20
CLOUD_W,  CLOUD_H  = 10, 8
CLOUD_GAP      = 65   # distance from valve centre to cloud centre (in element generation)
EDGE_CLEARANCE    = 80    # minimum gap from stock edge to valve centre (two-ended flows)
SE_EDGE_CLEARANCE = 170   # larger gap for single-ended (stock-cloud) flows
LABEL_DY       = 34   # rate-label Y offset below a horizontal valve
LABEL_DX_VERT  = 64   # rate-label X offset to right of a vertical valve


def _stock_half_w(_name=None):
    """Half-width of a stock rectangle (fixed width for all stocks)."""
    return STOCK_W / 2


def _valve_gap(_stock_name=None, single_ended=False):
    """Distance from stock centre to valve, ensuring clearance past the stock edge.
    single_ended=True uses the larger SE_EDGE_CLEARANCE for stock-to-cloud flows."""
    clearance = SE_EDGE_CLEARANCE if single_ended else EDGE_CLEARANCE
    return _stock_half_w() + clearance

# ── Colors ────────────────────────────────────────────────────────────────────
C_DEF   = "-1--1--1"

# ── Sketch / graph delimiters (literal backslashes in the MDL text) ──────────
SKETCH_START_TEXT = r'\\\---/// Sketch information - do not modify anything except names'
GRAPH_START_TEXT  = '///---' + '\\\\\\'   # ///---\\\  — opens the custom-graph block
                                           # NOT a sketch terminator; Vensim has no formal
                                           # end-of-sketch marker.  The sketch section ends
                                           # implicitly when ///---\\\, :L<%^E!@, or EOF
                                           # is reached.


# ═══════════════════════════════════════════════════════════════════════════════
# Spring layout
# ═══════════════════════════════════════════════════════════════════════════════

def fr_layout(n, weighted_edges, iterations=500, k=None, seed=42):
    """
    Fruchterman-Reingold layout.
    weighted_edges: list of (u_idx, v_idx, weight) tuples.
    Returns (n, 2) array with positions in [0, 1].
    """
    rng = np.random.default_rng(seed)
    pos = rng.random((n, 2))
    if k is None:
        k = math.sqrt(1.0 / max(n, 1))
    t = 0.10
    dt = t / (iterations + 1)

    for _ in range(iterations):
        # All-pairs repulsion
        delta = pos[:, None, :] - pos[None, :, :]   # (n, n, 2)
        dist  = np.linalg.norm(delta, axis=2)        # (n, n)
        dist  = np.clip(dist, 1e-9, None)            # prevent div-by-zero (incl. same-pos pairs)
        rep   = (k * k / dist ** 2)[..., None] * delta
        disp  = rep.sum(axis=1)                      # (n, 2)

        # Edge attraction
        for u, v, w in weighted_edges:
            diff = pos[v] - pos[u]
            dn   = max(np.linalg.norm(diff), 1e-9)
            f    = w * (dn * dn / k) * (diff / dn)
            disp[u] += f
            disp[v] -= f

        # Move with temperature cap
        dn   = np.linalg.norm(disp, axis=1, keepdims=True)
        dn   = np.where(dn < 1e-9, 1e-9, dn)
        pos += (disp / dn) * np.minimum(dn, t)
        pos  = np.clip(pos, 0.02, 0.98)
        t   -= dt

    return pos


def compute_layout(model):
    """
    Two-phase layout returning dict { var_name: (x, y) } in Vensim pixel coordinates.

    Phase 1: FR spring layout on stocks and flows only, with strong stock<->flow
             attraction.  Flow valves are then snapped to stock midpoints (with a
             perpendicular push-out when stocks are too close) or spread from their
             single-ended stock in cardinal directions.

    Phase 2: Aux/constant variables are placed via a lightweight FR that attracts
             each aux toward the flows/stocks it directly influences, while the
             stock+flow positions are held fixed.
    """
    from collections import defaultdict

    variables   = model['variables']
    rels        = model.get('relationships', [])
    stocks_list = [v for v in variables if v['type'] == 'stock']
    flows_list  = [v for v in variables if v['type'] == 'flow']
    auxes_list  = [v for v in variables if v['type'] == 'variable']

    # ── Phase 1: layout stocks and flows ──────────────────────────────────────
    sf_vars = stocks_list + flows_list
    sf_idx  = {v['name']: i for i, v in enumerate(sf_vars)}
    n_sf    = len(sf_vars)

    sf_edges = []
    for var in stocks_list:                        # strong stock <-> flow attraction
        si = sf_idx[var['name']]
        for fn in var.get('inflows', []) + var.get('outflows', []):
            if fn in sf_idx:
                sf_edges.append((si, sf_idx[fn], 4.0))
    for r in rels:                                 # explicit relationships within sf set
        u, v = r.get('from', ''), r.get('to', '')
        if u in sf_idx and v in sf_idx:
            sf_edges.append((sf_idx[u], sf_idx[v], 1.0))

    sf_raw = fr_layout(n_sf, sf_edges, iterations=500, seed=42)

    pos = {}
    for name, i in sf_idx.items():
        x = MARGIN + sf_raw[i, 0] * (CW - 2 * MARGIN)
        y = MARGIN + sf_raw[i, 1] * (CH - 2 * MARGIN)
        pos[name] = (x, y)

    # ── Post-process: snap flow valves ────────────────────────────────────────
    outflow_only = defaultdict(list)   # src_stock -> [flow_names]  (no sink stock)
    inflow_only  = defaultdict(list)   # snk_stock -> [flow_names]  (no source stock)

    for var in flows_list:
        fname = var['name']
        src = next((sv['name'] for sv in stocks_list
                    if fname in sv.get('outflows', [])), None)
        snk = next((sv['name'] for sv in stocks_list
                    if fname in sv.get('inflows',  [])), None)

        if src and snk:
            sx, sy = pos[src]
            dx, dy = pos[snk]
            mx, my = (sx + dx) / 2, (sy + dy) / 2
            pos[fname] = _push_valve_clear(mx, my, sx, sy, dx, dy, src, snk)
        elif src:
            outflow_only[src].append(fname)
        elif snk:
            inflow_only[snk].append(fname)

    # Determine which cardinal directions each stock has committed to via two-ended pipes.
    # This prevents single-ended flows from being placed in the same direction and overlapping.
    stock_dirs_taken = defaultdict(set)
    for var in flows_list:
        fn = var['name']
        s2 = next((sv['name'] for sv in stocks_list if fn in sv.get('outflows', [])), None)
        k2 = next((sv['name'] for sv in stocks_list if fn in sv.get('inflows',  [])), None)
        if s2 and k2:
            sx2, sy2 = pos[s2];  dx2, dy2 = pos[k2]
            if abs(dx2 - sx2) >= abs(dy2 - sy2):
                stock_dirs_taken[s2].add((1 if dx2 > sx2 else -1, 0))
                stock_dirs_taken[k2].add((-1 if dx2 > sx2 else 1, 0))
            else:
                stock_dirs_taken[s2].add((0, 1 if dy2 > sy2 else -1))
                stock_dirs_taken[k2].add((0, -1 if dy2 > sy2 else 1))

    # Assign single-ended flow positions: outflows first, then inflows.
    # Cycle through [right, left, down, up] skipping directions already taken.
    SE_DIRS = [(1, 0), (-1, 0), (0, 1), (0, -1)]   # right, left, down, up
    for stock_name in sorted(set(outflow_only) | set(inflow_only)):
        taken = set(stock_dirs_taken.get(stock_name, set()))
        sx, sy = pos[stock_name]
        gap   = _valve_gap(stock_name, single_ended=True)
        for fname in outflow_only.get(stock_name, []) + inflow_only.get(stock_name, []):
            placed = False
            # First pass: in-canvas AND not-taken
            for d in SE_DIRS:
                if d not in taken:
                    ox, oy = d
                    vx, vy = sx + ox * gap, sy + oy * gap
                    if MARGIN <= vx <= CW - MARGIN and MARGIN <= vy <= CH - MARGIN:
                        taken.add(d)
                        pos[fname] = (vx, vy)
                        placed = True
                        break
            if not placed:
                # Second pass: allow out-of-canvas but still not-taken.
                # Vensim scrolls, so out-of-canvas positions are valid.
                for d in SE_DIRS:
                    if d not in taken:
                        ox, oy = d
                        taken.add(d)
                        pos[fname] = (sx + ox * gap, sy + oy * gap)
                        placed = True
                        break
            if not placed:
                # True fallback: ignore all constraints
                ox, oy = _best_dir(SE_DIRS, 0, sx, sy, gap)
                pos[fname] = (sx + ox * gap, sy + oy * gap)

    # ── Estimate rate label positions and add them to pos so _place_aux avoids them ──
    rl_pos = {}   # flow_name -> (label_x, label_y)  — "rate label" positions
    for var in flows_list:
        fname = var['name']
        vx, vy = pos[fname]
        src = next((sv['name'] for sv in stocks_list
                    if fname in sv.get('outflows', [])), None)
        snk = next((sv['name'] for sv in stocks_list
                    if fname in sv.get('inflows',  [])), None)
        if src and snk:
            sx, sy = pos[src]; dx, dy = pos[snk]
            orient = 1 if abs(dx - sx) >= abs(dy - sy) else 4
        elif src:
            sx, sy = pos[src]
            orient = 1 if abs(vx - sx) >= abs(vy - sy) else 4
        elif snk:
            dx, dy = pos[snk]
            orient = 1 if abs(vx - dx) >= abs(vy - dy) else 4
        else:
            orient = 1
        if orient == 4:
            rl_pos[fname] = (vx + LABEL_DX_VERT, vy)
        else:
            rl_pos[fname] = (vx, vy + LABEL_DY)

    # Combine valve positions + rate label positions for avoidance.
    # Rate labels use a prefixed key so they don't overwrite the valve entry.
    pos_for_aux = dict(pos)   # stocks + flow valve positions
    for fname, lpos in rl_pos.items():
        pos_for_aux[f'_rl_{fname}'] = lpos   # rate label positions (avoidance only)

    # ── Phase 2: place aux/constants near the flows they influence ────────────
    # Collect all direct aux -> (flow or stock) connections
    explicit  = [(r['from'], r['to']) for r in rels]
    inferred  = list(_infer_eq_links(model))
    aux_tgts  = defaultdict(list)   # aux_name -> list of target names in pos
    for src, tgt in explicit + inferred:
        src_var = next((v for v in auxes_list if v['name'] == src), None)
        if src_var and tgt in pos and tgt not in aux_tgts[src]:
            aux_tgts[src].append(tgt)

    # Compute preferred placement angle for each aux node.
    # Parameters targeting a horizontal flow → below (90°, y increases downward).
    # Parameters targeting a vertical flow   → right (0°, same side as rate label).
    # If an aux targets multiple flows, the first determines the preference.
    aux_preferred_angle = {}
    for aux_var in auxes_list:
        aname = aux_var['name']
        flow_tgts = [t for t in aux_tgts.get(aname, [])
                     if any(v['name'] == t and v['type'] == 'flow' for v in flows_list)]
        if not flow_tgts:
            continue
        fname   = flow_tgts[0]
        vx2, vy2 = pos[fname]
        src2 = next((sv['name'] for sv in stocks_list if fname in sv.get('outflows', [])), None)
        snk2 = next((sv['name'] for sv in stocks_list if fname in sv.get('inflows',  [])), None)
        if src2 and snk2:
            sx2, sy2 = pos[src2];  dx2, dy2 = pos[snk2]
            orient2 = 1 if abs(dx2 - sx2) >= abs(dy2 - sy2) else 4
        elif src2:
            sx2, sy2 = pos[src2]
            orient2 = 1 if abs(vx2 - sx2) >= abs(vy2 - sy2) else 4
        elif snk2:
            dx2, dy2 = pos[snk2]
            orient2 = 1 if abs(vx2 - dx2) >= abs(vy2 - dy2) else 4
        else:
            orient2 = 1
        aux_preferred_angle[aname] = 90 if orient2 == 1 else 0

    pos.update(_place_aux([v['name'] for v in auxes_list], pos_for_aux, aux_tgts,
                           preferred_angles=aux_preferred_angle))
    return pos


def _best_dir(dirs, preferred_idx, sx, sy, gap):
    """
    Return the first direction from `dirs` (starting at preferred_idx) that
    keeps a valve placed `gap` pixels away from (sx, sy) within the canvas.
    Falls back to the preferred direction if none are in-bounds.
    """
    for offset in range(len(dirs)):
        dx, dy = dirs[(preferred_idx + offset) % len(dirs)]
        vx = sx + dx * gap
        vy = sy + dy * gap
        if MARGIN <= vx <= CW - MARGIN and MARGIN <= vy <= CH - MARGIN:
            return dx, dy
    return dirs[preferred_idx % len(dirs)]   # fallback


def _push_valve_clear(mx, my, sx, sy, dx, dy, src_name=None, snk_name=None):
    """
    Given a valve placed at the midpoint (mx, my) of stocks at (sx,sy) and (dx,dy),
    push it perpendicular to the stock-stock axis when either stock is too close,
    so the valve never sits inside a stock rectangle.
    min_dist is based on the wider stock's half-width plus EDGE_CLEARANCE.
    """
    min_dist = EDGE_CLEARANCE + max(
        _stock_half_w(src_name) if src_name else 0,
        _stock_half_w(snk_name) if snk_name else 0,
    )
    axis_x, axis_y = dx - sx, dy - sy
    axis_len = math.sqrt(axis_x ** 2 + axis_y ** 2)
    if axis_len < 1e-9:
        return mx + min_dist, my
    half = axis_len / 2          # midpoint is equidistant from both stocks
    if half >= min_dist:
        return mx, my            # already far enough
    # Push perpendicular to stock-stock axis by the amount needed
    perp_x = -axis_y / axis_len
    perp_y =  axis_x / axis_len
    perp_off = math.sqrt(min_dist ** 2 - half ** 2)
    return mx + perp_x * perp_off, my + perp_y * perp_off


def _place_aux(aux_names, pos_fixed, aux_tgts, preferred_angles=None):
    """
    Place aux/constant variables using a force-directed particle simulation.

    All phase-1 positions in pos_fixed (stocks, flow valves, rate labels, clouds)
    act as repellers.  Each aux is attracted toward the centroid of its target
    nodes via a spring with rest length TARGET_DIST.  The initial position is
    set in the preferred direction (below horizontal flows, right of vertical
    flows), which biases convergence toward that half-plane.

    Processing order: most-connected aux first, so earlier placements also
    become repellers for later ones.

    Returns dict { name: (x, y) }.
    """
    if not aux_names:
        return {}

    # ── Force-directed parameters ──────────────────────────────────────────
    TARGET_DIST = 165.0  # spring rest length: desired separation in sparse areas (px)
    K_ATT       = 0.015  # spring constant pulling toward target centroid (weak — allows
                         #   repulsion to dominate in crowded areas, giving larger gaps)
    K_REP       = 16000  # repulsion constant per phase-1 element (px³)
    DAMP        = 0.72   # velocity damping per step (lower → more overdamped)
    MAX_V       = 20.0   # initial velocity cap; anneals linearly to MIN_V
    MIN_V       = 3.0    # final velocity cap
    N_ITER      = 350    # simulation steps (extra for weak-spring convergence)

    def _stable_hash_angle(name):
        """Deterministic angle 0–359° from variable name."""
        return sum(ord(c) * (i + 1) for i, c in enumerate(name)) % 360

    placed = {}
    sorted_names = sorted(aux_names, key=lambda nm: -len(aux_tgts.get(nm, [])))

    for name in sorted_names:
        tnames = [tn for tn in aux_tgts.get(name, []) if tn in pos_fixed]
        if tnames:
            cx = sum(pos_fixed[tn][0] for tn in tnames) / len(tnames)
            cy = sum(pos_fixed[tn][1] for tn in tnames) / len(tnames)
        else:
            cx, cy = CW / 2, CH / 2

        # Initial position: TARGET_DIST in the preferred direction (or hash direction)
        if preferred_angles and name in preferred_angles:
            init_rad = preferred_angles[name] * math.pi / 180.0
        else:
            init_rad = _stable_hash_angle(name) * math.pi / 180.0
        px = cx + TARGET_DIST * math.cos(init_rad)
        py = cy + TARGET_DIST * math.sin(init_rad)

        # Fixed repellers: all phase-1 positions + previously placed aux nodes,
        # excluding the aux's own target nodes
        all_fixed = {**pos_fixed, **placed}
        non_tgt   = {k: v for k, v in all_fixed.items() if k not in tnames}
        repellers = list(non_tgt.values())   # pre-built list for speed

        vx, vy = 0.0, 0.0
        for step in range(N_ITER):
            fx, fy = 0.0, 0.0

            # Spring: attract toward target centroid at rest length TARGET_DIST
            dcx, dcy = cx - px, cy - py
            dc = math.sqrt(dcx ** 2 + dcy ** 2)
            if dc > 1e-9:
                stretch = dc - TARGET_DIST
                fx += K_ATT * stretch * (dcx / dc)
                fy += K_ATT * stretch * (dcy / dc)

            # Repulsion from all fixed phase-1 elements + placed aux
            for qx, qy in repellers:
                ddx, ddy = px - qx, py - qy
                d = math.sqrt(ddx ** 2 + ddy ** 2)
                if d < 1e-9:
                    d = 1e-9
                rep = K_REP / (d ** 2)
                fx += rep * (ddx / d)
                fy += rep * (ddy / d)

            # Velocity update with damping and annealed velocity cap
            vx = DAMP * vx + fx
            vy = DAMP * vy + fy
            t     = step / max(N_ITER - 1, 1)
            v_cap = MAX_V + (MIN_V - MAX_V) * t   # linear anneal: MAX_V → MIN_V
            speed = math.sqrt(vx ** 2 + vy ** 2)
            if speed > v_cap:
                vx *= v_cap / speed
                vy *= v_cap / speed
            px += vx
            py += vy

        placed[name] = (px, py)

    return {nm: placed[nm] for nm in aux_names}


def _infer_eq_links(model):
    """
    Yield (src_name, tgt_name) pairs inferred from equations.
    For each variable, scan its equation for references to other named variables
    (both underscore and space forms).  Used to draw constant→flow arrows and
    to add layout springs, not already captured in the relationships array.
    """
    variables = model['variables']
    all_names = {v['name'] for v in variables}
    existing  = {(r['from'], r['to']) for r in model.get('relationships', [])}

    for tgt in variables:
        eq = tgt.get('equation', '')
        # Try both underscore and space forms of every other variable name
        for src in variables:
            if src['name'] == tgt['name']:
                continue
            sname = src['name']
            if sname in eq or sname.replace(' ', '_') in eq:
                pair = (sname, tgt['name'])
                if pair not in existing:
                    yield pair


# ═══════════════════════════════════════════════════════════════════════════════
# Element constructors
# ═══════════════════════════════════════════════════════════════════════════════

def node10(nid, name, x, y, w, h, shape):
    """Type-10 variable node. Uses default format: f9=3, f10=0, f11=0, layer=-1, 9 trailing zeros."""
    return f'10,{nid},{name},{round(x)},{round(y)},{w},{h},{shape},3,0,0,-1,0,0,0,0,0,0,0,0,0'


def node11(nid, x, y, orient):
    """Type-11 valve. orient: 1=horizontal (shape 34, 6×8), 4=vertical (shape 33, 8×6)."""
    if orient == 1:
        w, h, shape = 6, 8, 34
    else:
        w, h, shape = 8, 6, 33
    return f'11,{nid},0,{round(x)},{round(y)},{w},{h},{shape},3,0,0,{orient},0,0,0,0,0,0,0,0,0'


def cloud(nid, x, y):
    """Type-12 cloud (shape 0). Field 3 is always 48 per NEWSKETCH.md."""
    return f'12,{nid},48,{round(x)},{round(y)},{CLOUD_W},{CLOUD_H},0,3,0,0,-1,0,0,0,0,0,0,0,0,0'


def pipe_arrow(nid, valve_id, target_id, polarity, wx, wy):
    """Style-22 pipe arrow. polarity=4 downstream, 100 upstream. thickness=192."""
    return (f'1,{nid},{valve_id},{target_id},{polarity},0,0,22,0,192,0,{C_DEF},,1'
            f'|({round(wx)},{round(wy)})|')


def causal_arrow(nid, from_id, to_id, polarity, wx=0, wy=0):
    """Style-0 causal arrow. polarity: 1=+, -1=-, 0=none."""
    return (f'1,{nid},{from_id},{to_id},{polarity},0,43,0,1,64,0,0-0-0,|||0-0-0,1'
            f'|({round(wx)},{round(wy)})|')


# ═══════════════════════════════════════════════════════════════════════════════
# Sketch generator
# ═══════════════════════════════════════════════════════════════════════════════

def is_pipe_link(src_name, tgt_name, model):
    """
    True when the src->tgt relationship is already shown by a flow pipe,
    so no extra causal arrow is needed.
    Cases:
      - flow -> stock  where the flow is in that stock's inflows/outflows
      - stock -> flow  where the flow is in that stock's inflows/outflows
    """
    variables = model['variables']
    sv = next((v for v in variables if v['name'] == src_name), None)
    tv = next((v for v in variables if v['name'] == tgt_name), None)
    if sv is None or tv is None:
        return False
    if sv['type'] == 'flow' and tv['type'] == 'stock':
        return src_name in tv.get('inflows', []) + tv.get('outflows', [])
    if sv['type'] == 'stock' and tv['type'] == 'flow':
        return tgt_name in sv.get('inflows', []) + sv.get('outflows', [])
    return False


def generate_sketch_elements(model, pos):
    """
    Generate V300 sketch element lines.
    Returns list of strings (one per element line).
    """
    _id   = [0]

    def nid():
        _id[0] += 1
        return _id[0]

    lines   = []
    node_id = {}   # var_name -> id of its type-10 node
    rate_id = {}   # flow_name -> id of its rate-label node
    variables = model['variables']

    # ── Stocks ────────────────────────────────────────────────────────────────
    for v in variables:
        if v['type'] != 'stock':
            continue
        n = nid()
        node_id[v['name']] = n
        x, y = pos[v['name']]
        lines.append(node10(n, v['name'], x, y, STOCK_W, STOCK_H, 3))

    # ── Auxiliaries / constants ───────────────────────────────────────────────
    for v in variables:
        if v['type'] != 'variable':
            continue
        n = nid()
        node_id[v['name']] = n
        x, y = pos[v['name']]
        w = max(46, len(v['name']) * 6)
        lines.append(node10(n, v['name'], x, y, w, AUX_H, 8))

    # ── Flows: clouds + pipe arrows + valve + rate label ──────────────────────
    for v in variables:
        if v['type'] != 'flow':
            continue
        fname = v['name']
        vx, vy = pos[fname]

        src_stock = next((sv['name'] for sv in variables
                          if sv['type'] == 'stock' and fname in sv.get('outflows', [])), None)
        snk_stock = next((sv['name'] for sv in variables
                          if sv['type'] == 'stock' and fname in sv.get('inflows', [])), None)

        # Valve orientation
        if src_stock and snk_stock:
            sx, sy = pos[src_stock]
            dx, dy = pos[snk_stock]
            orient = 1 if abs(dx - sx) >= abs(dy - sy) else 4
        elif src_stock:
            sx, sy = pos[src_stock]
            orient = 1 if abs(vx - sx) >= abs(vy - sy) else 4
        elif snk_stock:
            dx, dy = pos[snk_stock]
            orient = 1 if abs(vx - dx) >= abs(vy - dy) else 4
        else:
            orient = 1

        # Compute positions first (before allocating any IDs)
        if src_stock:
            up_x, up_y = pos[src_stock]
            up_stock_id = node_id[src_stock]
        else:
            if snk_stock:
                # Place cloud on the far side of the valve from the sink stock,
                # i.e. extend past the valve in the snk_stock → valve direction.
                dx2, dy2 = pos[snk_stock]
                ddx, ddy = vx - dx2, vy - dy2
                dlen = math.sqrt(ddx ** 2 + ddy ** 2)
                if dlen > 1e-9:
                    ddx, ddy = ddx / dlen, ddy / dlen
                else:
                    ddx, ddy = -1.0, 0.0
                up_x, up_y = vx + ddx * CLOUD_GAP, vy + ddy * CLOUD_GAP
            else:
                up_x = vx - CLOUD_GAP if orient == 1 else vx
                up_y = vy             if orient == 1 else vy - CLOUD_GAP
            up_stock_id = None

        if snk_stock:
            dn_x, dn_y = pos[snk_stock]
            dn_stock_id = node_id[snk_stock]
        else:
            if src_stock:
                # Place cloud on the far side of the valve from the source stock,
                # i.e. extend past the valve in the src_stock → valve direction.
                sx2, sy2 = pos[src_stock]
                ddx, ddy = vx - sx2, vy - sy2
                dlen = math.sqrt(ddx ** 2 + ddy ** 2)
                if dlen > 1e-9:
                    ddx, ddy = ddx / dlen, ddy / dlen
                else:
                    ddx, ddy = 1.0, 0.0
                dn_x, dn_y = vx + ddx * CLOUD_GAP, vy + ddy * CLOUD_GAP
            else:
                dn_x = vx + CLOUD_GAP if orient == 1 else vx
                dn_y = vy             if orient == 1 else vy + CLOUD_GAP
            dn_stock_id = None

        # Plan valve ID: arrows must have lower IDs than valve (matches Vensim convention).
        # Clouds are emitted first, then 2 arrows, then valve.
        n_clouds = (1 if up_stock_id is None else 0) + (1 if dn_stock_id is None else 0)
        vid = _id[0] + n_clouds + 2 + 1

        # Emit clouds
        if up_stock_id is None:
            cid = nid()
            lines.append(cloud(cid, up_x, up_y))
            up_id = cid
        else:
            up_id = up_stock_id

        if dn_stock_id is None:
            cid = nid()
            lines.append(cloud(cid, dn_x, dn_y))
            dn_id = cid
        else:
            dn_id = dn_stock_id

        # Pipe arrows: upstream (polarity=100) FIRST, downstream (polarity=4) SECOND.
        # Both reference the valve ID (vid) which is allocated after the arrows.
        wp_up = ((vx + up_x) / 2, (vy + up_y) / 2)
        wp_dn = ((vx + dn_x) / 2, (vy + dn_y) / 2)
        lines.append(pipe_arrow(nid(), vid, up_id, 100, *wp_up))
        lines.append(pipe_arrow(nid(), vid, dn_id, 4,   *wp_dn))

        # Valve — must receive the pre-planned ID (vid)
        lines.append(node11(nid(), vx, vy, orient))

        # Rate label
        rid = nid()
        rate_id[fname] = rid
        if orient == 4:      # vertical pipe: label to the right
            lx, ly = vx + LABEL_DX_VERT, vy
        else:                # horizontal pipe: label below
            lx, ly = vx, vy + LABEL_DY
        lw = max(46, len(fname) * 6)
        lines.append(node10(rid, fname, lx, ly, lw, 26, 40))

    # ── Causal arrows ─────────────────────────────────────────────────────────
    pol_map = {'+': 1, '-': -1}
    drawn = set()   # (from_id, to_id) already drawn

    def _draw_causal(src, tgt, pol=0):
        if is_pipe_link(src, tgt, model):
            return
        from_id = rate_id.get(src) or node_id.get(src)
        to_id   = rate_id.get(tgt) or node_id.get(tgt)
        if from_id is None or to_id is None:
            return
        key = (from_id, to_id)
        if key in drawn:
            return
        drawn.add(key)
        sx, sy = pos.get(src, (0, 0))
        tx, ty = pos.get(tgt, (0, 0))
        wx, wy = (sx + tx) / 2, (sy + ty) / 2
        lines.append(causal_arrow(nid(), from_id, to_id, pol, wx, wy))

    # From explicit relationships
    for rel in model.get('relationships', []):
        src, tgt = rel.get('from', ''), rel.get('to', '')
        pol = pol_map.get(rel.get('polarity', ''), 0)
        _draw_causal(src, tgt, pol)

    # From inferred equation references (constants/aux → flows/aux)
    for src, tgt in _infer_eq_links(model):
        _draw_causal(src, tgt, 0)

    return lines


def _build_single_view(model, pos, view_name='View 1'):
    """Assemble one V300 view as a string (no end-of-sketch delimiter)."""
    parts = [
        SKETCH_START_TEXT,
        'V300  Do not put anything below this section - it will be ignored',
        f'*{view_name}',
        '$-1--1--1,0,|12||-1--1--1|-1--1--1|-1--1--1|-1--1--1|-1--1--1|96,96,100,2',
    ]
    parts.extend(generate_sketch_elements(model, pos))
    return '\n'.join(parts)


def build_sketch_section(model):
    """Build the complete sketch text for the model, with one V300 view per
    connected component of the stock-flow network.

    Each component's layout is computed independently so the canvas is not
    wasted on unconnected regions.  If the model has only one component (or no
    stocks), a single view is produced.

    Returns a string ready for injection into an MDL file.
    """
    views = _assign_variables_to_views(model)
    sketch_parts = []
    for i, view_vars in enumerate(views):
        stocks_in_view = [v for v in view_vars if v['type'] == 'stock']
        if stocks_in_view:
            # Derive a short view name: abbreviations (first token of each stock
            # name, stripped of subscripts), sorted and joined, max 30 chars.
            abbrevs = sorted({
                re.sub(r'\s*\[.*?\]\s*', '', sv['name']).strip().split()[0]
                for sv in stocks_in_view
            })
            view_name = ' '.join(abbrevs)[:30]
        else:
            view_name = f'View {i + 1}'

        submodel = dict(model, variables=view_vars, relationships=[])
        sub_pos = compute_layout(submodel)
        sketch_parts.append(_build_single_view(submodel, sub_pos, view_name))

    return '\n'.join(sketch_parts)


# ═══════════════════════════════════════════════════════════════════════════════
# MDL injection
# ═══════════════════════════════════════════════════════════════════════════════

def inject_sketch(mdl_text, sketch_text, add_only=False):
    """Insert sketch_text into mdl_text at the correct position.

    Insertion order of preference (all three blocks are optional):
      1. Before ///---\\  (custom-graph block opener)
      2. Before :L<%^E!@   (settings block opener)
      3. At EOF

    add_only=False: strip all existing sketch views first, then insert.
    add_only=True:  leave existing views intact, just insert the new one.

    There is no explicit end-of-sketch delimiter in Vensim MDL; the sketch
    section ends implicitly when the next block marker or EOF is reached.
    """
    def _find_line(text, marker):
        """Return index of the '\n' that immediately precedes `marker` as a
        line-starting token, or len(text) if not found."""
        p = text.find('\n' + marker)
        return p if p != -1 else len(text)

    # Determine insertion point in the original text
    insert_pos = min(
        _find_line(mdl_text, GRAPH_START_TEXT),
        _find_line(mdl_text, ':L<%^E!@'),
    )

    if not add_only:
        # Strip all existing sketch views: from the first \\---/// up to insert_pos.
        first_sketch = mdl_text.find('\n' + SKETCH_START_TEXT)
        if first_sketch != -1 and first_sketch < insert_pos:
            mdl_text   = mdl_text[:first_sketch] + mdl_text[insert_pos:]
            insert_pos = first_sketch   # insertion point shifts accordingly

    result = mdl_text[:insert_pos] + '\n' + sketch_text + mdl_text[insert_pos:]

    # Normalise font: Vensim Sans works cross-platform; Courier is less desirable.
    result = result.replace('104:Courier|', '104:Vensim Sans|')
    # Normalise settings marker: ensure DEL byte is present so Vensim applies
    # 22: unit equivalents before running the batch unit checker.
    result = result.replace(':L<%^E!@', ':L<%^E!@')
    return result


# ═══════════════════════════════════════════════════════════════════════════════
# MDL parser  (for MDL-only mode — no JSON required)
# ═══════════════════════════════════════════════════════════════════════════════

def _parse_net_flow(expr):
    """
    Parse a Vensim net-flow expression like
        'Sapling Maturation-Oak Mortality'
    into (inflows, outflows) lists of variable name strings.
    All terms are variable names; + → inflow, - (or leading term) → outflow.
    """
    expr = re.sub(r'\s+', ' ', expr).strip()   # normalise whitespace
    tokens = re.split(r'([+\-])', expr)
    inflows, outflows = [], []
    sign = '+'
    for tok in tokens:
        tok = tok.strip()
        if tok == '+':
            sign = '+'
        elif tok == '-':
            sign = '-'
        elif tok:
            # Strip subscripts for validation; keep original (subscripted) for storage.
            # If the cleaned token isn't a bare Vensim variable name (e.g. it contains
            # '(', ')', '/', '*'), the net-flow expression is arithmetic rather than a
            # named-variable sum, so skip it (stock renders without pipe-valves).
            clean = re.sub(r'\s*\[.*?\]\s*', '', tok).strip()
            if re.match(r'^[A-Za-z][A-Za-z0-9 _]*$', clean):
                (inflows if sign == '+' else outflows).append(tok)
    return inflows, outflows


def _extract_integ_net_flow(eq_raw):
    """Extract the net-flow expression (first argument) from INTEG(net_flow, initial).

    Uses a bracket-aware walk so the initial-value argument can be any expression
    (variable reference, numeric literal, or complex formula) without breaking the
    parse.  Returns the net-flow string, or None if eq_raw is not an INTEG call.
    """
    m = re.match(r'INTEG\s*\(', eq_raw.strip(), re.IGNORECASE)
    if not m:
        return None
    i = m.end()
    depth = 1
    start = i
    while i < len(eq_raw):
        c = eq_raw[i]
        if c == '(':
            depth += 1
        elif c == ')':
            depth -= 1
            if depth == 0:
                break       # closed without comma — malformed INTEG
        elif c == ',' and depth == 1:
            return eq_raw[start:i]   # net-flow is everything before this comma
        i += 1
    return None


def _parse_control_specs(text):
    """Extract simulation specs from the .Control section of MDL text."""
    specs = {'startTime': 0, 'stopTime': 100, 'dt': 0.25, 'timeUnits': 'year'}
    m = re.search(r'FINAL TIME\s*=\s*([\d.eE+\-]+)', text)
    if m:
        specs['stopTime'] = float(m.group(1))
    m = re.search(r'INITIAL TIME\s*=\s*([\d.eE+\-]+)', text)
    if m:
        specs['startTime'] = float(m.group(1))
    m = re.search(r'TIME STEP\s*=\s*([\d.eE+\-]+)', text)
    if m:
        specs['dt'] = float(m.group(1))
    return specs


# Variable names that belong to the .Control section — not model variables
_CONTROL_NAMES = {'FINAL TIME', 'INITIAL TIME', 'SAVEPER', 'TIME STEP'}


def _parse_variable_blocks(text):
    """
    Parse the equations section of MDL text into a list of variable dicts
    and a set of flow names (variables that appear as inflows/outflows of stocks).

    Returns (variables, flow_names).
    Each variable dict has keys: name, equation, units, documentation,
    inflows, outflows, _is_stock.
    """
    # Each block is terminated by \n\t|
    blocks = re.split(r'\n\t\|', text)

    variables = []
    flow_names = set()

    for block in blocks:
        block = block.strip()
        if not block:
            continue

        # Match: VariableName = <rest>
        m = re.match(r'^(.+?)\s*=\s*(.*)', block, re.DOTALL)
        if not m:
            continue

        name = m.group(1).strip()
        rest = m.group(2)

        # Skip control variables and section headers
        if name in _CONTROL_NAMES:
            continue
        # Skip the *** .Title / .Control *** header blocks (no '=' but caught by regex)
        if name.startswith('*') or '\n' in name:
            continue

        # Split rest on the Vensim ~ separator to get equation / units / doc
        parts = re.split(r'\n\t~\t', rest)
        eq_raw  = parts[0].strip()
        units   = parts[1].strip() if len(parts) > 1 else ''
        doc_raw = parts[2].strip() if len(parts) > 2 else ''
        # Remove line-continuation backslashes from documentation
        doc = re.sub(r'\\\s*\n\s*', ' ', doc_raw).strip()

        is_stock = bool(re.match(r'INTEG\s*\(', eq_raw, re.IGNORECASE))
        inflows, outflows = [], []
        equation = eq_raw

        if is_stock:
            net_expr = _extract_integ_net_flow(eq_raw)
            if net_expr is not None:
                inflows, outflows = _parse_net_flow(net_expr)
                for fn in inflows + outflows:
                    flow_names.add(fn)

        variables.append({
            'name':          name,
            'equation':      equation,
            'units':         units,
            'documentation': doc,
            'inflows':       inflows,
            'outflows':      outflows,
            '_is_stock':     is_stock,
        })

    return variables, flow_names


def _find_stock_components(variables):
    """Return a list of sets, one per connected component of the undirected
    stock-flow graph.  Two stocks land in the same component when they share a
    two-ended flow (i.e. the flow has both a source stock and a sink stock).
    Single-ended flows (cloud → stock, stock → cloud) do not create edges, but
    their stock still appears as a singleton set if it has no two-ended flows.
    """
    from collections import defaultdict

    stocks = [v for v in variables if v['type'] == 'stock']
    flows  = [v for v in variables if v['type'] == 'flow']

    if not stocks:
        return []

    # Union-Find
    parent = {v['name']: v['name'] for v in stocks}

    def _find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def _union(a, b):
        ra, rb = _find(a), _find(b)
        if ra != rb:
            parent[ra] = rb

    for flow in flows:
        fname = flow['name']
        src = next((sv['name'] for sv in stocks
                    if fname in sv.get('outflows', [])), None)
        snk = next((sv['name'] for sv in stocks
                    if fname in sv.get('inflows', [])), None)
        if src and snk:
            _union(src, snk)

    comps = defaultdict(set)
    for sv in stocks:
        comps[_find(sv['name'])].add(sv['name'])
    return list(comps.values())


def _assign_variables_to_views(model):
    """Partition model variables into per-view subsets based on stock-flow
    connected components.

    Each view receives:
      - The stocks in one connected component
      - The flows attached to those stocks
      - Aux/constant variables whose equation references land mostly in this view

    Returns a list of variable lists.  If there is only one component (or no
    stocks at all), returns a single-element list containing all variables.
    """
    from collections import defaultdict

    variables = model['variables']
    stocks_all = [v for v in variables if v['type'] == 'stock']
    flows_all  = [v for v in variables if v['type'] == 'flow']
    auxes_all  = [v for v in variables if v['type'] == 'variable']

    comps = _find_stock_components(variables)
    if len(comps) <= 1:
        return [variables]   # single view: nothing to split

    stock_by_name = {v['name']: v for v in stocks_all}
    flow_by_name  = {v['name']: v for v in flows_all}

    # Map each stock name to its component index
    node_comp = {}
    for i, comp in enumerate(comps):
        for sname in comp:
            node_comp[sname] = i

    # Assign each flow to the component of its source or sink stock
    comp_flows = [[] for _ in comps]
    for flow in flows_all:
        fname = flow['name']
        src = next((sv['name'] for sv in stocks_all
                    if fname in sv.get('outflows', [])), None)
        snk = next((sv['name'] for sv in stocks_all
                    if fname in sv.get('inflows', [])), None)
        ref = src or snk
        if ref and ref in node_comp:
            comp_flows[node_comp[ref]].append(flow)
            node_comp[fname] = node_comp[ref]   # flows are addressable too

    # Assign each aux to the component where it has the most equation references
    all_var_names = {v['name'] for v in variables}
    comp_auxes = [[] for _ in comps]
    for aux in auxes_all:
        eq = aux.get('equation', '')
        counts = [0] * len(comps)
        for vname in all_var_names:
            if vname != aux['name'] and vname in node_comp:
                if vname in eq or vname.replace(' ', '_') in eq:
                    counts[node_comp[vname]] += 1
        best = max(range(len(counts)), key=lambda i: counts[i]) if any(counts) else 0
        comp_auxes[best].append(aux)

    # Assemble per-view variable lists
    views = []
    for i, comp in enumerate(comps):
        view_vars = (
            [stock_by_name[sn] for sn in comp]
            + comp_flows[i]
            + comp_auxes[i]
        )
        views.append(view_vars)
    return views


def parse_mdl_model(mdl_path):
    """
    Parse a Vensim .mdl file into the model dict expected by compute_layout()
    and generate_sketch_elements().

    Returns {'variables': [...], 'relationships': [], 'specs': {...}}.
    Relationships are left empty; _infer_eq_links() handles causal inference
    from equations at layout time.
    """
    with open(mdl_path, 'r', encoding='utf-8') as f:
        text = f.read()

    # Parse control specs before stripping anything
    specs = _parse_control_specs(text)

    # Strip sketch section (and everything after it)
    sketch_pos = text.find(SKETCH_START_TEXT)
    if sketch_pos != -1:
        text = text[:sketch_pos]

    # Strip .Control block (keep text up to the *** before .Control)
    control_pos = text.find('.Control')
    if control_pos != -1:
        cutoff = text.rfind('*', 0, control_pos)
        if cutoff != -1:
            text = text[:cutoff]

    # Parse all variable equation blocks
    variables, flow_names = _parse_variable_blocks(text)

    # Assign types
    for var in variables:
        if var['_is_stock']:
            var['type'] = 'stock'
        elif var['name'] in flow_names:
            var['type'] = 'flow'
        else:
            var['type'] = 'variable'
        del var['_is_stock']

    return {'variables': variables, 'relationships': [], 'specs': specs}


# ═══════════════════════════════════════════════════════════════════════════════
# Entry point
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    """
    Usage:
        python generate_sketch.py input.json model.mdl [output.mdl]
        python generate_sketch.py model.mdl [output.mdl]

    In the first form the JSON supplies model structure; in the second form
    the MDL file is parsed directly (no JSON required).
    """
    args = [a for a in sys.argv[1:] if a != '--add']
    add_only = '--add' in sys.argv[1:]

    if not args:
        print(f'Usage: {sys.argv[0]} [--add] [input.json] model.mdl [output.mdl]')
        sys.exit(1)

    # Detect mode by first positional argument extension
    if args[0].lower().endswith('.json'):
        json_path = args[0]
        mdl_path  = args[1]
        out_path  = args[2] if len(args) > 2 else mdl_path
        with open(json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        model = data['model']
    else:
        mdl_path = args[0]
        out_path = args[1] if len(args) > 1 else mdl_path
        model = parse_mdl_model(mdl_path)

    with open(mdl_path, 'r', encoding='utf-8') as f:
        mdl_text = f.read()

    # Report connected components
    comps = _find_stock_components(model['variables'])
    print(f'\nStock-flow connected components ({len(comps)} view(s)):')
    for i, comp in enumerate(comps):
        abbrevs = sorted(
            re.sub(r'\s*\[.*?\]\s*', '', sn).strip().split()[0] for sn in comp
        )
        print(f'  View {i+1}: {" ".join(abbrevs)[:60]}  ({len(comp)} stock(s))')

    sketch  = build_sketch_section(model)
    updated = inject_sketch(mdl_text, sketch, add_only=add_only)

    with open(out_path, 'w', encoding='utf-8') as f:
        f.write(updated)

    print(f'\nWritten: {out_path}')


if __name__ == '__main__':
    main()
