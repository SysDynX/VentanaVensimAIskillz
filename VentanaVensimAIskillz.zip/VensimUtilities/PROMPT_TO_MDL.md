# Prompt-to-MDL Guidelines

Building a Vensim `.mdl` file from a natural language model description.
For MDL and equation syntax see `MDL.md`, `EQUATIONS.md`, `VENSIM.md` in `..\VensimAgentDocs\`.
For sketch generation see `..\VensimAgentDocs\SKETCH.md` and `generate_sketch.py`.

---

## 1. Elicitation — questions to ask

Work through these in order. Later steps may reveal the need to revisit earlier ones.

### 1a. Core story
- What is the fundamental dynamic the model should capture?
- What grows, what declines, and what drives what?
- What is the main feedback loop?

### 1b. Stocks
Stocks are quantities that accumulate over time and persist.
Rule of thumb: if you "froze time", stocks are the things you could count or measure.

Key question for each candidate: *Can this change instantaneously, or does it have inertia?*
If it has inertia → stock. If it responds instantly → auxiliary.

- What populations, quantities of material, or levels exist in this system?
- Are any of these better represented as separate stocks because they have different dynamics? (e.g., cached vs. loose acorns germinate at different rates → two stocks)
- Are there important intermediate stocks between key stages? (e.g., saplings between germinating acorns and mature trees)
- Should some variables be held constant initially for simplicity, and made dynamic later?

### 1c. Flows
For each stock: what are its inflows and outflows?
Flows have units of **[stock units / time]**.

- What adds to this stock?
- What removes from this stock?
- Does this flow connect two stocks (pipe between stocks), or to/from the "outside world" (cloud)?

### 1d. Drivers and auxiliaries
For each flow: what determines its rate?

- Is the rate proportional to a stock? (first-order decay, growth)
- Does it depend on multiple stocks? (e.g., harvest rate ∝ acorns × squirrels)
- What constants (parameters) are needed?

### 1e. Parameters and initial conditions
- What are reasonable ballpark values for each constant, drawing on domain knowledge?
- Are initial stock values roughly consistent with near-equilibrium? (inflows ≈ outflows at t=0; useful for isolating dynamics rather than transients)
- Which parameters are most uncertain or most worth testing in sensitivity analysis?

### 1f. Scope decisions
Make these explicit before writing the model:

| Decision | Options |
|---|---|
| Complexity | Start simple (hold some stocks constant), add stages incrementally |
| Intermediate stocks | Model transitions instantly vs. explicitly (e.g., sapling stage) |
| Aggregation | One pool or separate pools for distinct sub-populations |
| Exogenous vs. endogenous | What is driven internally vs. set externally |
| Time horizon | Long enough for key dynamics (~5× the longest time constant is a guide) |
| dt | 1/4 to 1/10 of the smallest time constant (Forrester 1961); 0.25 year is a safe default |

---

## 2. Units

### Assign units early
- Every variable must have units.
- Stock units × (1/time) = flow units. e.g., `trees × (1/year) = trees/year` ✓
- Check that multiplication and division cancel correctly for each equation.

### Unit conversion variables
When a flow conceptually converts between different "things" (e.g., acorns germinating into trees), an explicit conversion constant is needed:

```
New Saplings [trees/year] = Germination Flow [acorns/year] × Germination Success [trees/acorn]
```

This variable encodes both the unit conversion and any biological survival probability. Name it
something like `Germination Success`, `Conversion Efficiency`, etc. Document what it represents.

### Singular/plural unit errors
Vensim's unit checker treats `squirrel` and `squirrels` as different units, producing false
errors for natural equations like:

```
Squirrels [squirrels] × Consumption Per Squirrel [acorns/squirrel/year]
→ Has Units: acorns*squirrels/(year*squirrel)   ← Vensim can't simplify this
→ Expected:  acorns/year
```

**Fix:** add `22:singular,plural` lines to the settings block of the `.mdl` file, inside the
`:L<%^E!@` section, before the `15:` line:

```
22:acorn,acorns
22:squirrel,squirrels
22:tree,trees
```

Scan all unit strings for tokens that appear in both singular and plural form. Common examples:
`tree/trees`, `squirrel/squirrels`, `acorn/acorns`, `person/persons`, `firm/firms`.

**Batch vs. GUI behavior:** these lines fix the unit checker in the **Vensim GUI**. The
batch/command-line LOADMODEL unit check runs before the settings block is applied, so
plural/singular errors still appear in `command.log`. This is a known Vensim behavior —
the errors are non-blocking and the model will simulate correctly.

**Distinguishing genuine errors:** if unit errors remain after applying all equivalents, they
likely reflect a genuine conceptual mismatch. Address these with an explicit conversion
variable rather than suppressing them.

---

## 3. MDL file structure

```
{UTF-8}

********************************************************
    .Title
********************************************************~
        Title: narrative description of model purpose and structure.
    |

[Stocks — INTEG equations]
[Flows and auxiliaries]
[Constants]

********************************************************
    .Control
********************************************************~
        Simulation Control Parameters
    |

FINAL TIME  = <stopTime>
    ~   year
    ~   The final time for the simulation.
    |

INITIAL TIME  = <startTime>
    ~   year
    ~   The initial time for the simulation.
    |

SAVEPER  =
        TIME STEP
    ~   year [0,?]
    ~   The frequency with which output is stored.
    |

TIME STEP  = <dt>
    ~   year [0.001,8]
    ~   The time step for the simulation.
    |

\\\---/// Sketch information - do not modify anything except names
V300  Do not put anything below this section - it will be ignored
*View 1
$192-192-192,0,Arial|12||0-0-0|0-0-0|0-0-255|-1--1--1|-1--1--1|96,96,75,0
///---\\\
:L<%^E!@
1:<runname>.vdfx
4:Time
5:Time
9:<runname>
19:74,0
24:<startTime>
25:<stopTime>
26:<stopTime>
23:<startTime>
22:singular1,plural1
22:singular2,plural2
15:0,0,0,1,0,0
27:0,
34:0,
42:0
72:0
73:0
95:0
96:0
97:0
77:0
78:0
102:1
93:0
94:0
92:0
91:0
90:0
87:0
75:
43:
103:8,8,8,3,8
105:0,0,0,0,0,0,0,0,0,0
104:Courier|12||0-0-0|0-0-0|-1--1--1|0-0-255|192-192-192|-1--1--1
```

For equation syntax see `EQUATIONS.md`. For sketch layout see `SKETCH.md` and
`generate_sketch.py`.

---

## 4. Equation ordering convention

1. **Stocks** (INTEG) — define the state variables first
2. **Flows** — in the order they appear as inflows/outflows in the stocks above
3. **Auxiliaries** — intermediate computed quantities
4. **Constants** — parameters, in the order they are first referenced

This order matches the reading flow of the model and is not required by Vensim, but aids
human review.

---

## 5. Testing

Run via command script (see `VENSIM.md` for details):

```
SPECIAL>NOINTERACTION|1
SPECIAL>CONTINUEONERROR|1
SPECIAL>LOADMODEL|mymodel.mdl
SIMULATE>RUNNAME|myrun
MENU>RUN|o
MENU>EXIT
```

Add `MENU>VDF2TAB|!|<runname>.tab` before `MENU>EXIT` to export results.
(`!` is the wildcard for the current run file name; `.vdfx` extension is added automatically.)

Parse `command.log`:
- `sim  <runname>` — simulation completed successfully
- Unit errors — check whether they are plural/singular (non-blocking) or genuine (needs fix)
- Other errors — structural problems requiring correction

Inspect the tab output with `inspect_tab.py`:
```
python inspect_tab.py <runname>.tab [var1 var2 ...] [--times 0 10 50 100 200]
```
The VDF2TAB format is transposed (variables as rows, time as columns).
If no variables are listed, all are shown. Default landmarks: 6 evenly-spaced time points.

---

## 6. Pre-writing checklist

- [ ] All stocks identified with units and initial conditions
- [ ] Every stock has at least one inflow and one outflow (or is clearly a terminal/source)
- [ ] Every flow has a source and sink (stock or cloud) and a units-correct equation
- [ ] Every constant has a value, units, and a brief documentation note
- [ ] Unit conversion variables added where different "things" are connected (e.g., acorns → trees)
- [ ] Singular/plural unit pairs identified for `22:` lines in settings block
- [ ] Time horizon is long enough; dt is small enough relative to fastest time constant
- [ ] Initial conditions are plausible (ideally near equilibrium unless modeling a transient)

## 7. Post-run checklist

- [ ] `sim  <runname>` appears in `command.log`
- [ ] Remaining unit errors are only plural/singular type
- [ ] Open `.vdfx` in Vensim and inspect trajectories for plausibility:
  - Do stocks stay non-negative?
  - Do key variables reach a reasonable steady state or cycle?
  - Are the magnitudes of stocks and flows consistent with real-world intuition?
  - Does the model respond sensibly to a parameter perturbation?


## License

Copyright 2026 Ventana Systems, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
