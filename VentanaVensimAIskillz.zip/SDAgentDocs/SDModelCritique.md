# Issues to Consider While Developing a System Dynamics Model

**Elizabeth K. Keating**  
Kellogg Graduate School of Management, Northwestern University  
Leverone Hall, Room 599, Evanston, IL 60208-2002  
Tel: (847) 467-3343 | Fax: (847) 467-1202 | e-mail: e-keating@nwu.edu

*August 1999*

---

## I. Introduction

Over the past forty years, system dynamicists have developed techniques to aid in the design, development and testing of system dynamics models. Several articles have proposed model development frameworks (for example, Randers (1980), Richardson and Pugh (1981), and Roberts et al. (1983)), while others have provided detailed advice on more narrow modeling issues.

This note is designed as a reference tool for system dynamic modelers, tying the numerous specialized articles to the modeling framework outlined in Forrester (1994). The note first reviews the "system dynamics process" and modeling phases suggested by Forrester (1994). Within each modeling phase, the note provides a list of issues to consider; the modeler should then use discretion in selecting the issues that are appropriate for that model and modeling engagement. Alternatively, this note can serve as a guide for students to assist them in analyzing and critiquing system dynamic models.

---

## II. A System Dynamic Model Development Framework

System dynamics modelers often pursue a similar development pattern. Several system dynamicists have proposed employing structured development procedures when creating system dynamics models. Some modelers have often relied on the "standard method" proposed by Randers (1980), Richardson and Pugh (1981), and Roberts et al. (1983) to ensure the quality and reliability of the model development process.

While Randers (1980) suggests four phases — conceptualization, model formulation, model testing, and implementation/representation — current system dynamics practice seems to fall into five phases that vary somewhat from Randers. First, due to the numerous issues incorporated in the conceptualization phase and different objectives of those tasks, the proposed framework decomposes Randers's initial phase into **analysis** and **design**. Richardson and Pugh (1981) refer to these two stages as *problem identification* and *system conceptualization*, respectively.

Second, and more importantly, Randers suggests model implementation as a final phase as would be found in a system development life cycle model. System dynamics consultants have questioned this view, describing their insights and contributions to organizations as "interventions," "modeling for learning," or "changing mental models" (Senge 1990, Graham 1994, Morecroft 1994). Accordingly, the **implementation phase is depicted as a parallel activity**, overlapping the other four modeling stages.

```
┌─────────────────────────────────────────────────────┐
│            Intervention & Implementation            │
├──────────┬──────────┬─────────────┬─────────────────┤
│ Analysis │  Design  │ Formulation │     Testing     │
└──────────┴──────────┴─────────────┴─────────────────┘
     Figure 2. A System Dynamics Model Development Life Cycle
```

---

## III. The Phases in the System Dynamics Model Development

### A. The Model Analysis Phase

During the model analysis phase, modelers become familiar with the problem area and work to clearly define the purpose of the model. At this point, it is important to assess what is the appropriate modeling technique to study the problem and what trade-offs are made in the selection of the modeling technique.

#### 1. Problem Definition

> *"A model needs a clear purpose."*

- **What is the purpose of the model?** (Forrester 1961, Sterman 1988a). Richardson and Pugh (1981) explain: *"From the system dynamics perspective, a model is developed to address a specific set of questions. One models problems not systems."*

- **What is the nature of the problem being studied?** Linear vs. nonlinear, static vs. dynamic. Forrester (1976) suggests that techniques commonly used by social scientists to analyze statistical data can be inconclusive or misleading when applied to the kind of nonlinear dynamic systems found in real life.

- **What kinds of insights are being sought?** Is it to study optimal or realistic behavior? Is it to better understand normative or positive behavior? According to Senge (1987), statistical methods aim at accurate estimation of model parameters, while simulation methods aid in understanding how the structure of complex systems produces the observed behavior.

- **What is the role of the model?** Is it a descriptive, explanatory, predictive, or teaching model?

- **What are the hypotheses or theory underlying the model?** Are these hypotheses dynamic?

#### 2. Matching the Modeling Technique to the Performance Requirements

> *"Each modeling discipline depends on unique underlying and often unstated assumptions; that is, each modeling method is itself based on a model of how modeling should be done."*

- **What type of modeling technique is appropriate?** Forrester (1973) identifies 5 types of models: mental, descriptive, solvable mathematical, statistical, and system dynamics. The modeling technique should be consistent with the purpose as well as the nature of the problem being studied.

- **What are the assumptions associated with each modeling technique?**

  **a) Discrete vs. Continuous Modeling** — Social scientists often model discrete events and rely upon discrete modeling techniques. In contrast, system dynamicists employ continuous modeling and differential equations (Forrester 1961).

  **b) Correlation vs. Causal** — Most social scientists study correlation relationships, which may or may not be causal. In contrast, system dynamicists examine and model causal relationships. Richardson and Pugh (1980) explain: *"The problem is that correlations made from total system behavior do not measure ceteris paribus causal relationships."*

  **c) Equilibrium** — System dynamics permits disequilibrium modeling, while systems of simultaneous equations assume a stress-free equilibrium. One econometrics text (Kennedy 1993) notes that traditional econometric structural models were too static to represent economies that are more frequently out of equilibrium than in it.

  **d) Parameters** — Econometrics imposes the assumption of equilibrium in order to generate parametric estimates. System dynamics assumes parameters and causal relationships between variables in order to better understand disequilibrium behaviors.

  **e) Feedback** — System dynamicists view capturing feedback processes via stock and flow equations as critically important. In general, econometricians place less emphasis on feedback, using advanced techniques such as instrumental variables to remove feedback effects when necessary.

  **f) Simultaneity and Time Delays** — Econometricians generally view adjustment processes as rapid, justifying simultaneity as an assumption. System dynamicists assume that a time delay is present in every feedback process and that simultaneity can only be approximated through a low time step (dt).

  **g) Determination/Identification of the System** — Both modeling schools require as many independent, consistent equations as unknowns. Economists rely on numerical data and economic theory, while system dynamicists utilize a wider range of data, including unobservable concepts and soft variables (Forrester 1992).

  **h) Linearity/Nonlinearity** — A linear relationship is one in which a variable increases as a constant percentage of another (e.g., y = mx + b). Simulation techniques such as system dynamics allow the modeler flexibility to introduce important non-linearities.

- **Are there additional limitations of the modeling technique selected?**

  **a) Robustness of Results** — Senge observes that parameter estimates derived from OLS and GLS are highly sensitive to errors in data measurement, especially when a model's feedback structure is not completely known.

  **b) Units Consistency** — Drawing upon its foundations in engineering control theory, system dynamicists are encouraged to ensure the consistency of units (Forrester 1973).

- **Should multiple modeling techniques be employed**, either for comparison purposes or to fulfill different needs? Meadows (1980) suggests that econometrics and system dynamics are essentially complementary techniques that should be used to answer different questions.

---

### B. The Model Design Phase

During the model design phase, much of the model conceptualization occurs. Generally, the following topics are examined: variables of interest and reference modes are described; feedback loops are outlined in verbal and causal-loop diagrams; model scope, including time horizon and system boundary, are assessed; and the appropriate level of model aggregation is examined.

#### 1. Variables of Interest

- What are the variables of interest?
- Should the variable be endogenous or exogenous?
- Are pertinent variables included and the unnecessary ones excluded?

#### 2. Reference Modes

Randers describes a reference mode as: *"...a graphical or verbal description of the social process of interest. The reference mode of a model under developed can be stated by drawing a graph of the expected behavior of major variables...Often the reference mode encompasses different possible time paths for the model variables."*

- What are the behavior patterns that the variables display historically? (Randers 1980)
- What are the expected and/or desired future behavior patterns?
- What level of confidence/certainty is associated with these values or patterns?
- What considerations have been given to appropriately "slicing the problem"? (Saeed 1992)

#### 3. Dynamic Hypotheses

Randers describes dynamic hypotheses as the reference modes along with the "basic mechanisms" of a problem — key feedback interactions between variables of interest, depicted in causal loop diagrams.

- What are the core dynamic hypotheses?
- How are they represented in causal-loop diagrams? Stock-flow diagrams?
- Are the dynamic hypotheses meaningful, tangible and specific? (Forrester 1961, Randers 1980)

#### 4. Model Scope

> *"The art of model building is knowing what to leave out."*

- **Boundary Adequacy Test:** Is the boundary of the model appropriate given the purpose? Is the model too complex or too simple? Are the important concepts for addressing the problem endogenous to the model? (Graham 1974, Forrester and Senge 1990, Wittenberg 1992)

  Forrester states: *"...it follows that one starts not with the construction of a model of a system but rather one starts by identifying a problem, a set of symptoms, and a behavior mode which is the subject of the study. Without a purpose, there can be no answer to the question of what system components are important."*

  Richardson and Pugh (1981) define the system boundary as including *"all concepts and variables considered by the modeler to relate significantly to the dynamics of the problem being addressed."*

- **Time Horizon:** What is the appropriate time horizon of the model?

  The time horizon should be related to the issue under study and the potential decisions being considered (Forrester 1973). The model should not be used to develop understanding or predict outside of a narrow time horizon if the structure of the problem is undergoing substantial change. If used for prediction purposes, a longer historical period may be required to improve parameter estimation quality (Pindyck and Rubinfeld 1991).

  Dynamic models should ideally be simulated over a long enough period for transient behavior to play out. Some control theorists suggest this period should be 5 times the longest time delay in the system (Franklin et al. 1986). System dynamicists tend to measure transient time as four times the sum of time constants around the dominant loop (Forrester 1961).

#### 5. Aggregation

- Is the model consistent in its level of aggregation?
- Is a particular construct depicted at the appropriate level of aggregation?

  Forrester suggests four aggregation principles (as reported in Legasto and Maciariello 1980):
  1. Phenomena with similar dynamic behavior may be aggregated together.
  2. Phenomena with different response times may not be mixed together in a model.
  3. Phenomena with similar underlying dynamic structures may be aggregated together.
  4. Model purpose determines the appropriate level of aggregation.

  Alfeld and Graham (1976) offer three conditions for aggregation:
  1. The actions or processes influence the model variables in similar fashion.
  2. The actions or processes respond to conditions represented by model variables in similar fashion.
  3. The depiction of the individual actions or processes is not critical to the utility of the model.

- Is the model at the appropriate level of aggregation given the desired policy tests?

---

### C. The Model Formulation Phase

The model formulation phase entails the construction of the model. Some system dynamicists proceed by writing out the proposed detail structure (with rates, levels, and constants), building the model, testing it, and revising it (Randers 1980). Others, such as Lyneis (1980), construct a core model based on a few feedback loops, conduct extensive testing, then modify formulations and add more feedback loops incrementally.

#### 1. Variable Formulation

- Do variables correspond with the real world? (Forrester 1961, Randers 1980)
- Should a variable be a stock or flow?
- Should the constants be constant? Should the variables be variable?
- Are units dimensionally consistent? (Forrester 1973, Forrester and Senge 1980)
- Are the names understandable and do they clearly convey the meaning? (Kampmann 1991)

#### 2. Formulation of Table Functions

- Are the x-axis and y-axis normalized (dimensionless)? In stress-free equilibrium, does the model use the normal operating point, often (1,1)?
- Does the table function generate unrealistic values? (Kampmann 1991)
- Is the shape of the function smooth? (Alfeld and Graham 1976)
- Is the shape consistent with reference lines that bound the potential values?
- Is there bias implicit in the formulation through an asymmetric table function?
- Does the table function depict a single effect or several dissimilar effects (implying it should be disaggregated)? Is it monotonically increasing or decreasing as disaggregated functions should be?
- What sections of the table function are used? Does the model regularly simulate off one end? If so, what value is assumed by the software?
- If real world data are used to calibrate a table function, did the researcher account for potential perception biases of information sources? (Ford and Sterman 1998)
- If the table is data-driven, is it still robust at the extremes?

#### 3. Other Formulation Issues

- **Extreme Conditions Test:** Are the formulations robust under extreme conditions? (Forrester and Senge 1980, Kampmann 1991, Peterson and Eberlein 1994) For example, if division is present in an equation, can the denominator become zero?

- **System Dynamics Tradition:** Are formulations consistent with the generic structures and "molecules of structure" used commonly in the system dynamics literature? (Forrester 1961, Paich 1985, Richmond et al. 1987, Hines 1996)

- **Discrete vs. Continuous:** Can a discrete formulation (e.g., IF THEN ELSE) be captured more effectively through a continuous (table function) formulation? (Forrester 1961, Kampmann 1991) Do discrete formulations correspond to the real world? Does the discrete formulation obscure bias?

- **Rate Design:** Is the classic "goal, current condition, discrepancy and action" structure present? (Forrester 1961)

- **Parameters:** Are the values of constants and initial stocks reasonable? Are parameters relatively consistent with each other? Are parameters explicit?

- **Initial Conditions:** Are initial stock values set equal to algebraic expressions that are a function of other stocks and parameters in the system rather than numbers?

- **Physical Structures:** Are the "physics of the system" correctly depicted? Are materials conserved? (Structure verification test of Forrester 1973 and Forrester and Senge 1980)

- **Information Structures:** Are the largest and more important information delays in the system present in the model? Are information structures consistent with the real world?

- **Time Delays:** Are time delays correctly depicted as material or informational delays? Is the length of the delay appropriate? Does the delay order chosen approximate well the delayed response of the system? (Hamilton 1980)

- **Decision Rules:** Are the decision rules realistic and boundedly rational? Has bounded rationality been implemented effectively? (Morecroft 1983a, 1983b and 1985, Sterman 1985)

  By bounded rationality, Simon (1976) means: (1) incomplete knowledge, (2) values and outcomes can only imperfectly be anticipated, and (3) not all possible alternatives are known. Morecroft (1983) expands this to: (1) decentralized/local decision making, (2) partial information, and (3) rules of thumb.

#### 4. Other Elements of Model Structure

- **Time Step (dt):** Is the dt selected appropriate? Is the model sensitive to changes in time step?

  Forrester (1961) recommends the time step be 1/4 to 1/10 of the smallest time constant. If dt is too large, it may introduce an implicit delay in feedback (Kampmann 1991) or create integration error (Forrester 1961).

- **Integration Method:** Is the integration method selected appropriate? Is the model sensitive to changes in integration method?

  Euler integration is generally the fastest and simplest. Runge-Kutta is preferable for models with oscillations.

- **Noise:** Are noise variables introduced at appropriate locations in the model? What type of noise is introduced?

  White noise assumes the noise being introduced is uncorrelated with itself. Pink noise assumes serial correlation. While modelers have historically used white noise, pink may more accurately depict real-world processes (Forrester 1961, Richardson and Pugh 1981, Glidden et al. 1995).

---

### D. The Model Testing Phase

The model testing phase includes questioning individual formulations, sections of model structure, as well as the entire model. Unexpected model behavior can lead the modeler to conclude that the model is flawed — causing revision — or that it is one's understanding of the problem that was flawed, leading to valuable insights.

#### 1. Model Validity

- **How do you determine if the model is valid? How do you develop confidence in the model?** (Barlas and Carpenter 1990, Barlas 1996)

  Social scientists often differentiate between construct, internal and external validity. System dynamicists ask whether the constructs correspond to the real world. In a consulting environment, they are often more concerned whether the client has developed confidence in the model.

- **What kinds of predictions or forecasts are the modelers making?** Generally, econometricians seek to make "point predictions," while system dynamicists seek to predict qualitative changes in reference modes.

- **In what operating range do the modelers feel comfortable making model predictions?** System dynamicists attribute many structural changes to a shift in loop dominance created by endogenous factors, and hence feel comfortable making forecasts about model behavior under varied assumptions.

- **Are the results of the model reproducible** from publications or reports? (Sterman 1988a)

- **How is the model documented**, and will the documentation be publicly available? (Robinson 1980, Sterman 1988a)

#### 2. Model Behavior Testing

> *"Testing is the intellectual highpoint of the modeling process."*

- **Behavior Reproduction Test:** How well does the model reproduce the historical reference mode? (Forrester 1973, Senge 1978, Forrester and Senge 1980)

- **Pattern Behavior Test:** Is the model capable of producing realistic future patterns of behavior in terms of periods, phase relationships and shape? (Forrester and Senge 1980)

- **Is the model initialized as a stress-free equilibrium**, in which inflows equal outflows and desired equals actual states?

- **What forms of stressed equilibrium are possible?** Stressed equilibrium exists when inflows equal outflows but not all actual states equal desired. For example, an inventory management system generates a constant level of inventory when production equals shipments, but the specific level may be too low or too high.

- **What is the origin of unusual or unexpected behavior?** Is it generated by the use of discrete formulations or integration error? Is it an unexpected insight into the behavior of the system?

- **Dynamic Analysis:** How does the model respond to various inputs (pulse, step, ramp, sine wave)? Is the transient behavior as expected? What is the long-term behavior (oscillation, limit cycle, or steady state equilibrium)?

- **Does the model display chaotic behavior?** Phase plots can often detect the presence of chaotic behavior (Andersen and Sturis 1988).

- **Parameter Sensitivity Test:** Have the "insensitive many" parameters been distinguished from the "critical few"? (Forrester 1971 and 1973, Forrester and Senge 1980)

- **Behavior Mode Sensitivity:** How does the behavior of the model change under different assumptions? What gives rise to shifts in loop dominance? Has the model been systematically tested to see if it can be pushed into different reference modes? (Mass 1991, Richardson 1995)

  Mass and Senge (1980) ask:
  1. Does omission/inclusion of the factor change predicted numerical values of the system?
  2. Does omission/inclusion of the factor change the behavior mode of the system?
  3. Does omission/inclusion of the factor lead to rejection of formerly favorable policies or reordering of policy preferences?

  Homer (1983) recommends partial model testing to address these questions, allowing the modeler to test a sub-system before adding it to a more complex model.

- **Are the behavioral responses realistic? Boundedly rational?** Could "smarter" agents or better decision rules change outcomes or policy conclusions?

- **Does the model reflect forms of policy resistance present in the real world?** Richardson and Pugh (1981) observe that compensating feedback is a property of real systems: *"parameter change may weaken or strengthen a feedback loop, but the multi-loop nature of a system dynamics model naturally strengthens or weakens other loops to compensate."*

- **Event Prediction Test:** Can the model predict events based on particular changes in circumstances? (Forrester and Senge 1980)

- **Family Member Test:** To what degree is the model generalizable to a family of similar situations? Are the model structures generic?

- **How well is the model calibrated to real-world data?** System dynamicists use statistical tests such as Theil statistics (Theil 1966) and others (Sterman 1984, Barlas 1989 and 1990, Oliva 1996) to assess how well simulated variable values conform to real world data.

- **How is the modeling outcome influenced by the selection of modeling technique?** How might the answer change if a different technique were employed? (Andersen 1980)

- **Are the modeling insights surprising or not?**

#### 3. Policy Implications and Testing

- What structures must be added to accommodate policy testing? Do the structures represent policies that could be instituted in the real world?

- Are the policies effectively implemented in the model from a formulation viewpoint?

- **System Improvement Test:** What behaviors in the system are desirable to improve? What policies/controllers can improve them? (Forrester and Senge 1980)

- **Policy Sensitivity Test:** Is the model sensitive to the policy introduced? Is the policy a leverage point?

  According to Sterman (1997): *"Policy sensitivity exists when a change in assumptions reverses the desirability or impacts of a proposed policy...Policy sensitivity tends to arise when one considers changes in assumptions about model boundary and time horizon."*

- **Is the effectiveness of the policy dependent on the state of the system?** Is the influence of the policy the same if implemented in stress-free equilibrium, stressed equilibrium, near equilibrium, or well out-of-equilibrium?

---

### E. The Model Intervention and Implementation Phase

Systems thinking concentrates on gaining systems insights during the model analysis and design phases, by identifying feedback processes and leverage points that can serve as policy levers (Senge 1990). System dynamicists have also highlighted counterintuitive or "surprise" behavior in systems during formulation and testing as another important source of insights (Forrester 1987a).

While the system dynamics literature describes methods for gaining insights, less focus has been placed on the implementation phase. Today, more emphasis is placed upon converting modeling insights into effective interventions within organizations.

#### 1. Client Interaction

- **What are the key deliverables to the client?** Are the insights learned during the modeling process the key deliverable, or is it a functioning model or simulator?

- **What is the most desirable interaction with a client?** The system dynamics community has become increasingly aware of the limitations of the expert mode of consulting and has emphasized "learner-centered" learning and "modeling as learning" (Graham 1994, Lane 1994).

- **What process will be followed to build the client's confidence in the model and modeling process?**

  **a) Knowledge Elicitation** — The process of building the client's confidence should occur throughout the modeling process. Brainstorming, hexagon, or other group process techniques can be employed to elicit information from clients (Vennix and Gubbels 1994, Hodgson 1994).

  **b) Group Model Building** — An entire issue of the *System Dynamics Review* (Vol. 13, No. 2, Summer 1997) is devoted to articles on group model building and working with clients to build confidence in models.

- **Do the users understand the role of the system, its appropriate uses, and limitations?**

  As Meadows (1980) reminds us: *"A model is simply an ordered set of assumptions about a complex system. It is an attempt to understand some aspect of the infinitely varied world by selecting from perceptions and past experience a set of general observations applicable to the problem at hand...The model we have constructed is, like every other model, imperfect, oversimplified, and unfinished."*

#### 2. Evaluation of the Modeling Process

- **Was scientific method followed?** Scientific method calls for first developing the theoretical basis along with hypotheses, and subsequently testing the hypotheses and searching for disconfirming evidence (Popper 1959).

- **What is the world view held by the modelers?** How may that bias the model, results, and interpretation of results?

  Arrow observes: *"There is really an identified model in the minds of the investigators, which, however, has not been expressed formally because of the limitations of mathematics or of language in general."* Meadows (1980) suggests that system dynamicists believe the real world is non-linear, multi-variable, time-delayed and disaggregated, while economists tend to view the world as linear, open loop, and conforming to economic theory.

  Econometricians are often accused of "tape spinning" — searching for significant relationships rather than developing adequate theory. System dynamicists have been accused of "falling in love with their models," inadequately testing their model against data.

- **What kind of impact did the model and the modeling process have on the world?** Some system dynamicists hold the view that *"Modeling is not functional unless it leads to an improvement of operational conclusions on the client's side."* Others seek to impact the academic community, viewing that knowledge will then be disseminated to a broader audience.

---

## IV. What Next?

By following a rigorous model development methodology, the system dynamics community may benefit from more reliable models that better meet users' needs, are faster to produce, and are more economical to develop. The System Dynamics Model Development Life Cycle framework provides a methodology to be followed when developing a model. As the model moves through the different development phases, the modeler can employ the associated list of issues as a procedures checklist to support the model development process.

Just as systems developers have adapted the traditional systems development lifecycle to be more compatible with new development techniques, system dynamic modelers may find it desirable to expand and modify this framework to be more consistent with their model development approach. For example, some system dynamicists are gravitating to a more object-oriented approach, using software layers (Peterson 1994) and software components such as the molecules of structure described in Hines (1996). Over time, the framework and associated procedures will also need to be expanded and modified to reflect new modeling insights.

---

## Acknowledgments

The author expresses gratitude to David Ford, Andrew Jones, Rogelio Oliva, Michael Radzicki, Donald Seville, and particularly Thomas Fiddaman, for their comments and suggestions.

---

## References

Alfeld, L. E. and A. K. Graham. 1976. *Introduction to Urban Dynamics.* Cambridge, MA: Wright-Allen Press.

Andersen, D. F. 1980. How Differences in Analytic Paradigms Can Lead to Differences in Policy Conclusions. In *Elements of the System Dynamics Method,* ed. by J. Randers. Portland, OR: Productivity Press.

Andersen, D. F. and J. Sturis. 1988. Chaotic Structures in Generic Management Models: Pedagogical Principles and Examples. *System Dynamics Review.* 4(1-2): 218-245.

Arrow, K. J. 1951. Mathematical Models in the Social Sciences. In *The Policy Sciences,* ed. by D. Lerner and H. J. Laswell. Stanford, CA: Stanford University Press.

Barlas, Y. 1989. Multiple Tests for Validation of System Dynamics Type of Simulation Models. *European Journal of Operations Research.* 42(1): 59-87.

Barlas, Y. 1990. An Autocorrelation Function for Output Validation. *Simulation.* July: 7-16.

Barlas, Y. and S. Carpenter. 1990. Philosophical Roots of Model Validation: Two Paradigms. *System Dynamics Review.* 6(2): 148-166.

Barlas, Y. 1996. Formal Aspects of Model Validity and Validation in System Dynamics. *System Dynamics Review.* 12(3): 183-210.

Ford, D. and J. D. Sterman. 1998. Expert Knowledge Elicitation to Improve Formal and Mental Models. *System Dynamics Review.* 14(4): 309-342.

Forrester, J. W. 1961. *Industrial Dynamics.* Cambridge, MA: Productivity Press.

Forrester, J. W. 1968. Market Growth as Influenced by Capital Investment. *Industrial Management Rev. MIT.* 9(2): 83-105.

Forrester, J. W. 1969. *Urban Dynamics.* Cambridge, MA: Productivity Press.

Forrester, J. W. 1973. Confidence in Models of Social Behavior — With Emphasis on System Dynamics Models. D-1967. System Dynamics Group, Sloan School of Management, MIT.

Forrester, J. W. 1985. 'The' Model Versus a Modeling 'Process.' *System Dynamics Review.* 1: 133-134.

Forrester, J. W. 1987a. Lessons from System Dynamics Modeling. *System Dynamics Review.* 3(2): 136-149.

Forrester, J. W. 1987b. Nonlinearity in High-Order Models of Social Systems. *European Journal of Operational Research.* 104-109.

Forrester, J. W. and P. M. Senge. 1980. Tests for Building Confidence in System Dynamics Models. In *System Dynamics,* ed. by A. A. Legasto Jr. et al. New York: North-Holland.

Forrester, J. W. 1992. Policies, Decisions, and Information Sources for Modeling. In *European Journal of Operational Research: Special Issue: Modeling for Learning,* ed. by J. D. W. Morecroft and J. D. Sterman. 59(1).

Forrester, J. W. 1994. System Dynamics, Systems Thinking, and Soft OR. *System Dynamics Review.* 10(2-3): 245-256.

Franklin, G. F., J. D. Powell, and A. Emami-Naeini. 1986. *Feedback Control of Dynamic Systems.* Reading, MA: Addison-Wesley.

Gilden, D. L., T. Thornton, and M. W. Mallon. 1995. 1/f Noise in Human Cognition. *Science.* 267: 1837-1839.

Graham, A. K. 1974. Modeling City-Suburb Interactions. In *Readings in Urban Dynamics,* ed. by N. J. Mass. Cambridge, MA: Productivity Press.

Graham, A. K. 1980. Parameter Estimation in System Dynamics Modeling. In *Elements of the System Dynamics Method,* ed. by J. Randers. Portland, OR: Productivity Press.

Graham, A. K., J. D. W. Morecroft, P. M. Senge, and J. D. Sterman. 1994. Model-supported Case Studies for Management Education. In *Modeling for Learning Organizations,* ed. by J. D. W. Morecroft and J. D. Sterman. Portland, OR: Productivity Press.

Hamilton, M. S. 1980. Estimating Lengths and Orders of Delays in System Dynamics Models. In *Elements of the System Dynamics Method,* ed. by J. Randers. Portland, OR: Productivity Press.

Hines, J. H. 1987. Essays in Behavioral Economic Modeling. Ph.D. Dissertation, MIT Sloan School of Management.

Hines, J. H. 1996. *Molecules of Structure.* System Dynamics Group, Sloan School of Management, MIT.

Hodgson, A. M. 1994. Hexagons for Systems Thinking. In *Modeling for Learning Organizations,* ed. by J. D. W. Morecroft and J. D. Sterman. Portland, OR: Productivity Press.

Homer, J. B. 1983. Partial-Model Testing As A Validation Tool for System Dynamics. In *International System Dynamics Conference Proceedings.* Chestnut Hill, MA.

Isaacs, W. and P. M. Senge. 1994. Overcoming Limits to Learning in Computer-Based Learning Environments. In *Modeling for Learning Organizations,* ed. by J. D. W. Morecroft and J. D. Sterman. Portland, OR: Productivity Press.

Judd, C., M. E. Smith, and L. Kidder. 1991. *Research Methods in Social Relations.* Fort Worth, TX: Holt, Rinehart and Winston.

Kampmann, C. 1991. Replication and Revision of a Classic System Dynamics Model. *System Dynamics Review.* 7(2): 159-198.

Kennedy, P. 1993. *A Guide to Econometrics.* Cambridge, MA: MIT Press.

Kuhn, T. S. 1962. *The Structure of Scientific Revolutions.* 2nd ed. Chicago, IL: University of Chicago Press.

Lane, D. C. 1994. Modeling as Learning: A Consultancy Methodology. In *Modeling for Learning Organizations,* ed. by J. D. W. Morecroft and J. D. Sterman. Portland, OR: Productivity Press.

Lane, D. C. and C. Smart. 1996. Reinterpreting 'Generic Structure': Evolution, Application and Limitation of a Concept. *System Dynamics Review.* 12(2): 87-120.

Legasto, A. A. Jr. and J. Macariello. 1980. System Dynamics: A Critical Review. *TIMS Studies in Management Science.* 14: 23-43.

Loebbecke, C. and T. X. Bui. 1996. Designing and Implementing DSS with System Dynamics. In *Implementing Systems for Supporting Management Decisions,* ed. by Humphreys et al. London: Chapman & Hall.

Lyneis, J. M. 1980. *Corporate Planning and Policy Design: A Systems Dynamics Approach.* Cambridge, MA: Pugh-Roberts Associates.

Mass, N. J. 1991. Diagnosing Surprise Model Behavior: A Tool for Evolving Behavioral and Policy Insights. *System Dynamics Review.* 7(1): 68-86.

Mass, N. J. and P. M. Senge. 1980. Alternative Tests for Selecting Model Variables. In *Elements of the System Dynamics Method,* ed. by J. Randers. Portland, OR: Productivity Press.

MacDonald, R. H. 1996. Discrete Versus Continuous Formulation: A Case Study Using Coyle's Aircraft Carrier Survivability Model. Working Paper, Rockefeller College of Public Affairs and Policy, University at Albany.

Meadows, D. H., D. L. Meadows, J. Randers, and W. W. Behrens III. 1972. *The Limits to Growth.* New York: Universe Books.

Meadows, D. H. 1980. The Unavoidable A Priori. In *Elements of the System Dynamics Method,* ed. by J. Randers. Portland, OR: Productivity Press.

Morecroft, J. D. W. 1983a. Rationality and Structure in Behavioral Models of Business Systems. *International System Dynamics Conference.* Chestnut Hill, MA.

Morecroft, J. D. W. 1983b. System Dynamics: Portraying Bounded Rationality. *Omega.* 11(2): 131-142.

Morecroft, J. D. W. 1985. Rationality in the Analysis of Behavioral Simulation Models. *Management Science.* 31(7): 900-916.

Morecroft, J. D. W. 1994. Executive Knowledge, Models and Learning. In *Modeling for Learning Organizations,* ed. by J. D. W. Morecroft and J. D. Sterman. Portland, OR: Productivity Press.

Oliva, R. 1996. A Dynamic Theory of Service Delivery Implications for Managing Service Quality. PhD Dissertation, Sloan School of Management, MIT.

Paich, M. 1985. Generic Structures. *System Dynamics Review.* 1(1): 126-132.

Peterson, D. W. 1980. Statistical Tools for System Dynamics. In *Elements of the System Dynamics Method,* ed. by J. Randers. Portland, OR: Productivity Press.

Peterson, D. W. and R. L. Eberlein. 1994. Reality Check: A Bridge Between Systems Thinking and System Dynamics. *System Dynamics Review.* 10(2-3): 159-174.

Peterson, S. 1994. Software for Model Building and Simulation. In *Modeling for Learning Organizations,* ed. by J. D. W. Morecroft and J. D. Sterman. Portland, OR: Productivity Press.

Pindyck, R. S. and D. L. Rubinfeld. 1991. *Econometric Models and Economic Forecasts.* 3rd Ed. New York: McGraw-Hill.

Popper, K. 1959. *The Logic of Scientific Discovery.* New York: Basic Books.

Randers, J. 1980. Guidelines for Model Conceptualization. In *Elements of the System Dynamics Method,* ed. by J. Randers. Portland, OR: Productivity Press.

Richmond, B., S. Peterson, and P. Vescuso. 1987. *An Academic User's Guide to STELLA.* Lyme, NH: High Performance Systems.

Richardson, G. P. and A. L. Pugh III. 1981. *Introduction to System Dynamics Modeling with Dynamo.* Portland, OR: Productivity Press.

Richardson, G. P. 1995. Loop Polarity, Loop Dominance and the Concept of Dominant Polarity. *System Dynamics Review.* 11(1): 67-88.

Roberts, E. B. 1972. Strategies for Effective Implementation of Complex Corporate Models. In *Managerial Applications of System Dynamics,* ed. by E. B. Roberts. Cambridge, MA: MIT Press.

Roberts, N., D. Andersen, R. Deal, M. Garet, and W. Shaffer. 1983. *Introduction to Computer Simulation: A System Dynamics Modeling Approach.* Portland, OR: Productivity Press.

Robinson, J. M. 1980. Managerial Sketches of the Steps of Modeling. In *Elements of the System Dynamics Method,* ed. by J. Randers. Portland, OR: Productivity Press.

Saeed, K. Slicing A Complex Problem for System Dynamics Modeling. *System Dynamics Review.* 8(3): 251-261.

Samuelson, P. A. 1947. *Foundations of Economic Analyses.* Enlarged Edition. Cambridge, MA: Harvard University Press.

Senge, P. M. 1977. Statistical Estimation of Feedback Models. *Simulation.* 177-184.

Senge, P. M. 1978. The System Dynamics National Model Investment Function: A Comparison to the Neoclassical Investment Function. PhD Dissertation, System Dynamics Group, Sloan School of Management, MIT.

Senge, P. M. 1990. *The Fifth Discipline: The Art and Practice of the Learning Organization.* New York: Doubleday Currency.

Simon, H. A. 1957. *Models of Men.* New York: Wiley.

Simon, H. A. 1976. *Administrative Behavior.* New York: The Free Press.

Sterman, J. D. 1984. Appropriate Summary Statistics for Evaluating the Historical Fit of System Dynamics Models. *Dynamica.* 10(2): 51-66.

Sterman, J. D. 1985. A Behavioral Model of the Economic Long Wave. *Journal of Economic Behavior and Organization.* 6: 17-53.

Sterman, J. D. 1987. Testing Behavioral Simulation Models by Direct Experiment. *Management Science.* 33(12): 1572-1592.

Sterman, J. D. 1988a. A Skeptic's Guide to Computer Models. In *Foresight and National Decisions: The Horseman and Bureaucrat,* by L. Grant. University Press of America.

Sterman, J. D. 1988b. Deterministic Chaos in Models of Human Behavior: Methodological Issues and Experimental Results. *System Dynamics Review.* 4(1-2): 148-178.

Sterman, J. D. 1997. Assignment #6: Understanding Business Fluctuations. The Causes of Oscillation. D-Memo 4148-9. System Dynamics Group, Sloan School of Management, MIT.

Theil, H. 1966. *Applied Economic Forecasting.* Amsterdam: North-Holland Publishing Co.

Vennix, J. A. M., D. F. Andersen, G. P. Richardson, and J. Rohrbaugh. 1994. Model Building for Group Decision Support. In *Modeling for Learning Organizations,* ed. by J. D. W. Morecroft and J. D. Sterman. Portland, OR: Productivity Press.

Vennix, J. A. M. and J. W. Gubbels. 1994. Knowledge Elicitation in Conceptual Model Building: A Case Study in Modeling A Regional Dutch Health Care System. In *Modeling for Learning Organizations,* ed. by J. D. W. Morecroft and J. D. Sterman. Portland, OR: Productivity Press.

Ventana Systems Inc. 1994. *Vensim: Ventana Simulation Environment Reference Manual.* Belmont, MA: Ventana Systems.

Wittenberg, J. 1992. On the Very Idea of a System Dynamics Model of Kuhnian Science. *System Dynamics Review.* 8: 1.

Wolstenholme, E. F. 1994. A Systematic Approach to Model Creation. In *Modeling for Learning Organizations,* ed. by J. D. W. Morecroft and J. D. Sterman. Portland, OR: Productivity Press.
