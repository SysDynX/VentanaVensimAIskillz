# Calibration Decisions — A Teaching Guide

*How to choose likelihood functions, process noise formulations, priors, estimation methods, and convergence checks when calibrating System Dynamics models.*

**Format**: decision-tree questions with rationale, caveats, and ElkWolves worked examples.
**Verification**: Section 6 walks the ElkWolves project through every decision to confirm the tree gives the right answers.

**Related docs** (Vensim implementation):
- `VensimAgentDocs/CALIBRATION.md` — workflow overview
- `VensimAgentDocs/VOC_VPD.md` — `.voc` and `.vpd` file formats
- `VensimAgentDocs/KALMAN.md` — Kalman filter setup
- `VensimElkWolvesOpt/NOTES.md` — full project documentation

---

## Decision 1: Likelihood / Error Distribution

*What probability model do you put on the gap between model output and data?*

This is the most consequential calibration decision. It determines what "fitting" means and how parameters are identified.

---

### Q1.1 — What are your observations?

**Are they counts of discrete individuals (organisms, events, failures)?**

→ **Candidate: Poisson likelihood**
- Variance = mean: `Var[Y] = λ` where `λ` is the expected count
- Appropriate when: integer counts with no upper bound, detection is (near) complete, each individual is counted independently
- Formula (log-likelihood per observation): `y·log(λ) − λ − log(y!)`

**Caveats for ecological count data**:
Aerial surveys, mark-resight, camera traps, and most field methods yield *subsamples* of the true population — not complete counts. A survey that observes 47 elk does not mean 47 elk are present; it means ≥47 elk are present with some unknown detection probability. When detection is < 100%:
- The observed count is smaller than the true population size
- Detection varies by terrain, weather, observer experience, habitat
- Uncertainty in the observation is *not* just Poisson — it also includes detection uncertainty
- **Prefer Gaussian or log-Gaussian** over Poisson for real field data unless detection is verified near-complete

Use Poisson for:
- Synthetic/simulated data where the stochastic process is explicitly Poisson
- Laboratory counts with near-complete detection
- Theoretical analysis and model specification

**Are they proportions or binary outcomes (0/1)?**

→ **Candidate: Binomial likelihood**
- `Y ~ Binomial(n, p)`: `n` known trials, probability `p` of success
- Appropriate for: mortality per time step (each individual dies with probability p), detection/non-detection, disease prevalence
- Note: in SD flow equations, per-step mortality probability often appears explicitly (see ElkWolves `Elk decrease rate`)

**Are they continuous measurements (length, mass, temperature, index value)?**

→ **Candidate: Normal (Gaussian) likelihood**
- Variance either known (fix it) or unknown (estimate with log-normal prior)
- Appropriate when: measurement errors are symmetric, additive, and bounded far from zero
- Default for most SD calibration; robust to mild assumption violations

**Are errors likely multiplicative (percentage errors, not absolute errors)?**

→ **Candidate: Log-normal or Log-Gaussian likelihood**
- `log(Y) ~ Normal(log(μ), σ²)`
- Appropriate when: quantities span orders of magnitude; errors are proportional to the level (a 10% error on 1000 elk is different from a 10% error on 10 elk in an important way); quantities are strictly positive
- Vensim: `*CGL` directive; weight is the SD fraction `σ`

**Are residuals likely heavy-tailed or do you suspect outliers?**

→ **Candidate: Student-t likelihood**
- Fatter tails than Gaussian; down-weights outliers automatically
- Not natively supported in Vensim's `.vpd` directives; requires a custom payoff expression or preprocessing
- Consider when: data has measurement anomalies you can't explain, or when Gaussian residuals have persistent kurtosis

---

### Q1.2 — Is measurement variance known or unknown?

**Known (from sensor specs, prior studies, repeatability tests)**:
- Fix it in the model. Estimating may introduce unnecessary uncertainty and can make noise identification underdetermined or slow optimization.
- In Vensim: set `Est elk measurement var frac = knownValue` as a constant; do not include it in the `.voc` parameter list
- Caveat: if it's important, you may want to estimate it, but with a strong prior based on the known variance. Specs are not always the whole story.

**Unknown**:
- Estimate it as a free parameter
- Use a log-normal prior (positive, scale-invariant): `LOGNORMAL(expected_frac, CV)`
- If you have a physical argument for the scale (e.g., Poisson implies frac ≈ 1), center the prior there
- If completely uncertain, use `LOGNORMAL(1, 1)` — broad prior; allows values from roughly 0.1 to 10

**ElkWolves**: unknown → estimated with `LOGNORMAL(1, 1)`. Posterior: elk frac ≈ 0.37, wolf frac ≈ 0.99.

---

### Q1.3 — Is your model continuous or stochastic?

**Continuous model (deterministic SD)**:
- Choose based on the data type (Q1.1): Normal for continuous measurements, log-normal for multiplicative errors
- Simple `*C` (weighted squared error) is numerically equivalent to Gaussian maximum likelihood when variance is fixed

**Stochastic model (with explicit random flows)**:
- The model itself generates process noise → the likelihood should account for both process and measurement noise
- Use the **Kalman filter** (`*CK`): it propagates a covariance matrix that tracks both sources of uncertainty through time
- Without the Kalman filter, the likelihood only sees measurement noise; process noise makes the model internally inconsistent with a deterministic likelihood
- Caveat: for large models, the Kalman filter may be computationally impractical

---

### Decision 1 Summary

```
What are your observations?
├── Integer counts, near-complete detection, synthetic data → Poisson (*CP)
│   └── But real ecological field data: detection < 100% → see Gaussian below
├── Proportions or binary outcomes → Binomial
│   └── (model in flows, not in likelihood; use Gaussian on transformed proportion)
├── Continuous measurements, additive errors → Gaussian (*C or *CK)
│   ├── Is variance known? → fix it
│   └── Is variance unknown? → estimate with LOGNORMAL prior
└── Multiplicative errors, log-scale → Log-Gaussian (*CGL)

Is the model stochastic (process noise matters)?
├── Yes + want state tracking → Kalman filter (*CK); see Decision 2 first
└── No → standard weighted payoff (*C or *CGL)
```

---

## Decision 2: Process Noise (Driving Noise)

*Does the true system state vary stochastically beyond what your parameters predict?*

Process noise (also called driving noise, system noise, or state noise) is variation in the true state that cannot be explained by parameter uncertainty alone. In Kalman filter terminology this is the Q matrix — the covariance of the state transition noise.

---

### Q2.1 — Is there genuine stochasticity in the system dynamics?

**No** (system is deterministic, only parameter uncertainty matters):
- No process noise needed; driving noise = 0
- Standard Powell or MCMC calibration; no Kalman filter
- Example: a deterministic economic model where variation comes only from different scenarios, not random shocks

**Yes** (dynamics include genuine randomness):
- Births and deaths of individuals (demographic stochasticity)
- Environmental stochasticity (random weather, random resource availability)
- Measurement error in model inputs that propagates to state uncertainty
→ Process noise is appropriate; see Q2.2

**Ambiguous** (you're unsure):
- Start without process noise; check residuals (see Decision 5)
- If residuals show systematic autocorrelation → model is missing structure → add process noise or improve model

---

### Q2.2 — Can you derive the process variance analytically?

**Yes** (the stochastic flow structure is known):
- Derive Q from the distributional assumptions on flows
- This strongly identifies Q; no need to estimate it from data alone
- Example: if births are Poisson(rate·dt), variance per unit time = rate; if deaths are Binomial(n, p·dt), variance per unit time = n·p·(1−p·dt)
- Combine independent flows by summing their variances

*ElkWolves derivation*:
```
Elk increase:  Poisson(Elk·α·dt)     → variance/time = Elk·α
Elk decrease:  Binomial(Elk, m·dt)   → variance/time = Elk·m·(1−m·dt)
Total:  Elk Driving Var = Elk·(α + m·(1−m·dt))
```
This is the formula in the estimator model, implemented in `Elk Driving Var` and `Wolf Driving Var`.

**No** (you know noise exists but can't derive its form):
- Estimate a **driving noise scale** as a free parameter: `Est Elk driving noise scale`
- Q entry = `Elk Driving Var × scale`, where `Elk Driving Var` provides the shape (how Q varies with state) and the scale parameter adjusts the magnitude
- Use a log-normal prior on the scale (positive, uncertain over orders of magnitude)
- If you don't even know the shape: use a constant Q and estimate it directly, or parameterize Q ∝ state (common in ecological models)

---

### Q2.3 — Are driving noise scales known?

**Known** (from laboratory experiments, theoretical argument):
- Fix the scale (= 1 if the formula is exact)

**Unknown** (most cases):
- Estimate as a free parameter with log-normal prior
- `LOGNORMAL(1, 1)` if scale ≈ 1 is plausible (i.e., the derivation is believed approximately correct)
- `LOGNORMAL(0.5, 1)` if you believe noise is smaller than the analytical formula predicts

**ElkWolves**: scales unknown; estimated with `LOGNORMAL(1,1)`. Posterior: elk scale ≈ 0.94, wolf scale ≈ 0.10.

---

### Q2.4 — Are noise scales identifiable?

Process noise and measurement noise are often **hard to identify separately** with limited data. Two observationally equivalent models can produce the same time series:
- High process noise + low measurement noise: state jumps around, perfectly observed
- Low process noise + high measurement noise: state is smooth, observations are noisy

To improve identifiability:
- Use an analytical formula for Q (locks in the Q shape; only scale is free)
- Use strong priors when you have physical arguments
- Increase data density (more frequent observations) — measurement noise is identifiable at short time scales; process noise is identifiable at longer scales
- Observe multiple correlated state variables (cross-variable constraints help)

**ElkWolves**: near-identification problem. The wolf driving noise scale (0.10) is much lower than the elk scale (0.94) — wolves are more predictable. This makes sense biologically but was not assumed; it emerged from the data. However, this may be an artifact of a single realization, which could be verified by repeated synthetic data experiments.

---

### Decision 2 Summary

```
Is there genuine process noise?
├── No → set driving noise = 0; no Kalman filter
└── Yes → use Kalman filter (Decision 4)
    ├── Can you derive Q analytically from flow distributions?
    │   ├── Yes → use analytical formula; estimate scale only
    │   └── No → estimate Q or Q-scale directly with LOGNORMAL prior
    └── Are noise scales identifiable from available data?
        ├── Yes → estimate freely
        └── No → use strong prior or fix from physical argument
```

---

## Decision 3: Priors

*What do you believe about parameter values before seeing the data?*

Priors matter most for:
- Parameters that are weakly identified from data (noise scales, initial conditions)
- MCMC runs (priors explicitly enter the posterior)
- Powell optimization when bounds are the only constraint (uniform prior within bounds)

---

### Q3.1 — What are the hard physical bounds?

Always establish hard bounds before choosing a prior distribution:
- Rates and fractions: [0, 1] or [0, some_max]
- Counts and populations: [0, physical_maximum]
- Variance fractions: (0, large_upper_bound] — strictly positive

In Vensim `.voc`: `lo <= Parameter <= hi` defines bounds; the prior (if any) is applied within these bounds.

**Key**: bounds act as a hard uniform prior in MCMC. If you specify no prior distribution (just bounds), MCMC treats [lo, hi] as a uniform prior. For well-constrained dynamics parameters (growth rates, predation rates), this is often fine.

---

### Q3.2 — What is the parameter's physical character?

**Rate, fraction, probability (positive, often < 1)**:
→ Log-normal prior if uncertain over an order of magnitude
→ Beta prior if bounded [0, 1] and you have shape knowledge (alternative — use bounds + LOGNORMAL or PERT which is a generalized Beta)
→ Uniform if only bounds are known

**Scale parameter (positive, uncertain over orders of magnitude)**:
→ Log-normal: `LOGNORMAL(expected_value, CV)`
→ Example: variance fractions, noise scale multipliers
→ Justification: log-normal is the maximum-entropy distribution for a positive quantity with known mean and CV; it gives equal probability per decade (scale-invariant)
→ Non-informative alternative: SCALE, which is log-uniform between the parameter's bounds

**Location parameter (can be negative, symmetric uncertainty)**:
→ Normal: `NORMAL(mu, sigma)`
→ Example: initial conditions expressed as deviations from reference

**Bounded parameter with a known most-likely value (triangular/PERT)**:
→ PERT: `PERT(lo, mode, hi)`
→ Example: expert judgment about a parameter range with a best guess

**Initial conditions (relative to a reference)**:
→ Usually a modest uniform or log-normal range around 1.0
→ ElkWolves: `0.5 <= Relative initial elk <= 2` — uniform, because the initial state is poorly constrained but must be positive

---

### Q3.3 — Do you have previous estimates?

**Yes** (from prior literature, previous model version, earlier calibration run):
- Use a normal or log-normal prior centered on the previous estimate
- Width (sigma) should reflect your confidence in that estimate's applicability to the current context
- Example: `LOGNORMAL(0.1, 0.2)` for `Elk other mortality rate` in `MC-ad.voc` — centered at 0.1 (known from prior study), narrow CV=0.2 (confident in the order of magnitude)

**No**:
- Use diffuse priors: `LOGNORMAL(1, 1)` or `UNIFORM(lo, hi)`
- Let data dominate

---

### Q3.4 — Are any parameters practically unidentifiable?

Some parameters may be near-collinear — the likelihood surface is flat along certain directions:
- `Elk fractional growth rate alpha` and `Elk other mortality rate` in ElkWolves: both increase the gross inflow/outflow; high alpha + high mortality ≈ low alpha + low mortality for some trajectories
- In this case, a prior on one (or both) is essential to prevent the optimizer from running to a boundary, or MCMC sampling all the feasible pairings

Signs of near-unidentifiability:
- Parameter estimate sits at its bound
- Different restarts converge to very different values with similar payoffs
- MCMC posterior is nearly as wide as the prior
- MCMC joint posterior for 2 or more parameters is nearly linear

Responses:
1. Add informative prior on the problematic parameter
2. Reduce the model — if parameters are collinear, one of them may not be separately identifiable; consider fixing the less important one
3. Collect additional data that can distinguish the two effects - for example, attempt to observe elk births or mortality directly

---

### Decision 3 Summary

```
For each free parameter:
1. Set hard bounds (physical constraints)
2. Choose prior type by physical character:
   - Positive, scale-uncertain → LOGNORMAL(expected, CV)
   - Bounded [lo,hi], symmetric → UNIFORM (= no prior spec in .voc)
   - Bounded with mode → PERT(lo, mode, hi)
   - Previous estimate → NORMAL or LOGNORMAL centered on prior estimate
3. Widen priors if data is rich; tighten if data is sparse or parameters weakly identified
4. If parameter hits its bound post-calibration → tighten bound or add prior
```

---

## Decision 4: Estimation Method

*What algorithm do you use to find parameter values and quantify uncertainty?*

---

### Q4.1 — Do you need uncertainty quantification?

**No** (only need a point estimate):
→ Powell optimizer is sufficient
→ Fast, deterministic, scales well to many parameters
→ Use multiple restarts (`RESTART_MAX=4+`) if the likelihood surface is rough

**Yes** (need credible intervals, posterior distributions, predictions with uncertainty):
→ MCMC is required for proper Bayesian uncertainty
→ Alternatively: likelihood profile intervals from the `:SENSITIVITY=Payoff Value=` threshold, but this is less complete than MCMC
→ Powell first to find a starting point, then MCMC from there

---

### Q4.2 — Does the model have significant process noise?

**No** (deterministic model, or process noise negligible):
→ Standard parameter estimation: Powell or MCMC on the parameter space
→ Payoff: weighted squared error (`*C`) or Gaussian log-likelihood

**Yes** (meaningful stochastic dynamics):
→ **Kalman filter is relevant**
→ The Kalman filter tracks state covariance through time, combining model predictions with observations at each step
→ Without it: the likelihood ignores process noise → incorrect uncertainty quantification → parameters absorb noise as apparent signal

*Does estimation need to track unobserved state trajectories?*
→ **Yes**: Kalman is especially valuable — it computes optimal state estimates alongside parameters, and unobserved states are included as they reveal themselves through the dynamics
→ **No** (all states are observed): Kalman is still useful for likelihood computation, but state tracking benefit is reduced

---

### Q4.3 — Powell vs. MCMC: when to use each?

These are **complementary**, not alternatives. The standard workflow is Powell first, then MCMC.

**Powell alone** when:
- Only point estimates needed; uncertainty not required
- Computation budget is tight
- Likelihood surface is smooth and unimodal (verify with multiple restarts)
- Preliminary scoping run before deciding whether to do MCMC

**MCMC alone** when:
- You have a known good starting point (from prior study or previous run), or
- You can afford the computation to start dispersed and converge
- You need the full posterior from the start (e.g., sequential updating)

**Both (recommended default)**:
- Step 1 — Powell: fast local search; gets to a good starting region; identifies approximate scale of each parameter's uncertainty
- Step 2 — MCMC from Powell output: explores the posterior region; quantifies uncertainty; reveals multimodality

**MCMC settings to consider**:

*Chain count and parallelism*:
- `MCNCHAINS` controls number of chains per parameter; need at least 2, or more for hard likelihoods; potentially diminishing returns beyond ~4× the number of free parameters
- `MAX THREADS` variable in the model controls paralellism but can be omitted for automation; hardware with high core counts is desirable
- More chains → better convergence diagnostics; better exploration of multimodal posteriors

*Burn-in*:
- Discard the early part of each chain (exploration before convergence)
- `MCBURNIN / MCLIMIT` ≈ 0.9 is conservative but safe for complex likelihoods
- Check convergence with PSRF and Gelman-Rubin R-hat (below)

*Move size, jumps and randomness*:
- Goal: tune size of movements to achieve acceptance rate ≈ 20–30%
- If moves are too small → slow mixing; too large → low acceptance (mostly rejections)
- Potential starting point: use adaptive MCMC, MCADAPT>0 (`MCADAPT=0.1` in `MC-ad.voc`) to tune automatically
- `MCGAMMA=1` scales differential evolution move size
- `MCDELTA` and `MCEPSILON` control additive and multiplicative noise, and should be small values
- `MCXOVER` controls crossover and `MCJUMP=0.05` determines the propability of mode-jumping iterations with 100% crossover

*Annealing*:
- If your likelihood surface is rough and multimodal, you can raise the initial temperature `MCTEMP` to explore more widely. Set the inital temperature to something greater than the height (in payoff terms) of the barrier between modes.
- Set a cooling schedule type with `MCSCHEDULE` nonzero (3=linear which may be a good start) and `MCCOOLING` for duration, perhaps 50% - 80% of burnin iterations.
- The final temperature `MCFTEMP` should normally stay at 1, unless you think the payoff is biased in some way

---

### Q4.4 — Is your model fast or slow?

**Fast** (milliseconds per simulation):
→ Run many chains, many iterations (ElkWolves: ~1ms → 64 chains × 32K = ~2M sims feasible)
→ MCMC is practical

**Slow** (seconds to minutes per simulation):
→ Powell is more practical for point estimates
→ For MCMC: reduce `MCLIMIT`; consider parallel chains carefully (each chain runs sequentially, so wall time = iterations × sim_time / threads)
→ Consider surrogate/emulator approaches (not in Vensim natively)

---

### Decision 4 Summary

```
Do you need uncertainty quantification?
├── No → Powell (single or multiple restarts)
└── Yes → Powell first, then MCMC

Does the model have significant process noise?
├── No → standard payoff (*C or *CGL)
└── Yes → Kalman filter (*CK); proceed with Powell+Kalman → MCMC+Kalman

Computation budget:
├── Generous → XParallel MCMC, many chains (64+), long chains (10K+)
├── Moderate → Powell (multi-start) + MCMC (fewer chains, shorter chains)
└── Tight → Powell only; or Powell + profile intervals from :SENSITIVITY=Payoff Value=

Final recommended default workflow:
  1. Powell (6 core params, no filter) → point estimate
  2. Powell (all params, Kalman on, 4+ restarts) → refined estimate
  3. MCMC (all params, Kalman on, 64 chains, XParallel) → full posterior
  4. Sensitivity (posterior draws, Kalman off) → prediction uncertainty
```

---

## Decision 5: Checking Results

*How do you know if the calibration succeeded and the model is correctly specified?*

---

### Q5.1 — Did the optimizer converge?

**Powell**: check `.out` header:
- `Normally terminated optimization` → converged to tolerance
- `Abnormally terminated` → hit iteration limit; either increase `MAX_ITERATIONS` or the surface is very flat

**Multiple restarts**: do all restarts converge to the same payoff value?
- Check this by examining the _endpoint .dat or .tab files or .log
- Yes → single mode; result is robust
- No, but differences are small (< 5% of best payoff) → multiple local optima with similar posterior probability; MCMC will resolve
- No, large differences → surface is highly multimodal; increase `RESTART_MAX`; consider stronger priors

**MCMC**: check `.out` header for payoff and simulation count. Inspect the `_sample.tab` posterior sample files — do they show a consistent mode?

---

### Q5.2 — Are parameter estimates reasonable?

For each parameter, check:

1. **Does it sit at a bound?** → Near-unidentifiability or wrong prior; consider fixing the parameter or adding an informative prior, or correcting the bounds
2. **Is it far from the true/expected value?** → Potential misspecification or identification problem; check Q5.3
3. **Do different restarts give different values with similar payoffs?** → Parameters are interchangeable in their effect; model may need restructuring
4. **ElkWolves example**: `Elk fractional growth rate alpha` estimated at 0.82 (true: 0.40). High alpha + high `Elk other mortality rate` (0.49, true: 0.10) → identification problem on sparse data; the two parameters compensate each other.

---

### Q5.3 — Kalman whiteness test: are innovation residuals white noise?

**What it checks**: at each observation time, the Kalman filter computes an innovation (observed − predicted). If the model is correctly specified, these should be serially uncorrelated (white noise). Autocorrelation indicates systematic model error.

**Interpretation**:
- No significant autocorrelation → model is consistent with data
- Autocorrelation at lag 1 → model missing fast dynamics or errors in measurement timing
- Autocorrelation at lag k·SAVEPER → model missing a cycle of that period
- Persistent positive autocorrelation → model systematically biased (wrong sign or structure)
- Persistent negative autocorrelation → model overcompensating (too strong a feedback)

**Vensim**: `kalman.prm` sets `LAGMax=4` (check 4 lags) and `NSDWt=4.0` (flag at 4 sigma). Check the optimization log or payoff report for whiteness test output.

**Response to whiteness test failure**:
1. Examine which variable and which lag has the problem
2. Consider: missing feedback, wrong functional form, missing state variable
3. Add process noise (if autocorrelation looks like random walks that the model can't track) — but this treats symptoms, not cause

---

### Q5.4 — MCMC convergence: Gelman-Rubin R-hat

**What it checks**: compares between-chain variance to within-chain variance. If all chains have mixed and converged to the same distribution, between ≈ within → R-hat ≈ 1.

**Interpretation**:
- R-hat < 1.1: conventionally accepted as converged
- 1.1 < R-hat < 1.2: borderline; consider longer chains or more burn-in
- R-hat > 1.2: not converged; chains are in different parts of the parameter space

**Common causes of poor convergence**:
- Burn-in too short → increase `MCBURNIN`
- Jump size too small or too large → tune `MCJUMP`; use `MCADAPT`
- Multimodal posterior → chains stuck in different modes; increase `RESTART_MAX` and check whether modes are meaningfully different
- Bad starting point → run Powell first

**Vensim**: Check the MCMC output report in the .log or _stats.dat files for convergence diagnostics.

---

### Q5.5 — Posterior predictive check: do predictions match data?

Run the model forward with posterior parameter draws (sensitivity run using the _sample.vsc) and compare the resulting trajectories to the observed data:

- **Prediction envelopes should contain most observed data points** (approximately 95% within 95% interval)
- If envelopes are too narrow → model overconfident; process noise underestimated; or MCMC didn't explore enough
- If envelopes are too wide → model underconfident; overly diffuse priors; or systematic bias that MCMC compensated with uncertainty

**ElkWolves**: the `SensitivityTest.cmd` runs 8 sensitivity groups on the sparse dataset and exports to TAB. Comparing `block0` to `block1` output distributions checks convergence; comparing envelopes to the data used, e.g., `DataSparse.vdfx`, checks calibration quality.

---

### Q5.6 — Sensitivity to priors

Especially for weakly identified parameters, check whether results change substantially if you tighten or loosen priors:

- **Robust result**: posterior is similar across reasonable prior choices → data is informative
- **Prior-dominated result**: posterior closely tracks prior → data has little information; you are reporting your prior beliefs, not learned from data
- For prior-dominated parameters: either report them as uncertain (propagate through to predictions), fix them at a central value, or collect more targeted data

**ElkWolves**: the `MC-ad.voc` uses tighter priors (`LOGNORMAL(1, 0.2)` vs. `LOGNORMAL(1, 1)`) based on the Stage 2 Powell result. Using a previous posterior as a new prior (sequential Bayesian updating) but may also introduce some risk of overfitting. The sensitivity test (`SensitivityTest.cmd`) checks how predictions differ with vs. without this prior tightening.

---

### Decision 5 Summary

```
After calibration, check in order:
1. Did the optimizer converge? (payoff terminal message, restart consistency)
2. Are parameter estimates in plausible ranges? (bounds, literature, priors)
3. Kalman residuals white? (whiteness test; autocorrelation → model misspecification)
4. MCMC R-hat < 1.1? (convergence; if not → more burn-in, tune jump, more restarts)
5. Posterior predictive envelopes cover data? (predictive check; if not → bias or variance mismatch)
6. Robust to prior changes? (prior sensitivity; if not → parameter is not data-identified)
```

---

## Section 6: ElkWolves Decision Walkthrough

*Walking through every decision in this guide against the ElkWolves project choices to verify the tree gives correct answers.*

---

### 6.1 Likelihood

**Q1.1**: Observations are counts of elk and wolves — discrete individuals.
→ **Candidate: Poisson**. Correct for simulation (RANDOM_POISSON in generator). For real Yellowstone data: aerial survey → detection < 100% → would use Gaussian.

**Q1.2**: Measurement variance unknown (observation process is stochastic, scale uncertain).
→ **Estimate with LOGNORMAL prior**. ✓ Implemented: `LOGNORMAL(1,1)` in `.voc`.

**Q1.3**: Model is stochastic (RANDOM_POISSON, RANDOM_BINOMIAL flows in generator); estimator is deterministic but process noise needs tracking.
→ **Kalman filter** (*CK). ✓ Implemented: `KalmanFit.vpd`, `SIMULATE>KALMAN|1`.

**Decision 1 verdict**: Kalman Gaussian likelihood with estimated variance fractions. ✓

---

### 6.2 Process Noise

**Q2.1**: Genuine stochasticity? Yes — births (demographic stochasticity) and deaths (random per-individual mortality) in an ecological system with small-to-medium populations.
→ **Process noise appropriate**. ✓

**Q2.2**: Can Q be derived analytically?
- Elk births: Poisson(Elk·α·dt) → variance/time = Elk·α ✓
- Elk deaths: Binomial(Elk, m·dt) → variance/time = Elk·m·(1−m·dt) ✓
- Combined: `Elk Driving Var = Elk·(α + m·(1−m·dt))` ✓ Exact formula implemented in the estimator.
→ **Yes, derived analytically**. ✓

**Q2.3**: Scales known? No.
→ **Estimate `Est Elk/Wolf driving noise scale`** with `LOGNORMAL(1,1)`. ✓

**Q2.4**: Identifiable? Marginal with sparse data. Wolf scale (0.10) much lower than elk scale (0.94) — plausible but sparse data means high posterior uncertainty on scales. Analytical Q shape helps constrain identification. Stronger priors could be used. ✓

**Decision 2 verdict**: Analytically-derived Q with estimated scale parameters. ✓

---

### 6.3 Priors

**Dynamics parameters** (growth rates, mortality, predation):
- Physical character: rates, fractions → [0,1] bounds, uniform prior
- Q3.3: No previous estimates → diffuse uniform ✓
- Implemented: `0<=Reference wolf growth rate<=1` (no prior spec = uniform) ✓

**Noise parameters** (measurement var fracs, driving noise scales):
- Physical character: positive scale parameters, uncertain over orders of magnitude → log-normal
- Q3.3: No previous estimates → `LOGNORMAL(1,1)` ✓
- Implemented: `LOGNORMAL(1,1)` in `Parameters+Filter.voc` ✓

**After Stage 2 (MC-ad.voc)**:
- Tight prior `LOGNORMAL(1,0.2)` on noise fracs: Powell found ~1 → prior centered on result
- Tight prior `LOGNORMAL(0.1,0.2)` on `Elk other mortality rate`: Powell found ~0.1 → sequential update ✓

**Q3.4**: `Elk fractional growth rate alpha` and `Elk other mortality rate` near-collinear. Best fit shows both high (0.82 and 0.49 vs. true 0.4 and 0.1). Prior tightening in MC-ad resolves this partially by anchoring mortality near 0.1.
→ **Decision 3 identifies the identification problem and recommends tighter prior or model simplification**. ✓

**Decision 3 verdict**: Uniform priors for dynamics; log-normal for noise; sequential tightening after Stage 2. ✓

---

### 6.4 Estimation Method

**Q4.1**: Uncertainty needed? Yes — want to understand parameter uncertainty and generate predictive intervals for elk/wolf trajectories.
→ **MCMC required**. ✓

**Q4.2**: Process noise significant? Yes.
→ **Kalman filter**. ✓

**Q4.3**: Both Powell and MCMC needed?
- Stage 1 Powell (6 params): fast point estimate. ✓
- Stage 2 Powell+Kalman (11 params, 4 restarts): refined starting point. ✓
- Stage 3 MCMC: full posterior. ✓
→ **Standard three-stage workflow, correctly applied**. ✓

**Q4.4**: Model speed: ~1ms per simulation. With 16 threads: 64 chains × 32K iterations = 2M simulations; wall time ≈ 2M × 1ms / 16 threads ≈ 35 minutes. Feasible. ✓

**Decision 4 verdict**: Full three-stage workflow with Kalman filter correctly chosen and feasible given model speed. ✓

---

### 6.5 Checking Results

**Q5.1**: Both `Parameters+Filter.voc` (Powell) and `Parameters+Filter MC.voc` (MCMC) terminate normally. `Est-data-MCad-sparse.out` shows `Normally terminated optimization` after 32,011 simulations. ✓

**Q5.2**: Parameter plausibility:
- Wolf growth rate (0.21), predation rate (0.10), wolf mortality (0.11): all near true values ✓
- Elk other mortality (0.49): high vs. true (0.10); alpha (0.82) also high vs. true (0.40) → identification problem on sparse data; known limitation, consistent with Q3.4 assessment ✓
- No parameters at bounds except within reasonable range ✓

**Q5.3**: Whiteness test configured: `LAGMax=4`, `NSDWt=4.0`. `:DEBUg` in `kalman.prm` enables diagnostic output. Not reported in the `.out` file excerpt — would appear in `command.log` during the MCMC run. ✓ (framework correctly set up)

**Q5.4**: MCMC convergence: `MCNCHAINS=2` → 2 chains per parameter. `MCBURNIN=30000` / `MCLIMIT=32000` = 93.75% discarded. Conservative burn-in reduces risk of non-convergence. ✓

**Q5.5**: `SensitivityTest.cmd` runs posterior predictive check. Runs are exported to TAB for visual comparison. ✓

**Q5.6**: Prior sensitivity implicitly tested by comparing `Parameters+Filter.voc` (loose priors) vs. `Parameters+Filter MC-ad.voc` (tight priors). If results agree → robust; if they differ → prior matters, and the tighter prior (informed by previous run) is preferred. ✓

**Decision 5 verdict**: All checks are configured. The identification problem (alpha/mortality) is flagged by Q5.2 and is a known limitation of sparse data, not a calibration failure. ✓

---

## Section 7: Quick Reference Card

*The five decisions in condensed form.*

```
CALIBRATION DECISIONS QUICK REFERENCE

1. LIKELIHOOD
   Counts, synthetic data          → Poisson (*CP in Vensim)
   Counts, real field data         → Gaussian (unknown detection)
   Continuous, additive error      → Gaussian (*C or *CK)
   Multiplicative / log-scale      → Log-Gaussian (*CGL)
   Variance unknown?               → LOGNORMAL prior on var frac
   Model stochastic?               → Kalman filter (*CK)

2. PROCESS NOISE
   Genuine stochasticity?          → Yes: include driving noise (Q)
   Q derivable analytically?       → Yes: use formula; estimate scale only
                                   → No: estimate Q directly with LOGNORMAL
   Near-identification problem?    → Use strong prior; more data; reduce params

3. PRIORS
   Positive scale param            → LOGNORMAL(expected, CV)
   Bounded, symmetric              → UNIFORM (no prior spec in .voc)
   Bounded, expert judgment        → PERT(lo, mode, hi)
   Previous estimate exists        → LOGNORMAL or NORMAL centered on it
   Parameter hits bound?           → Add informative prior or fix it

4. ESTIMATION METHOD
   Need uncertainty?               → Yes: Powell first, then MCMC
                                   → No: Powell with multiple restarts
   Process noise significant?      → Yes: Kalman filter + *CK payoff
   Model fast (< 1s/sim)?          → MCMC with 64 chains, long chains
   Model slow (> 10s/sim)?         → Powell; or MCMC with few/short chains

5. CHECKING RESULTS
   Converged?                      → Payoff terminal msg; restart consistency
   Estimates plausible?            → Check bounds, literature, prior support
   Residuals white?                → Kalman whiteness test; LAGMax=4, NSDWt=4
   MCMC converged?                 → R-hat < 1.1; increase burn-in if not
   Predictions match data?         → Posterior predictive sensitivity run
   Robust to priors?               → Re-run with different prior widths
```

---

## Section 8: Real Ecological Data vs. Simulation — An Important Caveat

The ElkWolves project uses **synthetic data generated from a known model**. This is invaluable for understanding the calibration system (ground truth is known!), but real ecological data raises additional challenges not present in synthetic experiments:

**Detection probability**: Aerial surveys of Yellowstone elk typically detect 60–90% of animals; detection varies by vegetation, snow cover, group size, and survey method. The "observed" count is a random variable driven by both true population size and detection probability. A model that treats the aerial count as `Poisson(TruePop)` is wrong; a model that treats it as `Binomial(TruePop, detection_rate)` with uncertain detection rate is more appropriate.

**Spatial heterogeneity**: Wolves and elk don't mix uniformly. Local densities, pack territories, and migration routes violate the well-mixed assumption of Lotka-Volterra dynamics. Residual autocorrelation in a spatial model calibrated to aggregate data is expected and should be interpreted carefully.

**Multiple data streams**: Real Yellowstone data includes: aerial elk surveys (annual), wolf pack monitoring (monthly), mortality cause data, age structure from hunter kills. Each stream has different measurement error structure. The `*CKE` directive (exclude from likelihood while still tracking state) can be used to incorporate a data stream for state smoothing without letting its poorly-characterized error structure contaminate the parameter estimates.

**Non-stationarity**: Wolf reintroduction (1995), management interventions, and climate variation change parameters over time. A time-homogeneous Lotka-Volterra model will show systematic residuals during transition periods. The whiteness test (Decision 5.3) would flag this.

These considerations don't change the decision tree — they change the *answers* to its questions. For real data, Q1.1 ("Are observations counts with near-complete detection?") almost always answers "No," leading to Gaussian rather than Poisson likelihoods.

## License

Copyright 2026 Ventana Systems, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
