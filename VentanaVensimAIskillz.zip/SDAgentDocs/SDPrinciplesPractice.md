# System Dynamics: Principles and Practice

A reference for students and modeling agents, distilled from introductory teaching materials by Tom Fiddaman (originated by Bob Eberlein), Ventana Systems.

---

## 1. Why System Dynamics?

Real-world problems are **coupled and dynamic**. Climate change, economic crises, supply chain failures, addiction, and population growth all share a common feature: the behavior arises from structure, not from external events alone.

**Laundry-list thinking** — the dominant mental model — has serious limitations:
- External focus; linear causality
- Static importance weights
- Treats factors as independent
- Non-operational, non-testable
- Leads to forecasting and reaction rather than learning

**Systemic thinking** replaces this with:
- Internal focus; circular (feedback) causality
- Dynamic importance weights
- Operational, testable structure
- Learning and leverage rather than reaction

**Why simulate?**
- People are good at identifying structure but bad at predicting its consequences
- Computers are good at predicting consequences of structure but cannot identify it
- Simulation bridges the gap

**Limitations of SD to keep in mind:**
- Causal / reductionist / mechanistic approach
- Continuous-time formulation may miss discrete detail
- Building good models is expensive in time and expertise

---

## 2. Events, Behavior, and Structure

The same structure generates different events in different contexts. To understand a system:

| Layer | Example |
|-------|---------|
| **Events** | A market crash today |
| **Behavior** | Recurring boom-bust cycles |
| **Structure** | Feedback loops, delays, decision rules |

Leverage comes from changing **structure**, not reacting to events. Causal loop diagrams and stock-flow models make structure explicit and testable.

---

## 3. Causal Loop Diagramming

### Naming variables
- Use **nouns** (or noun phrases) — quantities that can accumulate or vary
- Express in **positive sense** (e.g., "Inventory", not "Lack of Inventory")
- Direction should be clear; avoid double negatives
- Non-normative labels (no "good" or "bad" built into the name)

### Link polarity
A causal link from X → Y is:
- **Positive (+)**: "If X increases, Y increases from what it would otherwise have been" (all else equal)
- **Negative (−)**: "If X increases, Y decreases from what it would otherwise have been"

Links represent **causation**, not correlation. Always ask: is this a real causal mechanism or a spurious association?

### Loop polarity
- Count the number of negative links in a loop
- **Even number (including zero)** → **Positive (reinforcing) loop** — amplifies change
- **Odd number** → **Negative (balancing) loop** — resists change, seeks a goal
- Generally it is better to walk through the loop and 'tell the story' rather than merely counting

### Limitations of CLDs
CLDs cannot reliably predict behavior — they show possible loops but not dominance, delays, or nonlinearities. Always simulate.

---

## 4. Stocks and Flows

### Stocks (levels, states, integrals)
- **Accumulate** over time; they have **memory**
- Persist when all flows stop ("stop the world" test: the stock remains, the flow disappears)
- Units: a **quantity** (people, dollars, kg, meters of inventory)
- Name as **nouns**
- Physical stocks are always ≥ 0; conservation laws apply to material quantities
- Examples: Population, Capital, Inventory, Customer Base, Pressure to Act

```
Stock = INTEG( Net Inflow, Initial Value )
```

### Flows (rates, derivatives)
- **Change** stocks; they are the derivatives of stocks
- Units: **quantity / time** (people/month, dollars/year)
- Name as verbs or "-ing" forms, or use a word that indicates change: "Hiring Rate", "Depreciation", "Adoption Rate"
- Determined by stocks, information, and parameters — not directly by other flows
- Model flows as **continuous** where possible (Forrester's advice); avoid cluttering models with discrete event detail unless it is essential to the behavior of interest

### Distinguishing stocks from flows
| Feature | Stock | Flow |
|---------|-------|------|
| Units | stuff | stuff/time |
| "Stop the world" | persists | disappears |
| Role | memory, delay | rate of change |

### Auxiliaries (converters)
Variables that transform information: indicators, decision functions, exogenous inputs. They have no memory; they compute instantly from their inputs.

### Information channels
Information links are subject to delay, distortion, bias, and error. These imperfections are often the source of oscillation and policy resistance.

### Lookups (table functions)
When a relationship is nonlinear but hard to express as a formula:
- Define **domain** (input range) and **range** (output range) explicitly
- **Normalize** inputs and outputs where possible (use fractions of normal)
- Ensure **continuity** and physically sensible behavior at extremes
- Avoid kinks (discontinuities in slope) unless they represent real thresholds
- Note any **implicit time constants** hidden in the shape

---

## 5. Basic Behavior Modes and Structures

| Behavior | Archetype structure | Key driver |
|----------|--------------------|-|
| Exponential growth | 1st-order positive loop | Growth rate × Stock |
| Exponential decay | 1st-order negative loop | Decay rate × Stock |
| Goal seeking | 1st-order negative loop | Gap between goal and state |
| S-shaped growth | Positive + negative loops | Shifting loop dominance |
| Oscillation | 2nd-order negative loop with delay | Overcorrection |
| Overshoot & collapse | Growth + resource depletion | Delay in perceiving limits |
| Chaos | 3rd-order structures | Sensitive dependence |

**Shifting loop dominance**: the same loop structure can produce qualitatively different behavior as parameters change. A model of population growth can shift from exponential to S-shaped to overshoot-and-collapse depending on whether resource limits are present and how quickly they feed back.

---

## 6. Quantitative Rules of Thumb

### Negative feedback — goal seeking / decay

```
Stock = INTEG( -Outflow )
Outflow = Stock * Decay Rate
```
or
```
Change = (Goal - Stock) / Time Constant
```

- **Time constant** τ = 1 / decay rate
- **Half-life** ≈ 0.7 × τ  (because ln 2 ≈ 0.7)
- ~2/3 of adjustment complete at 1 time constant (because e^(-1) ≈ 0.368)
- ~95% of adjustment complete at 3 time constants (because e^(-3) ≈ 0.0498)

*Example: if a perception adjusts 20%/day toward reality, τ = 5 days. After 15 days (3τ) it has adjusted ~95%.*

### Positive feedback — exponential growth

```
Stock = INTEG( Inflow )
Inflow = Stock * Growth Rate
```

- **Time constant** τ = 1 / growth rate
- **Doubling time** ≈ 70 / (% growth rate per period)

*Example: a population growing at 5%/year doubles in 70/5 = 14 years.*

### Delayed balancing loop
- Aggressive correction → overshoot and instability
- Rule: **be patient** — overcorrection wastes resources and destabilizes
- Use longer smoothing and smaller adjustment fractions when delays are large

### Nonlinearity
- "2 + 2 = 5" — interacting factors can produce superadditive or subadditive effects
- Getting a bigger hammer won't work when you're hitting the wrong nail
- Look for shifting dominance before assuming more of the same policy will work

---

## 7. Bathtub Dynamics

The bathtub analogy is fundamental: a stock (bathtub water level) integrates its net flow (faucet minus drain). Key implications:

- **Pattern matching is broken**: a stock and its flow are causally connected but can look completely different in time (e.g., a linearly increasing inflow produces a quadratically increasing stock)
- **Lack of correlation ≠ lack of causation** — never assume that because a flow and a stock don't correlate, they are unrelated
- Always ask: is this variable a stock or a flow? Confusing them leads to structurally wrong models

---

## 8. Sources of Error and Uncertainty

A well-formulated model must account for multiple sources of uncertainty:

| Source | Examples |
|--------|---------|
| Model structure | Missing loops, wrong decision rules |
| Parameters | Imprecisely known constants |
| Driving noise | Poisson arrivals, unknown random processes, discrete shocks (tariffs, tsunamis) |
| Measurement error | Sampling error, instrument imprecision, systematic bias |

"Randomness is structure we don't understand." Driving noise can be modeled with stochastic Vensim functions (RANDOM PINK NOISE, RANDOM NORMAL, RANDOM POISSON, RANDOM BINOMIAL). Measurement error is distinct from process noise and should be modeled separately.

To reason clearly about a system, you need:
1. Time-series data that can be matched to model outputs
2. Subject-matter expertise guiding model choices
3. A model of the system dynamics
4. A model of the data-generating process (including noise and measurement)

---

## 9. System Archetypes

Archetypes are recurring loop structures with characteristic behaviors and policy insights. They emerge from simulation experience, not the other way around — don't shoehorn a situation into an archetype before verifying the structure.

| Archetype | Core structure | Leverage |
|-----------|---------------|---------|
| **Limits to Growth** | Growth loop + resource limit | Remove the limit; don't push harder on growth |
| **Shifting the Burden** | Symptomatic fix undermines fundamental solution | Invest in fundamental fixes; beware dependency |
| **Eroding Goals** | Lowering the goal when the gap grows | Hold the vision; don't let the goal drift down |
| **Escalation** | Two actors each responding to the other | Look for mutual win; try to reverse the cycle |
| **Success to the Successful** | Winner takes more resources | Restructure rewards to weaken the coupling |
| **Tragedy of the Commons** | Shared resource depleted by individual actors | Manage the common resource collectively |
| **Fixes that Fail** | Fix has delayed side effects that worsen the original problem | Focus on long-term consequences |
| **Growth and Underinvestment** | Demand growth outpaces capacity | Build capacity in advance of demand |
| **Delayed Balancing Loop** | Correction overshoots due to delay | Be patient; reduce aggressiveness of correction |

### Policy resistance
Even well-intentioned policies fail when:
- They address symptoms rather than causes
- Compensating feedback undermines the intervention
- Inherent control mechanisms are relaxed
- Side effects dominate in the long run

Effective policy:
- Taps natural forces rather than fighting them
- Uses leverage and amplification
- Avoids creating dependency on the intervention
- Considers paradoxical interventions when direct approaches are resisted

---

## 10. Conceptualization and Modeling Workflow

### Defining the problem
1. **Problem statement**: what behavior needs explaining?
2. **Reference modes**: time series (observed or hypothetical) of key variables showing the problem behavior
3. **Dynamic hypothesis**: a feedback loop structure that could generate the reference modes
4. **Model boundary**: what is endogenous, exogenous, excluded?
5. **Time horizon**: long enough to see the behavior of interest unfold

### Developing structure
1. Identify **stocks** — what accumulates? What has inertia or memory?
2. Link stocks with **flows** — what causes each stock to increase or decrease?
3. Close the loops — what decisions, goals, resources, or physical constraints close the feedback?
4. Add **auxiliaries** for decision rules and functional relationships
5. Add **lookups** for nonlinear relationships
6. Specify **units** for every variable; enforce dimensional consistency

### Equation formulation
- Write equations so that units balance on both sides
- Flow units = Stock units / Time
- Formulate decisions using operational logic (what information does the actor actually have?)
- Use **bounded rationality** rather than optimization unless optimization is literally what agents do

### Initializing in equilibrium
- Set initial conditions so that all derivatives equal zero at time zero (unless the problem is specifically about transient dynamics)
- This simplifies interpretation and avoids spurious startup behavior

### Simulating and learning
- Work in **small pieces**; run frequently
- Write down **expectations** before running — surprises are the most valuable learning
- Every defect is a treasure: unexpected behavior points to structural errors or missing mechanisms
- Use **test inputs** (STEP, PULSE, RAMP, noise) to reveal inherent behavior

---

## 11. Model Analysis and Testing

### Structural review
- **Dimensional consistency**: do units balance everywhere?
- **Physical coherence**: do material stocks stay ≥ 0? Are conservation laws respected?
- **Variable names**: nouns for stocks, "-ing"/"-Rate" for flows; one concept per variable
- **Operational correspondence**: does each variable have a clear real-world counterpart?
- **Lookups**: domain, range, normalization, continuity, monotonicity, anchor points

### Behavioral testing
| Test | Purpose |
|------|---------|
| Step/pulse/ramp inputs | Reveal inherent behavior modes |
| Extreme conditions | Force stocks to zero or infinity; check realism |
| Equilibrium check | Does the system settle? Does it return to initial equilibrium? |
| Asymmetric disturbances | Positive vs. negative shocks of equal magnitude |
| Multiple amplitude levels | Small vs. large inputs |
| Reality Checks (`:THE CONDITION:`/`:IMPLIES:`) | Automated sanity checks |

### Behavior modes to check for
- Growth, decay, S-shaped growth, overshoot, overshoot-and-collapse, oscillation, limit cycle, chaos

### Performance metrics

| Behavior type | Metrics |
|---------------|---------|
| Steady state | Mean, equilibrium value, steady-state error |
| Growth / decay | Time constant, half-life, growth rate, doubling time |
| Overshoot | Rise time, peak overshoot, time to peak, settling time |
| Oscillation | Amplitude, period, phase lag |

### Simulation method
- **Time step**: shorter than 1/4 to 1/2 of the shortest time constant or delay; halve until behavior stops changing
- **Euler** for models with discrete events (step functions, IF THEN ELSE logic)
- **RK4** for models with smooth oscillation or stiff systems
- Always test alternative integration methods

### Sensitivity analysis
Levels of sensitivity (from least to most concerning):
1. **Insensitive** — behavior mode unchanged regardless of parameter values
2. **Numerical** — values shift but behavior "looks" the same
3. **Behavior mode** — qualitative shift (e.g., goal-seeking → oscillation)
4. **Policy** — conclusions about the best policy change

Use sensitivity analysis to: identify leverage points, link behavior to loop structure, search for equilibria, and evaluate robustness of policy conclusions.

### Feedback elimination
To identify which loops drive a behavior:
- Sever flow connections
- Replace variables with constants or test inputs
- Insert `0 * variable` or `variable^0` to break feedback algebraically
- Flatten lookup tables to linear

### Partial model testing
- Cut subsystems into separate models
- Drive them with data or test inputs
- Test subsystem responses before integrating

---

## 12. Vensim Reference

For Vensim-specific implementation details, see the `VensimAgentDocs/` folder:

- **`EQUATIONS.md`** — Equation syntax, built-in functions (INTEG, SMOOTH, STEP, PULSE, RANDOM PINK NOISE, IF THEN ELSE, etc.), subscripts, macros
- **`VENSIM.md`** — Running models from the command line, command scripts, parsing `command.log`, diagnosing errors
- **`FILES.md`** — File types (`.mdl`, `.vdfx`, `.tab`, `.voc`, `.vpd`, `.vsc`, etc.)
- **`CALIBRATION.md`** / **`KALMAN.md`** / **`SENSITIVITY.md`** — Calibration, estimation, and sensitivity analysis workflows
- **`MDL.md`** / **`SKETCH.md`** — `.mdl` file format and diagram layout

---

## 13. Resources

### Books
- *Business Dynamics* — John Sterman (the standard graduate text)
- *Strategy Dynamics* — Kim Warren
- *Modeling the Environment* — Andrew Ford
- *Industrial Dynamics* — Jay Forrester (the original)

### Online
- Vensim documentation and forum: [vensim.com](https://vensim.com)
- SD Society: [systemdynamics.org](https://www.systemdynamics.org)
- Model library: [models.metasd.com](http://models.metasd.com)
- Bathtub dynamics blog posts: [metasd.com/2012/05/bathtub-dynamics](https://metasd.com/2012/05/bathtub-dynamics/)
- Bathtub statistics: [metasd.com/2012/05/bathtub-statistics](https://metasd.com/2012/05/bathtub-statistics/)

## License

Copyright 2026 Ventana Systems, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.